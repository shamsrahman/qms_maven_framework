package com.mhplan.qms.common;

import java.io.File;
import java.lang.reflect.Method;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mhplan.qms.DriverScript;
import com.mhplan.qms.ConfigManager.FileLoc;
import com.mhplan.qms.ObjectRepository.Admin;
import com.mhplan.qms.ObjectRepository.MedicalRecords;
import com.mhplan.qms.reportmanager.PrepareReport;

/**
 *
 *
 */
public class BaseClass {

	private static final Logger LOG = Logger.getLogger(BaseClass.class.getName());

	public static WebDriver driver = null;
	public static WebDriver incdriver = null;
	public static Properties prop = null; // properties file
	public static Properties objRepProp = null; // object repository property
	public static PrepareReport obj = new PrepareReport();
	public static boolean stepFail; // keep track of total step fail for each testcase
	public static int mainStep; // keep track of main step for each testcases
	public static int subStep; // keep track of subStep for each mainStep
	public static boolean testCaseFlow; // keep track of the test flow
	public static boolean bGetButtonCallFlag; // Keep Track of call status
	public static int callCounts; // Keep track of call try count
	public static int totalTime;
	public String strTimeDiff = null;
	public static String PageTitle = null;
	public static int count;
	private static String noElementFound = "--No Such Element Found--";
	private static String loginFailed = "fnLogIn------------------Failed";
	private Boolean bFlag = true;
	public static int count1;

	public BaseClass() {

	}

	private final DateFormat DATE_FORMAT_dd_MM_yy_hh_mm_ss = new SimpleDateFormat("dd_MM_yy_hh_mm_ss");

	/**
	 * Returns a String which represents the current date/time in the format:
	 * "dd_MM_yy_hh_mm_ss"
	 *
	 * @return
	 */
	public final String getDateTime() {
		return DATE_FORMAT_dd_MM_yy_hh_mm_ss.format(new Date());
	}

	private static final String SYSTEM_PROPERTY_NAME_WEBDRIVER_CHROME_DRIVER = "webdriver.chrome.driver";
	private static final String CHROME_DRIVER_CAPABILITY_NAME_CHROME_BINARY = "chrome.binary";
	private static final String CHROME_DRIVER_OPTIONS_TEST_TYPE = "test-type";
	private static final String CHROME_DRIVER_FILE_NAME = "chromedriver.exe";

	public void fnSetBrowserCapabilities() {
		final String preferredChromeDriverPath = getPreferredChromeDriverFilePath();
		System.setProperty(SYSTEM_PROPERTY_NAME_WEBDRIVER_CHROME_DRIVER, preferredChromeDriverPath);
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		options.addArguments(CHROME_DRIVER_OPTIONS_TEST_TYPE);
		capabilities.setCapability(CHROME_DRIVER_CAPABILITY_NAME_CHROME_BINARY, preferredChromeDriverPath);
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
	}

	/**
	 * Returns a String which represents the preferred path to the Chrome Driver for
	 * this execution environment:
	 * <ol>
	 * <li>First, look to the user's home directory for a file named:
	 * "chromedriver.exe". If exists, use this file. Else:</li>
	 * <li>Look to the location specified by this program's configuration</li>
	 * </ol>
	 *
	 * @return
	 * @see FileLoc.sChromeDriverPath
	 */
	protected String getPreferredChromeDriverFilePath() {
		String path = null;
		final String userHomeDirectoryFilePath = System.getProperty("user.home") + System.getProperty("file.separator")
				+ CHROME_DRIVER_FILE_NAME;
		final String projectDirectoryFilepath = FileLoc.sChromeDriverPath + CHROME_DRIVER_FILE_NAME;
		try {
			LOG.info("Looking for chrome driver at this path: " + userHomeDirectoryFilePath);
			File file = new File(userHomeDirectoryFilePath);
			if (file.isFile() && file.canExecute()) {
				path = file.getAbsolutePath();
				LOG.info("Successfully identified ChromeDriver from user's home directory!");
			}
		} catch (Exception ignoredException) {
			LOG.error(ignoredException);
			// ignore
		}
		if (path == null) {
			LOG.info("Unable to identify the ChromeDriver executable file at: " + userHomeDirectoryFilePath);
			LOG.info("Attempting to load ChromeDriver from: " + projectDirectoryFilepath);
			try {
				File file = new File(projectDirectoryFilepath);
				if (file.isFile() && file.canExecute()) {
					path = file.getAbsolutePath();
					LOG.info("Successfully identified ChromeDriver from project directory!");
				} else {
					path = null;
				}
			} catch (Exception ignoredException) {
				LOG.error(ignoredException);
				// ignore
			}
		}
		if (path == null) {
			LOG.fatal("Unable to identify an executable ChromeDriver.");
		}

		return path;
	}

	private static SecureRandom secureRandom;

	/**
	 * Generate a random integer
	 *
	 * @param count
	 * @return
	 */
	public int fnRandomNum(int count) {
		if (secureRandom == null) {
			secureRandom = new SecureRandom();
		}
		return secureRandom.nextInt(count);
	}

	/**
	 * Generate a random number within that specified range Note:
	 * <ul>
	 * <li>parameters must match the following rule: max &gt; min &gt; 0.</li>
	 * <li>if min &lt; 0, min is set to zero</li>
	 * <li>if max &lt; 0, max is set to the value of Integer.MAX_VALUE</li>
	 * <li>If max < min, max is set to the value of Integer.MAX_VALUE</li>
	 * </ul>
	 *
	 * @param min @param max
	 * @re
	 *
	 * 	t u rn
	 */
	public int fnRandomtwoNum(int min, int max) {
		// NOTE: Usually this should be a field rather than a method
		// variable so that it is not re-seeded every call.
		Random rand = new Random();
		// nextInt is normally exclusive of the top value,
		// so add 1 to make it inclusive

		return rand.nextInt((max - min) + 1) + min;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void fnExecuteFunction(String className, String sFunctionName) {
		try {
			Class[] cArg = new Class[1];
			cArg[0] = obj.getClass();

			// load the ClassName at runtime
			Class clsObj = Class.forName(className);
			Object obj1 = clsObj.newInstance();

			Method method = clsObj.getDeclaredMethod(sFunctionName, cArg);
			PrepareReport.totalExecuted++;
			method.invoke(obj1, obj);

		} catch (Exception e) {
			DriverScript.log.info("Test case failed for " + sFunctionName + ". Check if the function is missing...");
		}
	}

	public void highlightElementByName(String value) throws InterruptedException {
		WebElement ele = driver.findElement(By.name(value));

		String originalStyle = ele.getAttribute("style");

		JavascriptExecutor js = (JavascriptExecutor) driver;
		for (int i = 0; i < 2; i++) {
			js.executeScript(
					"arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red; width: 100%');",
					ele);
			Thread.sleep(500);
			js.executeScript("arguments[0].setAttribute('style', '" + originalStyle + "');", ele);
			Thread.sleep(500);
		}
	}

	/**
	 *
	 * @param IDvalue
	 * @throws InterruptedException
	 */
	public void HighlightElementById(String IDvalue) throws InterruptedException {
		WebElement ele = driver.findElement(By.id(IDvalue));
		String originalStyle = ele.getAttribute("style");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		for (int i = 0; i < 2; i++) {
			js.executeScript(
					"arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red; width: 100%');",
					ele);
			Thread.sleep(500);
			js.executeScript("arguments[0].setAttribute('style', '" + originalStyle + "');", ele);
			Thread.sleep(500);
		}

	}

	/**
	 *
	 * @param xPath
	 * @throws InterruptedException
	 */
	public void HighlightElementByXpath(String xPath) throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath(xPath));
		HighlightElement(ele);

	}

	/**
	 *
	 * @param ele
	 * @throws InterruptedException
	 */
	public void HighlightElement(WebElement ele) throws InterruptedException {
		String originalStyle = ele.getAttribute("style");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		for (int i = 0; i < 2; i++) {
			js.executeScript(
					"arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red; width: 100%');",
					ele);
			Thread.sleep(150);
			js.executeScript("arguments[0].setAttribute('style', '" + originalStyle + "');", ele);
			Thread.sleep(150);
		}
	}

	/**
	 * Returns true of the driver is able to find a single element at the specified
	 * xpath
	 *
	 * @param xPath
	 * @return
	 */
	public boolean elementFound(String xPath) {
		boolean result = false;
		List<WebElement> eleList = driver.findElements(By.xpath(xPath));
		if (eleList.size() == 1) {
			result = true;
		}
		return result;
	}

	/**
	 * Returns the number of elements which this webDriver is able to find at the
	 * specified xpath. If the driver is unable to find any elements which match the
	 * specified xpath, an error is logged and zero (0) is returned.
	 *
	 * @param value
	 * @return
	 */
	public int checkXpath(String value) {
		int result = 0;
		try {
			List<WebElement> eleList = driver.findElements(By.xpath(value));
			result = eleList.size();
		} catch (Exception e) {
			LOG.info("Xpath>>" + value + " not found.");
		}
		return result;
	}

	/**
	 * Returns the number of elements which this webDriver is able to find which
	 * match the specified element ID. If the driver is unable to find any elements
	 * which match the specified ID, an error is logged and zero (0) is returned.
	 *
	 * @param value
	 * @return
	 */
	public int checkId(String value) {
		int result = 0;
		try {
			List<WebElement> eleList = driver.findElements(By.id(value));
			result = eleList.size();
		} catch (Exception e) {
			LOG.info("Id>>" + value + " not found.");
		}
		return result;
	}

	/**
	 * Returns true iff the driver is able to find text in the page which matches,
	 * case-insensitively, the specified input String
	 *
	 * @param text
	 * @return
	 */
	public boolean checkTextOnPage(String text) {
		boolean result;
		if (text != null) {
			text = text.toLowerCase();
			result = driver.getPageSource().toLowerCase().contains(text);
		} else {
			result = false;
		}
		return result;
	}

	/**
	 *
	 * @param text
	 * @return
	 * @throws Exception
	 */
	public boolean fnCheckTextOnPage(String text) throws Exception {
		boolean result = true;
		try {
			result = checkTextOnPage(text);
			if (result) {
				obj.repAddData("Check Text  on page", "'" + text + "' should  be Present", "'" + text + "'  present ",
						"Pass");
			} else {
				obj.repAddData("Check Text  on page", "'" + text + "' should  be Present",
						"'" + text + "' not present ", "Fail");
			}

		} catch (Exception e) {
			LOG.info("--" + text + "--Present");

			obj.repAddData("Check Text  on page", "'" + text + "' should  be Present", "'" + text + "' not present ",
					"Fail");
			throw (e);
		}
		return result;
	}

	/**
	 *
	 * @param text
	 * @return
	 * @throws Exception
	 */
	public boolean fnCheckTextNotOnPage(String text) throws Exception {
		boolean result = true;
		try {
			text = text.toLowerCase();
			result = driver.getPageSource().toLowerCase().contains(text);

			if (result == false) {
				obj.repAddData("Check Text Not on page", "'" + text + "' should not be Present",
						"'" + text + "' not present ", "Pass");
			} else {
				obj.repAddData("Check Text Not on page", "'" + text + "' should not be Present",
						"'" + text + "'  present ", "Fail");
			}
		} catch (Exception e) {
			LOG.info("--" + text + "--Present");
			obj.repAddData("Check Text Not on page", "'" + text + "' should not be Present", "'" + text + "'  present ",
					"Fail");
			throw (e);
		}
		return result;

	}

	/**
	 * perform one action from Keyboard
	 *
	 * @param action
	 * @param actionDescription
	 * @throws Exception
	 */
	public void keyboardAction(Keys action, String actionDescription) throws Exception {
		try {
			Actions act = new Actions(driver);
			act.sendKeys(action).build().perform();
			Thread.sleep(1000);
			obj.repAddData("Perform action from Keyboard", "'" + actionDescription + "' should be performed",
					"'" + actionDescription + "' performed", "Pass");
		} catch (Exception e) {
			LOG.info("--" + actionDescription + "--Not Performed");
			obj.repAddData("Perform action from Keyboard", "'" + actionDescription + "' should be performed",
					"'" + actionDescription + "' not performed", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param IDvalue
	 * @param key
	 * @param Field_Name
	 * @throws Exception
	 */
	public void sendKeyById(String idValue, String key, String fieldName, boolean... optionalBoolParams)
			throws Exception {
		boolean maskField = false;
		if (optionalBoolParams != null && optionalBoolParams.length > 0 && optionalBoolParams[0] == true) {
			maskField = true;
		}

		try {

			WebElement ele = driver.findElement(By.id(idValue));
			HighlightElement(ele);
			ele.clear();
			ele.sendKeys(key);
			Thread.sleep(500);
			obj.repAddData("Enter data to field " + fieldName,
					"<b>" + ((maskField == true) ? "***" : key) + "</b> should be entered to " + fieldName,
					"" + ((maskField == true) ? "***" : key) + "</b> entered to " + fieldName, "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Enter data to field " + fieldName,
					"<b>" + ((maskField == true) ? "***" : key) + "<b/> should be entered to " + fieldName,
					"<b>" + ((maskField == true) ? "***" : key) + "</b> not entered" + fieldName, "Fail");

		}
	}

	/**
	 *
	 * @param Xpath
	 * @param key
	 * @param field
	 * @throws Exception
	 */
	public void sendKeyByXpath(String xpath, String key, String field) throws Exception {
		try {
			Thread.sleep(3000);
			WebElement ele = driver.findElement(By.xpath(xpath));
			HighlightElement(ele);
			ele.clear();
			ele.sendKeys(key);
			Thread.sleep(500);
			obj.repAddData("Enter data to field" + field, "'" + key + "' should be entered to" + field,
					"'" + key + "' entered to" + field, "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Enter data to field" + field, "'" + key + "' should be entered to" + field,
					"'" + key + "' not entered to" + field, "Fail");
		}
	}

	/**
	 *
	 * @param Xpath
	 * @param key
	 * @param field
	 * @throws Exception
	 */
	public void sendKeyByXpathNoclear(String xpath, String key, String field) throws Exception {
		try {
			Thread.sleep(3000);
			WebElement ele = driver.findElement(By.xpath(xpath));
			HighlightElement(ele);

			ele.sendKeys(key);
			Thread.sleep(500);
			obj.repAddData("Enter data to field" + field, "'" + key + "' should be entered to" + field,
					"'" + key + "' entered to" + field, "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Enter data to field" + field, "'" + key + "' should be entered to" + field,
					"'" + key + "' not entered to" + field, "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param Xpath
	 * @param key
	 * @param field
	 * @throws Exception
	 */
	public void sendKeyByXpathCustomize(String xpath, String key, String field) throws Exception {
		try {
			Thread.sleep(3000);
			WebElement ele = driver.findElement(By.xpath(xpath));
			HighlightElement(ele);
			ele.clear();
			ele.sendKeys(key);
			Thread.sleep(500);
			ele.sendKeys(Keys.ENTER);
			obj.repAddData("Enter data to field" + field, "'" + key + "' should be entered to" + field,
					"'" + key + "' entered to" + field, "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Enter data to field" + field, "'" + key + "' should be entered to" + field,
					"'" + key + "' not entered to" + field, "Fail");

		}

	}

	/**
	 *
	 * @param Xpath
	 * @throws Exception
	 */
	public void sendKeyByXpathTAB(String xpath) throws Exception {
		try {
			Thread.sleep(3000);
			WebElement ele = driver.findElement(By.xpath(xpath));
			HighlightElement(ele);
			ele.sendKeys(Keys.TAB);
			obj.repAddData("Hitting Tab", "Tab should be hit", "Tab was hit", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Hitting Tab", "Tab should be hit", "Tab was not hit", "Fail");

		}

	}

	public void sendKeyByXpathENTER(String xpath) throws Exception {
		try {
			Thread.sleep(3000);
			WebElement ele = driver.findElement(By.xpath(xpath));
			HighlightElement(ele);
			ele.sendKeys(Keys.ENTER);
			obj.repAddData("Hitting ENTER", "ENTER should be hit", "ENTER was hit", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Hitting ENTER", "ENTER should be hit", "ENTER was not hit", "Fail");

		}

	}

	/**
	 *
	 * @param FileUploaderdialog_xpath
	 * @param path
	 * @param UploadButton
	 * @throws Exception
	 */
	public void fileUploader(String fileUploaderDialogXpath, String path, String uploadButton) throws Exception {
		try {
			driver.findElement(By.xpath(fileUploaderDialogXpath)).sendKeys(path);
			Thread.sleep(5000);
			driver.findElement(By.xpath(uploadButton)).click();
			obj.repAddData("Upload a file", "File should be uploaded", "File uploaded successfully", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Upload a file", "File should be uploaded", "File not uploaded", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param value
	 * @param key
	 * @throws Exception
	 */
	public void sendKeyByName(String value, String key, boolean... optionalBoolParams) throws Exception {
		boolean maskField = false;
		if (optionalBoolParams != null && optionalBoolParams.length > 0 && optionalBoolParams[0] == true) {
			maskField = true;
		}

		try {
			WebElement ele = driver.findElement(By.name(value));
			HighlightElement(ele);
			ele.clear();
			ele.sendKeys(key);
			Thread.sleep(500);
			obj.repAddData("Enter data to field",
					"<b>'" + ((maskField == true) ? "***" : key) + "'</b> should be entered",
					"<b>'" + ((maskField == true) ? "***" : key) + "'</b> entered", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Enter data to field",
					"<b>'" + ((maskField == true) ? "***" : key) + "'</b> should be entered",
					"<b>'" + ((maskField == true) ? "***" : key) + "'</b> not entered", "Fail");
			// throw(e);
		}
	}

	/**
	 *
	 * @param ele
	 * @param key
	 * @throws Exception
	 */
	public void sendKeyByElement(WebElement ele, String key) throws Exception {
		try {
			HighlightElement(ele);
			ele.clear();
			ele.sendKeys(key);
			Thread.sleep(500);
			obj.repAddData("Enter data to field", "'" + key + "' should be entered", "'" + key + "' entered", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Enter data to field", "'" + key + "' should be entered", "'" + key + "' not entered",
					"Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param Classvalue
	 * @param faceValue
	 * @throws Exception
	 */
	public void clickByClassName(String classValue, String faceValue) throws Exception {
		try {
			WebElement ele;
			ele = driver.findElement(By.className(classValue));
			HighlightElement(ele);
			ele.click();
			Thread.sleep(1000);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' clicked", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' not clicked", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param IDvalue
	 * @param faceValue
	 * @throws Exception
	 */
	public void clickById(String idValue, String faceValue) throws Exception {
		try {
			WebElement ele;
			ele = driver.findElement(By.id(idValue));
			HighlightElement(ele);
			ele.click();
			Thread.sleep(1000);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' clicked", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' not clicked", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param value
	 * @param faceValue
	 * @throws Exception
	 */
	public void clickByName(String value, String faceValue) throws Exception {
		try {
			WebElement ele;
			ele = driver.findElement(By.name(value));
			HighlightElement(ele);
			ele.click();
			Thread.sleep(1000);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' clicked", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' not clicked", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param value
	 * @param faceValue
	 * @return
	 * @throws Exception
	 */
	public String getText(String value, String faceValue) throws Exception {
		String returnText;
		try {
			WebElement ele;
			ele = driver.findElement(By.className(value));
			HighlightElement(ele);
			returnText = ele.getText();
			Thread.sleep(1000);
			obj.repAddData("Success Message'" + faceValue + "'", "'" + faceValue + "' should be Displayed",
					"'" + faceValue + "' Displayed", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Success Message'" + faceValue + "'", "'" + faceValue + "' should be Displayed",
					"'" + faceValue + "' not Displayed", "Fail");
			throw (e);
		}
		return returnText;
	}

	/**
	 *
	 * @param value
	 * @param faceValue
	 * @return
	 * @throws Exception
	 */
	public String getTextbyXpath(String value, String faceValue) throws Exception {
		String returnText;
		try {
			WebElement ele;
			ele = driver.findElement(By.xpath(value));
			HighlightElement(ele);
			returnText = ele.getText();
			Thread.sleep(1000);
			obj.repAddData("Success Message'" + faceValue + "'", "'" + faceValue + "' should be Displayed",
					"'" + faceValue + "' Displayed", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Success Message'" + faceValue + "'", "'" + faceValue + "' should be Displayed",
					"'" + faceValue + "' not Displayed", "Fail");
			throw (e);
		}
		return returnText;
	}

	/**
	 *
	 * @param value
	 * @param faceValue
	 * @param pos
	 * @return
	 * @throws Exception
	 */
	public String getTextByXpathCustomize(String value, String faceValue, int pos) throws Exception {
		String returnText;
		try {
			List<WebElement> ele;
			ele = driver.findElements(By.xpath(value));
			WebElement ele1 = ele.get(pos);
			HighlightElement(ele1);
			returnText = ele1.getText();
			Thread.sleep(1000);
			obj.repAddData("Success Message'" + faceValue + "'", "'" + faceValue + "' should be Displayed",
					"'" + faceValue + "' Displayed", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Success Message'" + faceValue + "'", "'" + faceValue + "' should be Displayed",
					"'" + faceValue + "' not Displayed", "Fail");
			throw (e);
		}
		return returnText;
	}

	/**
	 *
	 * @param value
	 * @param faceValue
	 * @throws Exception
	 */
	public void clickByLinkText(String value, String faceValue) throws Exception {
		try {
			WebElement ele;
			ele = driver.findElement(By.linkText(value));
			HighlightElement(ele);
			ele.click();
			Thread.sleep(1000);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' clicked", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' not clicked", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param value
	 * @param faceValue
	 * @throws Exception
	 */
	public void clickByXpath(String value, String faceValue) throws Exception {
		try {
			Thread.sleep(3000);
			WebElement ele;
			ele = driver.findElement(By.xpath(value));
			HighlightElement(ele);
			ele.click();
			Thread.sleep(1000);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' is clicked", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' not clicked", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param value
	 * @param faceValue
	 * @param pos
	 * @throws Exception
	 */
	public void clickByXpathJS(String value, String faceValue, int pos) throws Exception {
		try {
			Thread.sleep(3000);
			List<WebElement> ele;
			ele = driver.findElements(By.xpath(value));
			WebElement element = ele.get(pos);
			HighlightElement(element);
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].click();", element);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' is clicked", "Pass");
		} catch (Exception e) {
			LOG.info("--No Such Element Found--");
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' not clicked", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param value
	 * @param faceValue
	 * @param pos
	 * @throws Exception
	 */
	public void clickByXpathCustomize(String value, String faceValue, int pos) throws Exception {
		try {
			Thread.sleep(3000);
			List<WebElement> ele = driver.findElements(By.xpath(value));
			HighlightElement(ele.get(pos));
			ele.get(pos).click();
			Thread.sleep(1000);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' is clicked", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Click on '" + faceValue + "'", "'" + faceValue + "' should be clicked",
					"'" + faceValue + "' not clicked", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param value
	 * @param faceValue
	 * @throws Exception
	 */
	public void doubleClickByXpath(String value, String faceValue) throws Exception {
		try {
			WebElement ele;
			ele = driver.findElement(By.xpath(value));
			HighlightElement(ele);
			if (ele.isDisplayed()) {
				Actions action = new Actions(driver);
				action.doubleClick(ele).build().perform();
			}
			Thread.sleep(1000);
			obj.repAddData("Double Click on '" + faceValue + "'", "'" + faceValue + "' should be Double Clicked",
					"'" + faceValue + "' Double Clicked", "Pass");
		} catch (Exception e) {
			LOG.info(noElementFound);
			obj.repAddData("Double Click on '" + faceValue + "'", "'" + faceValue + "' should be Double Clicked",
					"'" + faceValue + "' not Double Clicked", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param text
	 * @throws Exception
	 */
	public void fnCheckTitle(String text) throws Exception {
		if (driver.getTitle().equalsIgnoreCase(text)) {
			obj.repAddData("Navigate to Login Window", "'" + text + "' window should be displayed",
					"'" + text + "' window displayed", "Pass");
		} else {
			obj.repAddData("Navigate to Login Window", "'" + text + "' window should be displayed",
					"'" + text + "' window not displayed", "Fail");
			throw new Exception();
		}
	}

	/**
	 *
	 * @param url
	 * @param user
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public Boolean fnQMSLogIn(String url, String user, String password) throws Exception {

		try {
			driver.navigate().to(url);
			Thread.sleep(2000);
			if (PageTitle == null) {
				PageTitle = driver.getTitle();
				PageTitle = PageTitle.replace(" | ", "-");
				DriverScript.indexHeader = PrepareReport.repGenerateIndexHeader(BaseClass.PageTitle,
						DriverScript.Application, DriverScript.Production, DriverScript.Phase);
				DriverScript.indexHeader_email = PrepareReport.repGenerateIndexHeaderemail(BaseClass.PageTitle,
						DriverScript.Application, DriverScript.Production, DriverScript.Phase);
			}
			if (url.equalsIgnoreCase("https://qms-qa.caidan.local)")) {
				fnWaitForObjectExistXpath(45, MedicalRecords.LabelEnvironmentQA_xpath, "QA Environment Label");
			} else if (url.equalsIgnoreCase("https://qms-dev.caidan.local)")) {
				fnWaitForObjectExistXpath(45, MedicalRecords.LabelEnvironmentDEV_xpath, "DEV Environment Label");
			} else if (url.equalsIgnoreCase("https://qms-uat.caidan.local)")) {
				fnWaitForObjectExistXpath(45, MedicalRecords.LabelEnvironmentUAT_xpath, "UAT Environment Label");
			}

			fnWaitForObjectExistId(45, MedicalRecords.InputUserId_Id, "UserName Text Box");
			sendKeyById(MedicalRecords.InputUserId_Id, user, "Username Text Box");
			sendKeyById(MedicalRecords.InputPassword_Id, password, "Password text Box", true);
			clickByXpath(MedicalRecords.authenticationProviderDomainXpath, " Authentication Provider Domain");
			fnWaitForObjectNotExistXpath(30, MedicalRecords.authenticationProviderDomainValueeXpath,
					" Authentication Provider Domain Local");

			// clickByXpath(MedicalRecords.authenticationProviderDomainValueeXpath, "
			// Authentication Provider Domain Local");
			clickByXpath(MedicalRecords.authenticationProviderDomainValueCaidanXpath,
					" Authentication Provider Domain Caidan");
			if (objectExistXpath(30, MedicalRecords.selectedDomainValueCaidanXpath)) {

				fnWaitForObjectNotExistXpath(30, MedicalRecords.viewPasswordEyeBttnXpath, "Eye button for Password");

				fnWaitForObjectNotExistXpath(30, Admin.forgot_passowrd_xpath, "Forgot Password? link");

			}

			clickByXpath(MedicalRecords.ButtonSignIn_xpath, "Sign In Button");
			if (checkTextOnPage("Login Failed.")) {
				LOG.info("Username or password are incorrect");
				DriverScript.log.info("QMS Login Failed - Username or password are incorrect");
				bFlag = false;
			}
			if (checkTextOnPage("Something went wrong")) {
				LOG.info("System not responding");
				obj.repAddData("Login to the application", "Login should not be successful due to wrong Username",
						"Login Failed", "Pass");
				DriverScript.log.info("QMS Login Failed - Username or password are incorrect");
				bFlag = false;
			}

			if (checkTextOnPage("Your QMS account is locked")) {
				LOG.info("Account is locked");
				fnWaitForObjectExist(45, Admin.MsgFinalFailedLoginAttempt_xpath, "Login Failed - Account Locked");
				DriverScript.log.info("QMS Login Failed - Account is locked");
				bFlag = false;
			}
			try {
				// wait for page to load here
				if (bFlag == true) {
					WebDriverWait wait = new WebDriverWait(driver, 35);

					try {
						fnWaitForObjectExist(45, Admin.ButtonAdmin_xpath, "Admin Button");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						bFlag = false;
						e.printStackTrace();
					}
					Thread.sleep(2000);
				}
			} catch (Exception e) {
				bFlag = false;
			}
			verifyHomePage();

		} catch (Exception e) {
			LOG.info("fnLogIn------------------Failed");
			bFlag = false;
			obj.repAddData("Login to the application", "Login should be successful", "Login Failed", "Fail");
			DriverScript.log.error("QMS Login Failed!", e);
		}
		return bFlag;
	}

	public void verifyHomePage() {

		try {
			// wait for page to load here
			if (bFlag) {
				try {
					fnWaitForObjectExist(45, Admin.ButtonAdmin_xpath, "Admin Button");
				} catch (Exception e) {
					bFlag = false;
					e.printStackTrace();
				}
				Thread.sleep(2000);
			}
		} catch (Exception e) {
			bFlag = false;
			DriverScript.log.error("Home page not loaded!", e);
			LOG.info("Home Page Header not found");
		}
	}

	/**
	 *
	 * @param email
	 * @return
	 * @throws Exception
	 */
	public Boolean fnQMSForgotPwd(String email) throws Exception {
		Boolean bFlag = true;
		try {
			fnSetBrowserCapabilities();
			driver.navigate().to(DriverScript.sAppUrl);
			Thread.sleep(2000);
			fnWaitForObjectExistId(45, MedicalRecords.InputUserId_Id, "UserName Text Box");
			clickByXpath(Admin.forgot_passowrd_xpath, "forgot password");
			sendKeyByXpath(Admin.email_field_xpath, email, " User id");
			fnWaitForObjectExist(20, Admin.reset_button_xpath, "reset button");
			clickByXpath(Admin.reset_button_xpath, "Reset button");
			fnWaitForObjectExist(20, Admin.password_reset_msg_xpath, "password reset message");
		} catch (Exception e) {
			LOG.info(loginFailed);
			bFlag = false;
			obj.repAddData("Password reset", "Password reset should be successful", "Password reset Failed", "Fail");
			DriverScript.log.error("QMS Login Failed!", e);
			throw (e);
		}
		driver.quit();
		driver = null;
		return bFlag;
	}

	/**
	 *
	 * @return @throws Exception
	 */
	public Boolean fnLoginAttempt() throws Exception {
		Boolean bLoginAttemptFlag = false;
		try {
			int iLoginAttempt = Integer.parseInt(prop.getProperty("loginAttempt"));
			obj.repAddData("Sign In to the application", "", "", "");
			for (int i = 0; i < iLoginAttempt; i++) {
				fnSetBrowserCapabilities();
				bLoginAttemptFlag = fnQMSLogIn(DriverScript.sAppUrl, DriverScript.sUsername, DriverScript.sPassword);
				if (bLoginAttemptFlag) {
					obj.repAddData("Login to the application", "Login should be successful", "Logged in successfully",
							"Pass");
					break;
				} else {
					fnSignOutTC();
				}
			}

			if (!bLoginAttemptFlag) {
				obj.repAddData("Login to the application", "Login should be successful", "Login Failed", "Fail");
			}

		} catch (Exception e) {
			LOG.info(loginFailed);
			bLoginAttemptFlag = false;
		}
		return bLoginAttemptFlag;
	}

	/**
	 *
	 * @return @throws Exception
	 */
	public Boolean fnbadLoginAttempt() throws Exception {
		Boolean bLoginAttemptFlag = true;
		try {
			int iLoginAttempt = Integer.parseInt(prop.getProperty("badloginAttempt"));
			obj.repAddData("Sign In to the application", "", "", "");
			for (int i = 0; i < iLoginAttempt; i++) {
				fnSetBrowserCapabilities();
				bLoginAttemptFlag = fnQMSLogIn(DriverScript.sAppUrl, DriverScript.sUsername, DriverScript.sPassword);
				if (!bLoginAttemptFlag) {
					obj.repAddData("Login to the application", "Login should be not successful", "Login Failed",
							"Pass");
					if (!checkTextOnPage("Your QMS account is locked")) {
						driver.quit();
						driver = null;
					}
				} else {
					fnSignOutTC();
				}
			}
			if (bLoginAttemptFlag) {
				obj.repAddData("Login to the application", "Login should not be successful", "Login Successful",
						"Fail");
			}
		} catch (Exception e) {
			LOG.info("fnWrapCall--------------Failed");

			throw (e);
		}
		return bLoginAttemptFlag;
	}

	/**
	 *
	 * @param url
	 * @param user
	 * @param password
	 * @throws Exception
	 */
	public void fnLogIn(String url, String user, String password) throws Exception {

		// add check Extension Number
		// add Hangup call if still on call
		// add change status to 'Break' if it is not
		try {

			obj.repAddData("Sign In to the application", "", "", "");

			driver.navigate().to(url);
			Thread.sleep(2000);
			// =====================

			fnCheckTitle(prop.getProperty("pageTitle")); // check title

			sendKeyByName(prop.getProperty("InputUser"), user);
			sendKeyByName(prop.getProperty("InputPassword"), password, true);

			clickById(prop.getProperty("ButtonSignIn"), "Sign In Button"); // static ID

			if (checkTextOnPage("Username or password are incorrect")) {
				LOG.info("Username or password are incorrect");
				obj.repAddData("Login to the application", "Should login", "Login not successfully", "Fail");
				throw new Exception();
			}

			try {
				// wait for page to load here
				WebDriverWait wait = new WebDriverWait(driver, 20);
				wait.until(ExpectedConditions.elementToBeClickable(By.id(prop.getProperty("ButtonAdvisor"))));
				// wait until AdvisorName button to be clickable
			} catch (Exception e) {
				LOG.info("Advisor button not found");
			}

			Thread.sleep(2000);

			if (checkTextOnPage("Home")) {
				obj.repAddData("Login to the application", "Should login", "Login successfully", "Pass");
			} else {
				obj.repAddData("Login to the application", "Should login", "Login not successfully", "Fail");
				throw new Exception();
			}

			if (checkTextOnPage(prop.getProperty("Extenstion"))) {
				LOG.info("CTI connection available");
			} else {
				obj.repAddData("CTI connection", "CTI connection should be available", "CTI connection not found",
						"Fail");
				throw new Exception();
			}

		} catch (Exception e) {
			LOG.info("fnLogIn------------------Failed");
			// throw(e);
		}
	}

	/**
	 * Sign out of the Application
	 *
	 * @throws Exception
	 */
	public void fnSignOutTC() throws Exception {
		try {
			if (driver != null) {
				obj.repAddData("Sign out from the application", "", "", "");
				clickByXpath(MedicalRecords.ButtonLogout_xpath, "Log Out Button");
				fnWaitForObjectExistId(45, MedicalRecords.InputUserId_Id, "UserName Text Box");
				driver.manage().deleteAllCookies();
				driver.quit();
				driver = null;
			}

		} catch (Exception e) {
			LOG.info("fnSignOut-----failed");
			driver.manage().deleteAllCookies();
			driver.quit();
			driver = null;
		} finally {
			driver = null;
		}
	}

	/**
	 *
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public String fnGetGUITextXpath(String value) throws Exception {
		String guiValue = null;
		try {
			WebElement ele;
			ele = driver.findElement(By.xpath(value));
			HighlightElement(ele);
			guiValue = ele.getText();
			Thread.sleep(1000);
			if (guiValue.equalsIgnoreCase("")) {
				guiValue = ele.getAttribute("value");
			}
		} catch (Exception e) {
			LOG.info("--No Such Element Found--");
		}
		return guiValue;
	}

	/**
	 *
	 * @param intSec
	 * @param strXpath
	 * @param sEventName
	 * @return
	 * @throws Exception
	 */
	public boolean fnWaitForObjectExist(int intSec, String strXpath, String sEventName) throws Exception {
		boolean result = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, intSec); // 306
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(strXpath)));
			result = true;
			if (driver.findElement(By.xpath(strXpath)).isDisplayed()) {
				HighlightElement(driver.findElement(By.xpath(strXpath)));
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
						"'" + sEventName + "' displayed", "Pass");
				result = true;
			}
		} catch (Exception e) {
			obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
					"'" + sEventName + "' not displayed", "Fail");
			DriverScript.log.info(
					sEventName + " is not visible on the screen.. Test execution waited for " + intSec + " seconds.");
			throw (e);
		}
		return result;
	}

	/**
	 *
	 * @param intSec
	 * @param strXpath
	 * @param sEventName
	 * @throws Exception
	 */
	public void fnWaitForObjectExistXpath(int intSec, String strXpath, String sEventName) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver, intSec); // 306
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(strXpath)));
			if (driver.findElement(By.xpath(strXpath)).isDisplayed()) {
				HighlightElement(driver.findElement(By.xpath(strXpath)));
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
						"'" + sEventName + "' displayed", "Pass");
			}
		} catch (Exception e) {
			obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
					"'" + sEventName + "' not displayed", "Fail");
			DriverScript.log.info(
					sEventName + " is not visible on the screen.. Test execution waited for " + intSec + " seconds.");
			throw (e);
		}
	}

	/**
	 *
	 * @param intSec
	 * @param strXpath
	 * @param sEventName
	 * @throws Exception
	 */
	public void fnWaitForObjectNotExistXpath(int intSec, String strXpath, String sEventName) throws Exception {
		try {
			if (driver.findElement(By.xpath(strXpath)).isDisplayed()) {
				HighlightElement(driver.findElement(By.xpath(strXpath)));
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should not be displayed",
						"'" + sEventName + "' displayed", "Fail");
			}
		} catch (Exception e) {
			obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should not be displayed",
					"'" + sEventName + "' not displayed", "Pass");
			DriverScript.log.info(
					sEventName + " is not visible on the screen.. Test execution waited for " + intSec + " seconds.");
		}
	}

	/**
	 *
	 * @param intSec
	 * @param strXpath
	 * @return
	 * @throws Exception
	 */
	public boolean objectExistXpath(int intSec, String strXpath) throws Exception {
		boolean result = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, intSec); // 306
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(strXpath)));

			if (driver.findElement(By.xpath(strXpath)).isDisplayed()) {
				HighlightElement(driver.findElement(By.xpath(strXpath)));
				result = true;
			}
		} catch (Exception ignoredException) {
			// ignore
		}
		return result;
	}

	/**
	 *
	 * @param intSec
	 * @param strXpath
	 * @param sEventName
	 * @param pos
	 * @throws Exception
	 */
	public void fnWaitForObjectExistXpathCcustomize(int intSec, String strXpath, String sEventName, int pos)
			throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver, intSec); // 306
			List<WebElement> ele = driver.findElements(By.xpath(strXpath));
			WebElement element = ele.get(pos);
			wait.until(ExpectedConditions.visibilityOf(element));
			if (element.isDisplayed()) {
				HighlightElement(element);
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
						"'" + sEventName + "' displayed", "Pass");
			}
		} catch (Exception e) {
			obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
					"'" + sEventName + "' not displayed", "Fail");
			DriverScript.log.info(
					sEventName + " is not visible on the screen.. Test execution waited for " + intSec + " seconds.");
			throw (e);
		}
	}

	/**
	 *
	 * @param text1
	 * @param text2
	 * @param sEventName
	 * @throws Exception
	 */
	public void fnCompareElementsText(String text1, String text2, String sEventName) throws Exception {
		try {
			if (text1.equalsIgnoreCase(text2)) {
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
						"'" + sEventName + "' displayed", "Pass");
			} else {
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
						"'" + sEventName + "' not displayed", "Fail");
				throw new Exception("Text does not match");
			}
		} catch (Exception e) {
			DriverScript.log.info(sEventName + " is not visible on the screen..");
			throw (e);
		}
	}

	/**
	 *
	 * @param num1
	 * @param num2
	 * @param sEventName
	 * @throws Exception
	 */
	public void fnCompareElementsNumbers(int num1, int num2, String sEventName) throws Exception {
		try {
			if (num1 == num2) {
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
						"'" + sEventName + "' displayed", "Pass");
			} else {
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
						"'" + sEventName + "' not displayed", "Fail");
				throw new Exception("Text does not match");
			}
		} catch (Exception e) {
			DriverScript.log.info(sEventName + " is not visible on the screen..");
			throw (e);
		}
	}

	/**
	 *
	 * @param text1
	 * @param text2
	 * @param sEventName
	 * @throws Exception
	 */
	public void fnCompareElementsContainsText(String text1, String text2, String sEventName) throws Exception {
		try {
			if (text1.contains(text2)) {
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
						"'" + sEventName + "' displayed", "Pass");
			} else {
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
						"'" + sEventName + "' not displayed", "Fail");
				throw new Exception("Text does not match");
			}
		} catch (Exception e) {

			DriverScript.log.info(sEventName + " is not visible on the screen..");
			throw (e);
		}
	}

	/**
	 *
	 * @param intSec
	 * @param ID
	 * @param sEventName
	 * @throws Exception
	 */
	public void fnWaitForObjectExistId(int intSec, String ID, String sEventName) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver, intSec); // 306
			wait.until(ExpectedConditions.elementToBeClickable(By.id(ID)));

			if (driver.findElement(By.id(ID)).isDisplayed()) {
				HighlightElement(driver.findElement(By.id(ID)));
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
						"'" + sEventName + "' displayed", "Pass");
			}
		} catch (Exception e) {
			DriverScript.log.info(
					sEventName + " is not visible on the screen.. Test execution waited for " + intSec + " seconds.");
			throw (e);
		}
	}

	/**
	 *
	 * @throws Exception
	 */
	protected void fnInitializeGlobalVariables() throws Exception {
		try {

			mainStep = 0;
			subStep = 0;
			testCaseFlow = true;
			callCounts = 0;
			bGetButtonCallFlag = true;

		} catch (Exception e) {
			LOG.info("fnInitializeGlobalVariables--------------Failed");
			DriverScript.log.error("fnInitializeGlobalVariables--------------Failed", e);
		}
	}

	/**
	 *
	 * @param ColumnName
	 * @return
	 * @throws Exception
	 */
	public static String fnGetData(String columnName) throws Exception {
		String ColumnData = null;
		try {
			ColumnData = DriverScript.mEnvTestData.get(DriverScript.iTC_ID).get(columnName);
		} catch (Exception e) {

			DriverScript.log.error("fnGetData--------------Failed", e);
		}

		return ColumnData;
	}

	/**
	 *
	 * @param sxpath
	 * @param object
	 * @param text
	 * @throws Exception
	 */
	public void fnMatchText(String sxpath, String object, String text) throws Exception {
		try {
			if (driver.findElement(By.xpath(sxpath)).getText().contentEquals(text)) {
				obj.repAddData("" + object + " text verification", "" + object + " text should be found be verified",
						"" + object + " text is verified as '" + text + "'", "Pass");
			} else {
				obj.repAddData("" + object + " text verification", "" + object + " text should be found be verified",
						"" + object + " text is not verified as '" + text + "'", "Fail");
			}
		} catch (Exception e) {
			LOG.info("History Transaction Verifiation --------------Failed");

		}
	}

	/**
	 *
	 * @param xpath
	 */
	public void fnScrolltoelement(String xpath) {
		try {
			Thread.sleep(3000);
			WebElement element = driver.findElement(By.xpath(xpath));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
		} catch (Exception e) {
			DriverScript.log.error("fnScrolltoelement--------------Failed", e);
		}

	}

	/**
	 *
	 * @param lCOBCoverageType
	 * @param sDropDownField
	 * @param sDropDownButton
	 * @param faceValue
	 * @throws Exception
	 */
	public void fnCompareListVsComboBoxXpath(String[] lCOBCoverageType, String sDropDownField, String sDropDownButton,
			String faceValue) throws Exception {
		String valueTOCheck;
		valueTOCheck = "";
		try {
			WebElement ele = driver.findElement(By.xpath(sDropDownField));
			WebElement ele2 = driver.findElement(By.xpath(sDropDownButton));
			Thread.sleep(3000);
			HighlightElement(ele);
			ele.clear();
			ele.sendKeys("\u0008");
			Thread.sleep(500);
			ele2.click();
			Thread.sleep(3000);
			ele.sendKeys("\u0008");
			ele.sendKeys(Keys.DOWN);
			for (String s : lCOBCoverageType) {
				valueTOCheck = s;
				if (objectExistXpath(10, "//span[text()='" + valueTOCheck + "']") == false) {
					obj.repAddData("Check for '" + faceValue + "'",
							"'" + faceValue + "' '" + valueTOCheck + "' Should be present",
							"'" + faceValue + "' is not present", "Fail");
				} else {
					obj.repAddData("Check for '" + faceValue + "'",
							"'" + faceValue + "' '" + valueTOCheck + "' Should be present",
							"'" + faceValue + "' is present", "Pass");
				}

			}
		} catch (Exception e) {
			DriverScript.log.error("fnCompareListVsComboBoxXpath--------------Failed", e);
			obj.repAddData("Check for '" + faceValue + "'",
					"'" + faceValue + "' '" + valueTOCheck + "' Should be present",
					"'" + faceValue + "' is not present", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param ilength
	 * @param value
	 * @param faceValue
	 * @throws Exception
	 */
	public void fnCheckLengthXpath(int ilength, String value, String faceValue) throws Exception {
		try {

			Thread.sleep(3000);
			WebElement ele = driver.findElement(By.xpath(value));
			HighlightElement(ele);
			ele.clear();
			ele.sendKeys(new String(new char[ilength + 1]).replace("\0", "1"));
			Thread.sleep(500);

			if (fnGetGUITextXpath(value).length() == ilength) {
				obj.repAddData("Check length of '" + faceValue + "'",
						"'" + faceValue + "' length is equal to " + ilength,
						"'" + faceValue + "' length is as expected", "Pass");
			} else {
				obj.repAddData("Check length of '" + faceValue + "'",
						"'" + faceValue + "' length is equal to " + ilength,
						"'" + faceValue + "' length is as expected", "Fail");
			}
			ele.clear();
		} catch (Exception e) {
			LOG.info("--No Such Element Found--");
			obj.repAddData("Check length of '" + faceValue + "'", "'" + faceValue + "' length is equal to " + ilength,
					"'" + faceValue + "' length is as expected", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param intSec
	 * @param strXpath
	 * @return
	 * @throws Exception
	 */
	public boolean objectPresentXpath(int intSec, String strXpath) throws Exception {
		boolean result = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, intSec); // 306
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(strXpath)));
			HighlightElement(driver.findElement(By.xpath(strXpath)));
			Thread.sleep(500);
			result = true;

		} catch (Exception e) {
			result = false;
		}

		return result;
	}

	/**
	 *
	 * @param intSec
	 * @param strXpath
	 * @param sEventName
	 * @return
	 * @throws Exception
	 */
	public boolean fnObjectPresentXpath(int intSec, String strXpath, String sEventName) throws Exception {
		boolean result = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, intSec); // 306
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(strXpath)));
			HighlightElement(driver.findElement(By.xpath(strXpath)));
			Thread.sleep(500);
			result = true;
			obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
					"'" + sEventName + "' displayed", "Pass");

		} catch (Exception e) {
			result = false;
			obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be displayed",
					"'" + sEventName + "' not displayed", "Fail");
		}

		return result;
	}

	/**
	 *
	 * @param bVal
	 * @param value
	 * @param faceValue
	 * @throws Exception
	 */
	public void fnChkClickByXpath(Boolean bVal, String value, String faceValue) throws Exception {
		try {
			Thread.sleep(3000);
			WebElement ele;
			ele = driver.findElement(By.xpath(value));
			HighlightElement(ele);
			boolean beleState = ele.isSelected();
			if (bVal && !beleState) {
				ele.click();
			}
			if (!bVal && beleState) {
				ele.click();
			}
			Thread.sleep(500);
			if (bVal) {
				obj.repAddData("Select '" + faceValue + "'", "'" + faceValue + "' should be Selected",
						"'" + faceValue + "' is Selected", "Pass");
			} else {
				obj.repAddData("Un Select '" + faceValue + "'", "'" + faceValue + "' should be UnChecked",
						"'" + faceValue + "' is UnChecked", "Pass");
			}
		} catch (Exception e) {
			LOG.info("--No Such Element Found--");
			if (bVal) {
				obj.repAddData("Select '" + faceValue + "'", "'" + faceValue + "' should be Selected",
						"'" + faceValue + "' is Selected", "Fail");
			} else {
				obj.repAddData("Un Select '" + faceValue + "'", "'" + faceValue + "' should be UnChecked",
						"'" + faceValue + "' is UnChecked", "Fail");
			}
			throw (e);
		}
	}

	/**
	 *
	 * @param intSec
	 * @param strXpath
	 * @return
	 * @throws Exception
	 */
	public int getCountXpath(int intSec, String strXpath) throws Exception {
		try {
			List<WebElement> elementList = driver.findElements(By.xpath(strXpath));
			count = elementList.size();
		} catch (Exception e) {
			LOG.info("--No Such Element Found--");
		}
		return count;
	}

	/**
	 *
	 * @param value
	 * @param faceValue
	 * @throws Exception
	 */
	public void fnChkSelectedByXpath(String value, String faceValue) throws Exception {
		try {
			Thread.sleep(3000);
			WebElement ele;
			ele = driver.findElement(By.xpath(value));
			HighlightElement(ele);
			boolean beleState = ele.isSelected();
			if (beleState) {
				obj.repAddData("Check '" + faceValue + "'", "'" + faceValue + "' should be Checked",
						"'" + faceValue + "' is Selected", "Pass");
			} else {
				obj.repAddData("Check '" + faceValue + "'", "'" + faceValue + "' should be Checked",
						"'" + faceValue + "' is UnChecked", "Fail");
			}

		} catch (Exception e) {
			LOG.info("--No Such Element Found--");
			obj.repAddData("Check '" + faceValue + "'", "'" + faceValue + "' should be Checked",
					"'" + faceValue + "' is UnChecked", "Fail");
			throw (e);
		}
	}

	/**
	 *
	 * @param intSec
	 * @param strXpath
	 * @param sEventName
	 * @return
	 * @throws Exception
	 */
	public boolean fnIsDisabled(int intSec, String strXpath, String sEventName) throws Exception {
		boolean result = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, intSec); // 306
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(strXpath)));
			WebElement ele = driver.findElement(By.xpath(strXpath));
			if (!ele.isEnabled()) {
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be disabled",
						"'" + sEventName + "' disabled", "Pass");

			} else {
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be disabled",
						"'" + sEventName + "' not disabled", "Fail");
			}
			HighlightElement(driver.findElement(By.xpath(strXpath)));
			Thread.sleep(500);
			result = true;

		} catch (Exception e) {
			result = false;
			obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be disabled",
					"'" + sEventName + "' not disabled", "Fail");
		}

		return result;
	}

	/**
	 *
	 * @param intSec
	 * @param strXpath
	 * @param sEventName
	 * @return
	 * @throws Exception
	 */
	public boolean fnIsEnabled(int intSec, String strXpath, String sEventName) throws Exception {
		boolean result;
		try {
			WebDriverWait wait = new WebDriverWait(driver, intSec); // 306
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(strXpath)));
			WebElement ele = driver.findElement(By.xpath(strXpath));
			if (ele.isEnabled()) {
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be enabled",
						"'" + sEventName + "' enabled", "Pass");

			} else {
				obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be enabled",
						"'" + sEventName + "' not enabled", "Fail");
			}
			HighlightElement(driver.findElement(By.xpath(strXpath)));
			Thread.sleep(500);
			result = true;
		} catch (Exception e) {
			result = false;
			obj.repAddData("Wait for '" + sEventName + "'", "'" + sEventName + "' should be enabled",
					"'" + sEventName + "' not enabled", "Fail");
		}

		return result;
	}

	/**
	 *
	 * @param Xpath
	 * @param field
	 * @throws Exception
	 */
	public void clearFieldByXpath(String Xpath, String field) throws Exception {
		try {
			Thread.sleep(3000);
			WebElement ele = driver.findElement(By.xpath(Xpath));
			HighlightElement(ele);
			ele.clear();
			Thread.sleep(500);
			obj.repAddData("Clear " + field, " should be blank" + field, " cleared" + field, "Pass");
		} catch (Exception e) {
			LOG.info("--No Such Element Found--");
			obj.repAddData("Clear " + field, " should be blank" + field, " not cleared" + field, "Fail");

		}
	}

	// To verify the date format to be in MM/DD/YYYY for any date field
	public boolean verifyDateFormat(String xpath, String format, String sEventName) throws Exception {

		boolean returnresult = true;

		try {

			String displayDate = getTextbyXpath(xpath, " Display date");

			SimpleDateFormat dateFormat = new SimpleDateFormat(format);

			Date parsedisplayDate = null;

			// Now parse the displayDate
			parsedisplayDate = dateFormat.parse(displayDate);

			String finalFormattedDate = dateFormat.format(parsedisplayDate);

			// Print the Date

			LOG.info("Parsed date is " + parsedisplayDate);

			LOG.info("Final date after Formatting is   " + finalFormattedDate);

			fnCompareElementsText(displayDate, finalFormattedDate, " Matching  date format of " + sEventName);

		} catch (Exception e) {
			DriverScript.log.info(e);
			obj.repAddData("Date format for " + sEventName, " should be mm/dd/yyyy but " + sEventName,
					" is not in the expected format ", "Fail");
			returnresult = false;
		}

		return returnresult;

	}

	// To handle the confirmation popu up window for any Delete action
	public boolean confirmDeleteAction(String xpath, String name, String sEventName) {

		boolean returnresult = true;

		try {
			clickByXpath(xpath, sEventName);

			try {
				// Handle the alert pop-up using seithTO alert statement
				Alert alert = driver.switchTo().alert();

				// Print alert is present
				LOG.info("Alert is present");

				// Click on OK button on pop-up
				alert.dismiss();
			} catch (NoAlertPresentException e) {

				// if alert is not present print message
				LOG.info("alert is not present");

			}

			clickByXpath(xpath, sEventName);

			try {
				// Handle the alert pop-up using seithTO alert statement
				Alert alert = driver.switchTo().alert();

				// Print alert is present
				LOG.info("Alert is present");

				// get the message which is present on pop-up
				String message = alert.getText();

				message = message.trim();

				String messageExpected = "Are you sure you want to delete this document?";

				messageExpected = messageExpected.trim();

				LOG.info(message);

				LOG.info(messageExpected);
				try {

					fnCompareElementsText(message, messageExpected, " Matching  text of delete  ");

				} catch (Exception e) {

					DriverScript.log.info(e);
				}

				// Click on OK button on pop-up
				alert.accept();

			} catch (NoAlertPresentException e) {

				// if alert is not present print message
				LOG.info("alert is not present");

			}

			LOG.info("The  Deleted item is  " + name);

		} catch (Exception e) {

			DriverScript.log.info(e);
			returnresult = false;
		}

		return returnresult;

	}

	public boolean fnValidateToolTip(String xpath, String expMessage) {

		boolean returnresult = true;

		try {

			// Create action class object
			Actions hover = new Actions(driver);
			// find the tool-tip xpath
			WebElement run = driver.findElement(By.xpath(xpath));

			// Mouse hover to that text message
			hover.moveToElement(run).perform();

			// Extract text from tool-tip
			String actltoolTipMsg = run.getAttribute("title");

			// Print the tool-tip message just for our references
			LOG.info("Tooltip/ Help message is " + actltoolTipMsg);

			fnCompareElementsText(expMessage, actltoolTipMsg, "Matching text of " + expMessage + "  tooltip ");

		} catch (Exception e) {

			DriverScript.log.info(e);
			returnresult = false;
		}

		return returnresult;

	}

	public void fnMathichItemPerPageCountWithPageRowCount() {

		try {
			fnWaitForObjectExist(20, Admin.pageRowCountXpath, " Total rows");
			count1 = getCountXpath(10, Admin.pageRowCountXpath);
			String rowCount1 = String.valueOf(count1);
			System.out.println("The totla count is" + rowCount1);
			String listCount = getTextbyXpath(Admin.splitItemXpath, " List Count");
			String[] split = listCount.split(" ");
			String rowCount2 = split[2];
			System.out.println("The totla count is" + count);
			fnCompareElementsText(rowCount1, rowCount2, "Matching count");

		} catch (Exception e) {
			DriverScript.log.info(e);

		}

	}

	public boolean selectAnyItemFromDrpDwn(String sDropDownName) throws Exception {

		boolean returnresult = true;

		try {
		
			int countItems = getCountXpath(30, MedicalRecords.Valuesinitdrpdwn_xpath);

			int randItemSelected = fnRandomNum(countItems);

			clickByXpathCustomize(MedicalRecords.Valuesinitdrpdwn_xpath, "Random Item", randItemSelected);

		} catch (Exception e) {

			DriverScript.log.info(e);
			returnresult = false;
		}
		return returnresult;

	}

}