package com.mhplan.qms.UtilManager;

public class SQLMap {
	
	public String Memberid;
	
	public String getMemberid() {
		return Memberid;
	}

	public String setMemberid(String memberid) {
		return Memberid = memberid;
	}

public String AudTaskid;
	
	public String getaudTaskid() {
		return AudTaskid;
	}

	public String setaudTaskid(String audTaskid) {
		return AudTaskid = audTaskid;
	}

public String AudGenName;
	
	public String getaudGeneratorName() {
		return AudGenName;
	}

	public String setaudGeneratorName(String audGenName) {
		return AudGenName = audGenName;
	}

///////////////////////////////////////////
//////Provider Id//////////////////////////
	private String providerId;
	
	public String getProviderId() {
		return providerId;
	}

	public String setProviderId(String providerId) {
		return this.providerId = providerId;
	}

	
	
///////////////////////////////////////////
//////Location Id//////////////////////////
private String locationId;

public String getLocationId() {
return locationId;
}

public String setLocationId(String locationId) {
return this.locationId = locationId;
}


///////////////////////////////////////////
//////Med_Rec initiative name /////////////
private String medRecInitiativeName;

public String getmedRecInitiativeName() {
return medRecInitiativeName;
}

public String setmedRecInitiativeName(String medRecInitiativeName) {
return this.medRecInitiativeName = medRecInitiativeName;
}



}
