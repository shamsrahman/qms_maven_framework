
package com.mhplan.qms.module.functionalflow;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import com.mhplan.qms.DriverScript;
import com.mhplan.qms.ObjectRepository.Admin;



public class TestAdminDocument extends DriverScript {
    testAdminMeasureElement TAME = new testAdminMeasureElement();
	public static String user;
	Random rand = new Random();
	int j = rand.nextInt(10000);
    public static String username;
    public static String description;
	public boolean AddDocument(){

		boolean returnresult = true;
		

		try {
			    obj.repAddData("Add Document", "", "", "");
			     DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
				LocalDate localDate = LocalDate.now();
				 username = "Mohammed_test " + j;
				 description = "Test Description " + j;
			    clickByXpath(Admin.buttonAdminXpath,"Admin button");
			    fnWaitForObjectExist(20, Admin.buttonRefDataXpath,"Reference Data");
			    clickByXpath(Admin.buttonRefDataXpath,"reference data");
			    clickByXpath(Admin.Documents_Admin_xpath,"document button");
			    sorting();
			    fnMathichItemPerPageCountWithPageRowCount();
			    String docNameHeader = getTextbyXpath(Admin.document_header_name," Document name header");
			    fnCompareElementsText(docNameHeader,"Code","Matching document name");
			    String docDescriptionHeader = getTextbyXpath(Admin.document_header_desc," Document Description header");
			    fnCompareElementsText(docDescriptionHeader,"Description","Matching document description");
			    String docStatusHeader = getTextbyXpath(Admin.document_header_status," Document Status header");
			    fnCompareElementsText(docStatusHeader,"Status","Matching document status");
			    doubleClickByXpath(Admin.filter_text,"Filter field");
			    clickByXpath(Admin.button_Add_document,"Add document button");
			    fnWaitForObjectExist(30, Admin.headingNewDocTypeXpath,"Heading New Document Type");
				sendKeyByXpath(Admin.field_document_name,username,"Name");
				sendKeyByXpath(Admin.field_document_description,description,"Entering description");
				fnWaitForObjectExist(20, Admin.chkbox_date_required,"Check box");
				clickByXpathJS(Admin.chkbox_date_required ,"Date required check box",0);
				sendKeyByXpath(Admin.field_date_val_expression ,(dtf.format(localDate)),"Entering date");
				clickByXpath(Admin.button_add,"add button");
				fnWaitForObjectExist(30, Admin.msgDocTypeCreatdXpath,"  Document Type created message");
				filtering();
			    TAME.active();
			   


		}catch(Exception e) {
			closedocumentdialog();
			DriverScript.log.info(e);
			returnresult=false;
		}

try {
	clickByXpath(Admin.SwitchApplications_Admin_XPATH,"Switch Application");
}
	   catch(Exception e) {
		DriverScript.log.info(e);
		
	}	
		return returnresult;
		
}
	
	
	
	public boolean closedocumentdialog(){
		boolean returnresult = true;
		try {
			
			if (fnWaitForObjectExist (30,Admin.title_doc_dialog_XPATH , "Document dialog"))
				clickByXpathJS(Admin.button_cancel,"cancel button",0);
			  	
		}catch(Exception e) {
			DriverScript.log.info(e);
			returnresult=false;
		}
		return returnresult;
	}
	
	
	public boolean sorting(){
		boolean returnresult = true;
		try {
			
			fnWaitForObjectExistXpath(15,Admin.sortAscorderXpath,"Code Ascending Order");
			clickByXpath(Admin.document_header_name," Code Header");
			fnObjectPresentXpath(15,Admin.sortDescndorderXpath," Code Descending Order");
		    
		    clickByXpath(Admin.document_header_desc," Description Header");
			fnWaitForObjectExistXpath(15,Admin.sortAscorderXpath,"Description Ascending Order");
			clickByXpath(Admin.document_header_desc," Description Header");
			fnObjectPresentXpath(15,Admin.sortDescndorderXpath," Description Descending Order");
			
			clickByXpath(Admin.headerDateValidationExpressionXpath, " Date Validation Expression Header");
			fnWaitForObjectExistXpath(15, Admin.sortAscorderXpath, "Date Validation Expression Ascending Order");
			clickByXpath(Admin.headerDateValidationExpressionXpath, " Date Validation Expression Header");
			fnObjectPresentXpath(15, Admin.sortDescndorderXpath, " Date Validation Expression Descending Order");
			
			clickByXpath(Admin.document_header_status, " Status Header");
			fnWaitForObjectExistXpath(15, Admin.sortAscorderXpath, "Status Ascending Order");
			clickByXpath(Admin.document_header_status, " Status Header");
			fnObjectPresentXpath(15, Admin.sortDescndorderXpath, " Status Descending Order");
		    
		}catch(Exception e) {
			DriverScript.log.info(e);
			returnresult=false;
		}
		return returnresult;
	}
	
	
	public boolean filtering(){
		boolean returnresult = true;
		try {
			
		    sendKeyByXpath(Admin.filter_text,description," Document Description");
		    String doc = getTextbyXpath(Admin.documentDescriptionXpath," Document description");
		    fnCompareElementsText(doc,description,"Matching document description");
		    
		    sendKeyByXpath(Admin.filter_text,"N/A"," Date Validation Expression");
		    String dateValExpresn = getTextbyXpath(Admin.documentDateValiExprssnXpath," Date Validation Expression");
		    fnCompareElementsText(dateValExpresn,"N/A","Matching Date Validation Expression");
		    
		    sendKeyByXpath(Admin.filter_text,username," Document Name");
		    String adminDocument = getTextbyXpath(Admin.document_created_row_xpath," Document name");
		    fnCompareElementsText(adminDocument,username,"Matching document name");
		    
		}catch(Exception e) {
			DriverScript.log.info(e);
			returnresult=false;
		}
		return returnresult;
	}
	
	
	
	
	

}


	





