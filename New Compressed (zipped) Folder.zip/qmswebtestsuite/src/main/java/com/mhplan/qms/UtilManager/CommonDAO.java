package com.mhplan.qms.UtilManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mhplan.qms.DriverScript;

public class CommonDAO extends DriverScript {

	public final String ProviderId_query = "select distinct a.orgpractnrid as ProviderId from qms_medrecord.practnr as a join qms_medrecord.practnrsite as b On(B.orgsk =A.orgsk  and a.practnrsk = b.practnrsk ) join qms_medrecord.siteaddr as C on( B.orgsk =C.orgsk and b.siteaddrsk = C.siteaddrsk and c.st = 'MI') join qms_medrecord.lobtype as d on d.lobtypesk = b.lobtypesk   where a.orgpractnrid not in ( select orgpractnrid  from qms_medrecord.practnr as a join qms_medrecord.practnrsite as b on (B.orgsk =A.orgsk and a.practnrsk = b.practnrsk) join qms_medrecord.siteaddr as C on( B.orgsk =C.orgsk and b.siteaddrsk = C.siteaddrsk) join qms_medrecord.lobtype as d on  d.lobtypesk = b.lobtypesk join qms_medrecord.suplrpractnrsite as sps on sps.practnrsitesk = b.practnrsitesk join qms.qms_medrecord.suplr as splr on splr.suplrsk = sps.suplrsk)order by a.orgpractnrid desc limit 1";
	public final String LocationId_query = "select distinct  C.orgsiteaddrid as LocationId from qms_medrecord.practnr as a join qms_medrecord.practnrsite as b on (B.orgsk =A.orgsk and a.practnrsk = b.practnrsk) join qms_medrecord.siteaddr as C on( b.orgsk =C.orgsk and b.siteaddrsk = C.siteaddrsk and c.st = 'MI') join qms_medrecord.lobtype as d on d.lobtypesk = b.lobtypesk where C.orgsiteaddrid  not in ( select orgsiteaddrid from qms_medrecord.practnr as a join qms_medrecord.practnrsite as b on(B.orgsk =A.orgsk and a.practnrsk = b.practnrsk) join qms_medrecord.siteaddr as C on( a.orgsk =C.orgsk and b.siteaddrsk = C.siteaddrsk) join qms_medrecord.lobtype as d on d.lobtypesk = b.lobtypesk join qms_medrecord.suplrpractnrsite as sps on sps.practnrsitesk = b.practnrsitesk join qms.qms_medrecord.suplr as splr on splr.suplrsk = sps.suplrsk) order by C.orgsiteaddrid  limit 1";
	public final String MedRecInitiaitive_query = "SELECT  a.initiativename as MedRecInitiativeName FROM qms_medrecord.initiative as a join qms_medrecord.initiativetype as b on a.initiativetypesk = b.initiativetypesk join qms_medrecord.initiativefunctypeinitiativetype as c on c.initiativetypesk = b.initiativetypesk join qms_medrecord.initiativefunctype as d on d.initiativefunctypesk = c.initiativefunctypesk where a.recstat = 'A'and d.initiativefunctypecode = 'MED_REC' order by random() limit 1";
	public List<SQLMap> getPPCMember(String URL, String sql, String db_username, String db_password) {
		List<SQLMap> results = new ArrayList<SQLMap>();

		try (Connection connection = DBConnection.getConnection(URL, db_username, db_password)) {

			if (connection != null) {
				obj.repAdddbData("Database Conectivity", "Database should be Connected Successfully",
						"Database Connection Success", "Pass");

			} else {

				obj.repAdddbData("Database Conectivity", "Database should be Connected Successfully",
						"Database Connection Failed", "Fail");
			}

			try (PreparedStatement stmt = connection.prepareStatement(sql)) {
				try (ResultSet rs = stmt.executeQuery()) {

					while (rs.next()) {
						SQLMap vReq = new SQLMap();
						vReq.setMemberid(rs.getString("orgindvid"));
						results.add(vReq);

					}
				}
			}
		} catch (Exception e)

		{

		}

		return results;

	}

	public List<SQLMap> getAuditTaskDetails(String URL, String sql, String db_username, String db_password) {
		List<SQLMap> results = new ArrayList<SQLMap>();

		try (Connection connection = DBConnection.getConnection(URL, db_username, db_password)) {
			if (connection != null) {
				obj.repAdddbData("Database Conectivity", "Database should be Connected Successfully",
						"Database Connection Success", "Pass");
			} else {
				obj.repAdddbData("Database Conectivity", "Database should be Connected Successfully",
						"Database Connection Failed", "Fail");
			}
			try (PreparedStatement stmt = connection.prepareStatement(sql)) {
				try (ResultSet rs = stmt.executeQuery()) {
					while (rs.next()) {
						SQLMap vReq = new SQLMap();
						vReq.setaudTaskid(rs.getString("audtasksk"));
						vReq.setaudGeneratorName(rs.getString("audconfgname"));
						results.add(vReq);
					}
				}
			}
		} catch (Exception e) {
			// do something with it
		}
		return results;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public List<SQLMap> getProviderId(String URL, String sql, String db_username, String db_password) {
		List<SQLMap> results = new ArrayList<SQLMap>();

		try (Connection connection = DBConnection.getConnection(URL, db_username, db_password)) {
			if (connection != null) {
				obj.repAdddbData("Database Conectivity", "Database should be Connected Successfully",
						"Database Connection Success", "Pass");
			} else {
				obj.repAdddbData("Database Conectivity", "Database should be Connected Successfully",
						"Database Connection Failed", "Fail");
			}
			try (PreparedStatement stmt = connection.prepareStatement(sql)) {
				try (ResultSet rs = stmt.executeQuery()) {
					while (rs.next()) {
						SQLMap vReq = new SQLMap();
						vReq.setProviderId(rs.getString("ProviderId"));
						results.add(vReq);
					}
				}
			}
		} catch (Exception e) {
			// do something with it
		}
		return results;
	}
	
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public List<SQLMap> getLocationId(String URL, String sql, String db_username, String db_password) {
		List<SQLMap> results = new ArrayList<SQLMap>();

		try (Connection connection = DBConnection.getConnection(URL, db_username, db_password)) {
			if (connection != null) {
				obj.repAdddbData("Database Conectivity", "Database should be Connected Successfully",
						"Database Connection Success", "Pass");
			} else {
				obj.repAdddbData("Database Conectivity", "Database should be Connected Successfully",
						"Database Connection Failed", "Fail");
			}
			try (PreparedStatement stmt = connection.prepareStatement(sql)) {
				try (ResultSet rs = stmt.executeQuery()) {
					while (rs.next()) {
						SQLMap vReq = new SQLMap();
						vReq.setLocationId(rs.getString("LocationId"));
						results.add(vReq);
					}
				}
			}
		} catch (Exception e) {
			// do something with it
		}
		return results;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // To get the initiative name where initiative type is Med_Rec to create a Audit Generator.
	public List<SQLMap> getMedRecInitiativeName(String URL, String sql, String db_username, String db_password) {
		List<SQLMap> results = new ArrayList<SQLMap>();

		try (Connection connection = DBConnection.getConnection(URL, db_username, db_password)) {
			if (connection != null) {
				obj.repAdddbData("Database Conectivity", "Database should be Connected Successfully",
						"Database Connection Success", "Pass");
			} else {
				obj.repAdddbData("Database Conectivity", "Database should be Connected Successfully",
						"Database Connection Failed", "Fail");
			}
			try (PreparedStatement stmt = connection.prepareStatement(sql)) {
				try (ResultSet rs = stmt.executeQuery()) {
					while (rs.next()) {
						SQLMap vReq = new SQLMap();
						vReq.setmedRecInitiativeName(rs.getString("MedRecInitiativeName"));
						results.add(vReq);
					}
				}
			}
		} catch (Exception e) {
			// do something with it
		}
		return results;
	}
	
}
