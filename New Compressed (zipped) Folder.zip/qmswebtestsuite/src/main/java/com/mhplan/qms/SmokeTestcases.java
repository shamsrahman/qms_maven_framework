package com.mhplan.qms;


import com.mhplan.qms.reportmanager.PrepareReport;

public class SmokeTestcases extends DriverScript {

	
	public Boolean bLoginFlag=true;


	//Member Search

	public PrepareReport fn1001(PrepareReport obj) throws Exception
	{
		
	Boolean bdocFlag = true;


	log.info("Executing function to search for a member started.....");

	header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

	try {


		if (driver == null) {
			bLoginFlag = fnLoginAttempt();

		}
		
		obj.repAddData("Test Result", "", "", "");
		if (bdocFlag) {
			obj.repAddData("Verify Application", "QMS Application verified successfully", "Verifying Application Success", "Pass");
			PrepareReport.totalPass++;
		}else {
			obj.repAddData("Verify Application", "QMS Application verified successfully", "Verifying Application Failed", "Fail");
			PrepareReport.totalFail++;
		}
	}catch (Exception e) {
		e.printStackTrace();
		testCaseFlow = false;
		obj.repAddData("Error handler", "There should not be any error/exception in the test", "Exception found in current test", "Fail");
		PrepareReport.totalFail++;
		log.error("Function to Verify Application Failed", e);
	}finally {

		obj.repGenerateResult(Test_Case_Name, header);
		obj.repGenerateIndexReport(indexHeader);
		obj.repGenerateIndexReportemail(indexHeader_email);
		header = null;
		log.info("Execution of Function to Verify Application Completed");
	}
	return obj;
	}






	}

