package com.mhplan.qms.ObjectRepository;

import com.mhplan.qms.module.functionalflow.ChaseRulesDelete;
import com.mhplan.qms.module.functionalflow.testCodeSet;

public class Admin {

	public static final String TableComponents_xpath = "//div[@id = 'ext-ss-idm-components-1']";
    public static final String InputUserId_Name = "username";
	public static final String InputPassword_Name = "password";
	public static final String ButtonSignIn_xpath = "/html/body/app-root/div/app-login/div/mat-card/form/div/button";
	public static final String lableLoggedinUser_xpath = "//div[@class='username']";
	public static final String ButtonTasks_xpath = "//button[@data-componentid='workqueueBtn']";
    public static final String ButtonUserSetting_xpath = "//button[@data-componentid='userSettingsBtn']";
	public static final String ButtonLogout_xpath = "//a[@data-componentid='logoutBtn']";
	public static final String ButtonLogoutYes_xpath = "//button[@data-componentid='logoutYesBtn']";
	public static final String init ="html/body/app-root/div/app-medical-records/mat-sidenav-container/mat-sidenav-content/div/div/app-medical-record-add/mat-card/mat-card-content/app-initiative-details/mat-form-field/div/div[1]/div";
	public static final String Valueinitdrpdwn_xpath ="//*[@class='mat-option-text']";
	public static final String MemberID_XPATH = "//*[@ng-reflect-placeholder='Member Id']";
	public static final String Membersearchicon_XPATH = "/html/body/app-root/div/app-medical-records/mat-sidenav-container/mat-sidenav-content/div/div/app-medical-record-add/mat-card/mat-card-content/div/div[1]/app-member-details/mat-card/mat-card-content/div/div[1]/mat-form-field/div/div[1]/div[2]/button/span/mat-icon";
	public static final String SelectMmbrr_button_XPATH = "/html/body/app-root/div/app-medical-records/mat-sidenav-container/mat-sidenav-content/div/div/app-medical-record-add/mat-card/mat-card-content/div/div[1]/app-member-details/mat-card/mat-card-content/div[1]/div[2]/button";
	public static final String RowPagination_XPATH = "//*[@class='mat-paginator']";
	public static final String ButtonNextPage_XPATH = "//button[@class='mat-paginator-navigation-next mat-icon-button']";
	public static final String RowMembers_XPATH = "//tr[@class='mat-row ng-star-inserted']";
	public static final String memberInfo_txtbox_XPATH = "//*[@ng-reflect-placeholder='Member Information']";
	public static final String memberDOBInfo_txtbox_XPATH = "";
	public static final String SearchMmber_button_XPATH = "//*[@id=\"mat-dialog-0\"]/app-member-search-dialog/form/mat-dialog-actions/button[1]";
	public static final String CancelMmber_button_XPATH = "//*[@id=\"mat-dialog-0\"]/app-member-search-dialog/form/mat-dialog-actions/button[2]";
	public static final String Memberselected_XPATH = "//*[@id=\"mat-dialog-3\"]/app-member-search-dialog/form/mat-dialog-content/div[2]/table/tbody/tr[1]/td[2]";
	public static final String FinalSearchMmbr_XPATH = "//*[@id=\"mat-dialog-0\"]/app-member-search-dialog/form/mat-dialog-actions/button[1]";
	public static final String FinalMmbrCancel_XPATH = "//*[@id=\"mat-dialog-0\"]/app-member-search-dialog/form/mat-dialog-actions/button[2]";
	public static final String ProviderID_XPATH = "//*[@id=\"mat-input-3\"]";
	public static final String SelectPrvdr_button_XPATH = "/html/body/app-root/div/app-medical-records/mat-sidenav-container/mat-sidenav-content/div/div/app-medical-record-add/mat-card/mat-card-content/div/div[2]/app-provider-details/mat-card/mat-card-content/div/div[2]/button";
	public static final String Providersearchicon_XPATH = "/html/body/app-root/div/app-medical-records/mat-sidenav-container/mat-sidenav-content/div/div/app-medical-record-add/mat-card/mat-card-content/div/div[2]/app-provider-details/mat-card/mat-card-content/div/div[1]/mat-form-field/div/div[1]/div[2]/button";
	public static final String ProviderInfo_txtbox_XPATH = "//*[@ng-reflect-placeholder='Provider Name or ID']";
	public static final String SearchProvider_button_XPATH = "//*[@id=\"mat-dialog-1\"]/app-provider-search-dialog/form/mat-dialog-actions/button[1]";
	public static final String CancelProvider_button_XPATH = "//*[@id=\"mat-dialog-8\"]/app-provider-search-dialog/form/mat-dialog-actions/button[2]";
	public static final String Providerselected_XPATH = "//*[@id=\"mat-dialog-12\"]/app-provider-search-dialog/form/mat-dialog-content/div[2]/table/tbody/tr[5]/td[2]";
	public static final String FinalSearchprvdr_XPATH = "//*[@id=\"mat-dialog-12\"]/app-provider-search-dialog/form/mat-dialog-actions/button[1]";
	public static final String Finalcancelprvdr_XPATH = "//*[@id=\"mat-dialog-12\"]/app-provider-search-dialog/form/mat-dialog-actions/button[2]";
	public static final String Location_drpdwn_XPATh = "//*[@ng-reflect-placeholder='Location']";
	public final String Save_button_XPATH="//*[@id='save']";
	public final String Cancel_button_XPATH = "/html/body/app-root/div/app-medical-records/mat-sidenav-container/mat-sidenav-content/div/div/app-medical-record-add/mat-card/mat-card-actions/button[2]";



	//=============================================================================================================================================
	//=============================================================================================================================================
	//AdminPage
	    public static final String Documents_Admin_xpath = "//a[contains(@id,'document-types')]";
	    public static final String initiativesButtonXpath = "//a[@id='initiatives']";
	    public static final String buttonRefDataXpath = "//mat-panel-title[@class='mat-expansion-panel-header-title' and contains(text(),'Reference Data')]";
	    public static final String measure_xpath = "//mat-panel-title[@class='mat-expansion-panel-header-title' and text() = ' Measures ']";
	    public static final String measure_data_xpath = "//mat-panel-title[@class='mat-expansion-panel-header-title' and text() = ' Measures ']";
	    
	    
	    
	    //////////////============================== Element Types of measures of Admin===========================================
	    public static final String elementTypesXpath="//a[@id='measure-element-types']";
	    public static final String headingPageElementtypesXpath="//mat-card-title[text()=' Element Types ']";
	    public static final String addElementTypeButtonXpath ="//button[@id='add']";
	    public static final String headingAddEleTypeXpath="//h2[text()='Add Element Type']";
	    public static final String codeXpath=" //h2[text()='Add Element Type']/following::input[@ng-reflect-placeholder='Code']";
	    public static final String descriptionXpath="//textarea[@ng-reflect-placeholder='Description']";
	    public static final String addButtonXpath="submit";
	    public static final String cancelButtonXpath="cancel";
	    public static final String elementTypeCreatedMsgXpath="//span[contains(text(),'Element type created')]";
	    public static final String filterTextFiledXpath="//input[@ng-reflect-placeholder='Filter']";
	    public static final String sortNoArrowCodeEleTypesXpath = "//th[contains(@class,'cdk-column-code')]";
	    public static final String sortAscCodeEletypesXpath = "//th[contains(@class,'cdk-column-code') and @aria-sort='ascending']";
	    public static final String sortDescCodeEletypesXpath = "//th[contains(@class,'cdk-column-code') and @aria-sort='descending']";
	    public static final String sortNoArrowDescptnEletypesXpath = "//th[contains(@class,'cdk-column-description')]";
	    public static final String sortAscDescptnEletypesXpath = "//th[contains(@class,'cdk-column-description') and @aria-sort='ascending']";
	    public static final String sortDescDescptnEletypesXpath = "//th[contains(@class,'cdk-column-description') and @aria-sort='descending']";
	    public static final String sortNoArrowSttsEletypesXpath = "//th[contains(@class,'cdk-column-status')]";
	    public static final String sortAscSttsEletypesXpath = "//th[contains(@class,'cdk-column-status') and @aria-sort='ascending']";
	    public static final String sortDescSttsEletypesXpath = "//th[contains(@class,'cdk-column-status') and @aria-sort='descending']";
	    public static final String headingUpdateElementypeXpath="//h2[contains(text(),'Update Element Type')]";
	    public static final String updatedElemenTypeMSgXpath="//span[contains(text(),'Element type updated')]";
	    public static final String editCrtdCodeXpath="(//button[@id='edit'])[1]";
	    public static final String deleteCrtdCodeXpath="(//button[@id='delete'])[1]";
	    public static final String deactedMsgXpath="//span[contains(text(),'Element type deactivated')]";
	    public static final String Update_button="submit";
	    public static final String canceleleTypeButtonXpath="cancel";
	    public static final String statusDrpDwnElemTypesXpath="//mat-select[@ng-reflect-placeholder='Status']";
	    public static final String  defaultActiveSttsXpath="//mat-select[@ng-reflect-model='A']//following::span[contains(text(),'Active')]";
	    public static final String activeSttsElemTypesXpath="//span[@class='mat-option-text' and contains(text(),'Active')]";
	    public static final String inActiveSttsElemTypesXpath="//span[@class='mat-option-text' and contains(text(),'Inactive')]";
	    public static final String inActiveRecordEleTyppesXpath="(//tr[contains(@class,'mat-row')])[1]//child::td[contains(@class,'cdk-column-code')]//following::td[contains(text(),'Inactive')]";
	    public static final String valueinCodeColumnXpath="//td[contains(@class,'cdk-column-code')]";
	 	public static final String valueinDescrptnColumnXpath= "//td[contains(@class,'cdk-column-description')]";
	    //////////////////////////////////////////////////////////////////======================================================

	    public static final String buttonAdminXpath = "//button[@id='admin']";
		public static final String button_Ref_data_XPATH = "//*[@id=\"mat-expansion-panel-header-0\"]";
		public static final String button_ChaseRULES_XPATH = "//*[@id='rules']";
		public static final String button_ChaseGENERATORS_XPATH = "//*[@ng-reflect-router-link='chase-generators']";
		public static final String Initiatives_Admin_XPATH = "//*[@id='initiatives']";
		public static final String Documents_Admin_XPATH = "//*[@id='documents']";
		public static final String Services_Admin_XPATH = "//*[@id='services']";
		public static final String Measures_Admin_XPATH = "//*[@id='measures']";
		public static final String Measures_dictionary_XPATH = "//a[@id='measure-definitions']";
		public static final String Measures_version_XPATH = "//a[@id='measure-versions']";
		public static final String measuresVersionSearchButtonXpath = "//button[@id='search-measure']";
		public static final String srvc_Mappings_Admin_XPATH = "//*[@id='service-mappings']";
		public static final String SwitchApplications_Admin_XPATH = "//*[@id='switch-applications']";
		public static final String Logout_Admin_XPATH = "/html/body/app-root/div/app-admin/mat-sidenav-container/mat-sidenav/mat-nav-list/a[2]/div";
		public static final String initial_admin_page = "//div[@ng-reflect-fx-layout-align='center']";


		
	//=============================================================================================================================================
	//=============================================================================================================================================
	//AdminInitiative


		public static final String button_Add_initiatives = "//span[@class= 'mat-button-wrapper' and contains(text(),'Add Initiative')]";
		public static final String fieldEnterInitiativeNameXpath = "//*[@id='name' and @aria-required='true']";
		public static final String fieldEnterInitiativesDescXpath = "//input[@ng-reflect-placeholder='Description' and @aria-required='true']";
		public static final String enter_start_date = "//*[@id='start-date'and @aria-required='true']";
		public static final String enter_end_date = "//*[@id='end-date'and @aria-required='true']";
		public static final String completedByDateXpath = "//input[@id='completed-by-date'and @aria-required='true']";
		public static final String Admin_ini_button_add = "//*[@id='save']";
		public static final String Admin_ini_button_cancel = "//*[@id='cancel']";
		public static final String field = "//*[@id=\"mat-dialog-1\"]";
		public static final String button_add_validation = "//*[@id='add']";
		public static final String adminIniFieldFilter = "//input[@id='filter']";
		public static final String organization_xpath = "//*[@id='organization'and @aria-required='true']";
		public static final String disableOrganizationXpath = "//input[@id='organization' and @aria-required='false']";
		public static final String organization_dd_xpath = "//span[@class='mat-option-text' and contains(text(), 'Health Plan of Michigan')]";
		public static final String initiativeTypeXpath = "//mat-select[@id='type'and @aria-required='true']";
		public static final String disableInitiativeTypeXpath = "//input[@id='initiative-type' and @aria-required='false']";
		public static final String initiativeTypeMedicalRecord = "//span[@class='mat-option-text' and contains(text(), 'Medical Record')]";
		public static final String initiativeTypeMeasure = "//span[@class='mat-option-text' and contains(text(), 'Measure')]";
		public static final String initiativeSubypeXpath = "//mat-select[@id='subtype'and @aria-required='true']";
		public static final String disableInitiativeSubypeXpath = "//input[@id='initiative-subtype'and @aria-required='false']";
		public static final String initiativSubetypeDropDownHedisXpath = "//span[@class='mat-option-text' and contains(text(), 'HEDIS')]";
		public static final String initiativSubetypeDropDownManualSupDataXpath = "//span[@class='mat-option-text' and contains(text(), 'Manual Supplemental Data')]";
		public static final String initiativSubetypeDropDownManualHedisHybridXpath = "//span[@class='mat-option-text' and contains(text(), 'HEDIS Hybrid')]";
		public static final String workFlowXpath ="//mat-select[@id='workflow']";
		public static final String disableInitiativeWorkFlowXpath ="//input[@id='initiative-workflow'and @aria-required='false']";
		public static final String workFlowDropDownValueXpath ="//span[@class='mat-option-text' and contains(text() ,' Initative (Default)')]";
		public static final String check_box ="//span[@class= 'mat-option-text']";
		public static final String dropdown_Source = "//*[@id='mat-select-4']/div/div[1]/span";
		public static final String Data_ele_check_box ="//*[@class= 'mat-option-text']";
		public static final String add_button = "//button[@id = 'submit']";
		public static final String updatInitiativePageTitleXpath = "//mat-card-title[@class='mat-card-title' and text() = ' Update Initiative ']";
	    public static final String buttonRemoveXpath ="//button[@id='cancel']";
	    public static final String item_per_page ="//div[@class='mat-paginator-page-size-label']//following::div[@class= 'mat-select-trigger']";
	    
	    public static final String groupNameXpath = "(//td[contains(@class,'cdk-column-groupName')])[1]";
	    public static final String groupTypeXpath = "(//td[contains(@class,'cdk-column-groupType')])[1]";
	    public static final String organizationTypeXpath = "(//td[contains(@class,'cdk-column-organizationName')])[1]";
	    public static final String organizationcodeXpath = "(//td[contains(@class,'cdk-column-organizationID')])[1]";
	    public static final String sourceXpath = "(//td[contains(@class,'cdk-column-source')])[1]";
	    public static final String sourceOrgCodeXpath = "(//td[contains(@class,'cdk-column-sourceOrgCode')])[1]";
	    public static final String measureStatusValueXpath = "(//td[contains(@class,'cdk-column-measureStatus ')])[1]";
	    
	    public static final String tinXpath = "(//td[contains(@class,'cdk-column-tin')])[1]";
	    public static final String contact1Xpath = "(//td[contains(@class,'cdk-column-phone')])[1]";
	    public static final String contact2Xpath = "(//td[contains(@class,'cdk-column-fax')])[1]";
	    
	    public static final String admin_ini_item_per_page_dd ="//span[@class='mat-option-text' and text() = '100']";
	    public static final String next_paginator ="(//*[@class='mat-paginator-icon'])[2]";
	    public static final String back_paginator ="(//*[@class='mat-paginator-icon'])[1]";
	    public static final String initiative_page_title = "//mat-card-title[@class = 'mat-card-title']";
	    public static final String add_validation_button = "//*[@id='add']";
	    public static final String remove_button_path = "//*[@id='remove']";
	    public static final String save_button_path = "//*[@id='save']";
	    public static final String initiativeUpdateButtonXpath = "//button[@id='submit']";
	    public static final String add_ini_page_title = "//mat-card-title[@class = 'mat-card-title']";
	    public static final String title_ini_dialog_XPATH = "//h2[@class ='mat-dialog-title' and text() = 'Add Initiative']";
	    public static final String initiative_created_row_xpath = "//td[contains(@class,'cdk-column-name')]";
	    public static final String initiativeStartDateXpath = "//input[@id = 'start-date' and @aria-required='true' ]";
	    public static final String initiativeEndDateXpath = "//input[@id = 'end-date' and @aria-required='true' ]";
	    public static final String initiativeHeaderStartDateXpath = "(//td[contains(@class,'cdk-column-startDate')])[1]";
	    public static final String initiativeHeaderEndDateXpath = "(//td[contains(@class,'cdk-column-endDate')])[1]";
	    public static final String initiative_rules= "(//*[@id='rules'])[2]";
	    public static final String ini_header_organization = "(//button[@class = 'mat-sort-header-button'])[1]";
	    public static final String ini_header_description = "(//button[@class = 'mat-sort-header-button'])[3]";
	    public static final String iniEditBtnXpath = "(//mat-icon[@role='img' and contains(text() , 'edit')])[1]";
	    public static final String iniEditBtnRandomXpath = "//mat-icon[@role='img' and text() = 'edit']";
	    public static final String initiativeDeleteButtonXpath = "(//button[@id='delete'])[1]";
	    public static final String iniHeaderTabXpath = "//div[@class = 'mat-tab-label-content' and text() = 'Header']";
	    public static final String iniFunctionTabXpath = "//div[@class = 'mat-tab-label-content' and text() = 'Functions']";
	    public static final String Ini_roles_tab = "//div[@class = 'mat-tab-label-content' and text() = 'Roles']";
	    public static final String Ini_permission_tab = "//div[@class = 'mat-tab-label-content' and text() = 'Permissions']";
	    public static final String initiative_header_name = "//button[@class = 'mat-sort-header-button' and text()= 'Name']";
		public static final String initiative_header_desc = "//button[@class = 'mat-sort-header-button' and text()= 'Description']";
		public static final String initiative_header_status = "//button[@class = 'mat-sort-header-button' and text()= 'Record Status']";
		public static final String headerWorkflowStatusXpath = "//button[@class = 'mat-sort-header-button' and contains(text(), 'Workflow Status')]";
		public static final String initiative_start_date = "//button[@class = 'mat-sort-header-button' and text()= 'Start Date']";
		public static final String initiative_end_date = "//button[@class = 'mat-sort-header-button' and text()= 'End Date']";
		public static final String statusDropDwnXpath = "//mat-select[@id='status']";
		public static final String button_add_role__xpath = "//*[@id='add']";
		public static final String drop_down_role__xpath = "//*[@id='role']";
		public static final String drop_down_group__xpath = "(//*[@id='groups'])[2]";
		public static final String button_add__xpath = "//*[@id='submit']";
		public static final String button_cancel__xpath = "//*[@id='cancel']";
		public static final String button_add_permission__xpath = "//*[@id='add']";
		public static final String drop_down_permission__xpath = "//*[@id='permission']";
		public static final String drop_down_roles__xpath = "//*[@id='roles']";
		public static final String add_role_title_dialog_xpath = "//h2[@class = 'mat-dialog-title' and text() = 'Add Role']";
		public static final String msg_roles_created = "//div[@aria-live='assertive' and contains (text(), 'Role added')]";
		public static final String msg_permission_created = "//div[@aria-live='assertive' and contains (text(), 'Permission added')]";
		public static final String User_roles_created_row_xpath = "(//td[contains(@class,'cdk-column-name')])[1]";
		public static final String Ini_admin_roles_created_row_xpath = "(//td[contains(@class,'cdk-column-name')])[2]";
        public static final String RuleNeelima93196_XPATH= "//span[@class='mat-option-text' and contains(text(),'NeelRule31')]/preceding::mat-pseudo-checkbox[@ng-reflect-state='checked'][1]";
        public static final String RuleNeelima93196_unchecked_XPATH= "//span[@class='mat-option-text' and contains(text(),'NeelRule31')]/preceding::mat-pseudo-checkbox[1]";
        public static final String Editbttnfor7690init_XPATH=" //button[@id='edit']";
        public static final String Initiativeupdatemsg_XPATH="//span[text()='Initiative updated']"; 
        public static final String grid_table_XPATH="//table[@role = 'grid']"; 
        public static final String inactiveSttsXpath="//span[@class='mat-option-text' and text()=' Inactive ']";
        public static final String ActivesttsXpath="//span[@class='mat-option-text' and text()=' Active ']";
        public static final String InactiveinitSttsValueXpath="(//td[contains(@class,'mat-column-status') and contains (text(),'Inactive')])";
        public static final String ActiveinitSttsValueXpath="//td[contains(@class,'mat-column-status') and text()='Active']";
        public static final String inactiveInitMsgXpath="//span[contains(text(),'Initiative deactivated')]";
        public static final String workflow_status1_XPATH="(//td[@role = 'gridcell' and text() = 'Not Started'])[1]";
        public static final String workflow_status2_XPATH="(//td[@role = 'gridcell' and text() = 'Completed'])[1]";
        public static final String initiativetWFSatusDropDownXpath = "//mat-select[contains(@id,'workflowStatus')]"; 
        public static final String workflow_status3_XPATH="(//td[@role = 'gridcell' and contains(text(), 'Work in Progress')])[1]";
        public static final String record_status_XPATH="(//td[@role = 'gridcell' and text() = 'Active'])[1]";
        public static final String pageRowCountXpath = "//tr[contains(@class,'mat-row' )]";
        public static final String initiativetSatusDropDownXpath = "//mat-select[@id='workflowStatus' and @aria-required='true']";
        public static final String initiativeStatusNotStartedXpath ="(//mat-select[@id='workflowStatus']//following::span[@class ='mat-option-text'])[1]";
        public static final String initiativeStatusWorkInProgressXpath ="(//mat-select[@id='workflowStatus']//following::span[@class ='mat-option-text'])[2]";
        public static final String initiativeStatusCompletedXpath ="(//mat-select[@id='workflowStatus']//following::span[@class ='mat-option-text'])[3]";
        public static final String initiativeStatusEndedXpath ="(//mat-select[@id='workflowStatus']//following::span[@class ='mat-option-text'])[4]";
        public static final String msgRecordCannotBeCreatedForNotStartedStatusXpath = "//span[text()='Record cannot be created when initiative is in status Not Started']";
        public static final String msgRecordCannotBeModifiedForNotStartedStatusXpath = "//span[text()='Record cannot be modified when initiative is in status Not Started']";
        public static final String valueFromInitDrpdwnXpath = "//span[@class='mat-option-text' and contains(text(),'MI Hybrid 2019')]";
        public static final String msgRecordCannotBeCreatedForCompletedStatusXpath = "//span[contains(text(),'Record cannot be created when initiative is in status Completed')]";
        public static final String msgRecordCannotBeCreatedForEndedStatusXpath = "//span[contains(text(),'Record cannot be created when initiative is in status Ended')]";
        public static final String msgRecordCannotBeModifiedForEndedStatusXpath = "//span[contains(text(),'Record cannot be modified when initiative is in status Ended')]";
        public static final String msgMedicalRecordUpdatedXpath = "//span[contains(text(),'Medical record updated')]";
        public static final String addFunctionButtonXpath = "//button[@id='add']";
        public static final String functionTypeDropDownXpath = "//mat-select[@id = 'function-type']";
        public static final String functionTypeDropDownRandomValueXpath = "//mat-select[@id = 'function-type']//following::span[@ng-reflect-ng-switch='false']";
        public static final String functionTypeDropDownValueXpath = "//span[@class = 'mat-option-text']";
        public static final String functionTypeDropDownValueMedRecXpath = "//span[@class = 'mat-option-text' and contains(text(),' Medical Record Service Auditing')]";
        public static final String functionTypeDropDownValueChasesXpath = "//span[@class = 'mat-option-text' and contains(text(),' Chases')]";
        public static final String workflowConfigDropDownXpath = "//mat-select[@id = 'workflow-config']";
        public static final String workflowConfigDropDownvalueMedRecXpath = "//span[@class ='mat-option-text' and contains(text(),' Medical Record Service Audit')]";
        public static final String workflowConfigDropDownvalueChaseXpath = "//span[@class ='mat-option-text' and contains(text(),' Chase')]";
        public static final String workflowConfigDropDownvalueXpath = "//span[@class ='mat-option-text']";
        public static final String dataLakeDropDownXpath = "//mat-select[@id = 'data-lake']";
        public static final String functionAddButtonXpath = "//button[@id='submit']";
        public static final String functionCancelButtonXpath = "//button[@id='cancel']";
        public static final String functionDeleteButtonXpath = "//button[@id='delete']";
        public static final String msgDeactivatedFunctionXpath = "//span[contains(text(),'Function deactivated')]";
        public static final String functionEditButtonXpath = "//button[@id='edit']";
        public static final String dialogboxfunctionTypeNameXpath = "(//p[@class = 'mat-line'])[2]";
        public static final String gridFunctionTypeNameXpath = "(//td[contains(@class,'cdk-column-function')])[1]";
        public static final String gridWorkflowConfigXpath = "(//td[contains(@class,'cdk-column-workflowConfig')])[1]";
        public static final String gridDataLakeXpath = "(//td[contains(@class,'cdk-column-dataLake')])[1]";
        public static final String functionUpdateButtonXpath = "//button[@id='submit']";
        public static final String columnFunctionXpath = "//td[contains(@class,'cdk-column-function')]";
        public static final String columnWorkflowConfigXpath = "//td[contains(@class,'cdk-column-workflowConfig')]";
        public static final String columnDataLakeXpath = "//td[contains(@class,'cdk-column-dataLake')]";
        public static final String blockedIconXpath = "//mat-icon[@role= 'img' and @aria-hidden ='true' and text() ='block']";
        public static final String titleMeasureVersionSearchDialog = "//h2[@class ='mat-dialog-title' and text() = 'Measure Version Search']";
        public static final String noMeasureVerFounMsgXpath = "//h2[@class ='mat-dialog-title' and text() = 'Measure Version Search']/following::b[contains(text(),'No Measure Versions Found')]";
        public static final String nullChecksPassedXpath = "//mat-icon[@role = 'img']//following::*[contains(text(),'null checks passed')]";
        public static final String nullChecksFailedXpath = "//mat-icon[@role = 'img']//following::*[contains(text(),'null checks failed')]";
        public static final String nullWarningXpath = "//mat-icon[@role = 'img']//following::*[contains(text(),'null warmomg')]";
        
	//=============================================================================================================================================
	//=============================================================================================================================================
	//AdminDocument
        public static final String headingNewDocTypeXpath="//h2[contains(text(),'New Document Type')]";
        public static final String headingUpdateDocTypeXpath="//h2[contains(text(),'Update Document Type')]";
        public static final String msgDocTypeCreatdXpath="//span[contains(text(),'Document Type created')]";
        public static final String msgDocTypeDeactivatedXpath="//span[contains(text(),'Document Type deactivated')]";
        public static final String button_Add_document = "//span[@class= 'mat-button-wrapper' and contains(text(),'Add Document Type')]";
		public static final String field_document_name = "//*[@id='name']";
		public static final String field_document_description = "//*[@id='description']";
		public static final String chkbox_date_required = "//span[text()='Date Required']";
		public static final String field_date_val_expression = "//*[@id='date-validation']";
		public static final String button_add = "//*[@id='add']";
		public static final String button_cancel = "//*[@id='cancel']";
		public static final String admin_doc_field_filter = "//*[@id='filter']";
	    public static final String item_per_page_drpdwn = "//*[@id='mat-select-1']/div/div[2]";
		public static final String admin_doc_item_per_page_drpdwn_list = "//*[@class=\'mat-option-text\']";
		public static final String drop_down_status = "(//div[@class = 'mat-select-value'])[1]";
		public static final String active_status = "//span[@class = 'mat-option-text' and text()= ' Active ']/preceding::mat-pseudo-checkbox[contains(@class,'mat-pseudo-checkbox-checked')]";
		public static final String inactive_status = "//span[@class = 'mat-option-text' and text()= ' Inactive ']";
		public static final String update_document = "//mat-icon[@role='img' and text() = 'edit']";
		public static final String edit_button = "//*[@id='edit']/span/mat-icon";
		public static final String update_button = "//*[@id='add']";
		public static final String active_status_path = "//*[@id=\"status\"]/div/div[1]/span/span";
		public static final String active_inactive_status_path = "//*[@id=\"status\"]/div/div[1]/span/span";
		public static final String filter_text = "//*[@id = 'filter']";
		public static final String title_doc_dialog_XPATH = "//h2[@class = 'mat-dialog-title']";
		public static final String titleUpdtDocDialogXpath = "//h2[@class = 'mat-dialog-title' and contains(text(),'Update Document Type')]";
		public static final String updated_document_row_XPATH = "//td[contains(@class,'cdk-column-code')]";
		public static final String document_created_row_xpath = "//td[contains(@class,'cdk-column-code')]";
		public static final String organizationColumnXpath = "(//td[contains(@class,'cdk-column-organization')])[1]";
		public static final String documentDescriptionXpath = "(//td[contains(@class,'cdk-column-description')])[1]";
		
		public static final String serviceTypeDescriptionXpath = "(//td[contains(@class,'cdk-column-serviceTypeDescription')])[1]";
		public static final String serviceTypeCodeXpath = "(//td[contains(@class,'cdk-column-serviceTypeCode')])[1]";
		
		public static final String documentDateValiExprssnXpath = "(//td[contains(@class,'cdk-column-dateValidationExpression')])[1]";
		
		public static final String document_header_name = "//button[@class = 'mat-sort-header-button' and text()= 'Code']";
		public static final String document_header_desc = "//button[@class = 'mat-sort-header-button' and text()= 'Description']";
		public static final String document_header_status = "//button[@class = 'mat-sort-header-button' and text()= 'Status']";
		public static final String headerOrganizationXpath = "//button[@class = 'mat-sort-header-button' and text()= 'Organization']";
		public static final String headerDateValidationExpressionXpath = "//button[@class = 'mat-sort-header-button' and contains(text(), 'Date Validation Expression')]";
		
		public static final String AddButtonDisabled_xpath =  "//span[text()=' Add ']/parent::button[@ng-reflect-disabled='true']";
		public static final String AddButtonEnabled_xpath =  "//span[text()=' Add ']/parent::button[@ng-reflect-disabled='false']";
		public static final String TitleDocument_xpath = "//mat-card-title[contains(text(),'Document Types')]";
		public static final String SortNoArrowCode_xpath = "//th[contains(@class,'mat-column-code')]";
		public static final String SortDescCode_xpath = "//th[contains(@class,'mat-column-code') and @aria-sort='descending']";
		public static final String SortAscCode_xpath = "//th[contains(@class,'mat-column-code') and @aria-sort='ascending']";
		public static final String SortNoArrowDescription_xpath = "//th[contains(@class,'mat-column-description')]";
		public static final String SortDescDescription_xpath = "//th[contains(@class,'mat-column-description') and @aria-sort='descending']";
		public static final String SortAscDescription_xpath = "//th[contains(@class,'mat-column-description') and @aria-sort='ascending']";
		public static final String SortNoArrowStatus_xpath = "//th[contains(@class,'mat-column-status')]";
		public static final String SortDescStatus_xpath = "//th[contains(@class,'mat-column-status') and @aria-sort='descending']";
		public static final String SortAscStatus_xpath = "//th[contains(@class,'mat-column-status') and @aria-sort='ascending']";
		public static final String SortNoArrowDateValidationExp_xpath = "//th[contains(@class,'mat-column-dateValidationExpression')]";
		public static final String SortDescDateValidationExp_xpath = "//th[contains(@class,'mat-column-dateValidationExpression') and @aria-sort='descending']";
		public static final String SortAscDateValidationExp_xpath = "//th[contains(@class,'mat-column-dateValidationExpression') and @aria-sort='ascending']";
		public static final String HeaderCode_xpath = "//button[text()='Code']";
		public static final String HeaderDescription_xpath = "//button[text()='Description']";
		public static final String HeaderStatus_xpath = "//button[text()='Status']";
		public static final String HeaderDateValidationExp_xpath = "//button[text()='Date Validation Expression']";
		public static final String ButtonDeletetableFirstRow_xpath = "//table/tbody/tr[1]//mat-icon[text()='delete']";
		public static final String MsgDeactivated_xpath = "//span[contains(text(),'Document Type deactivated')]";
		public static final String DropdownStatus_xpath = "//mat-select[@id='status']//following::div[@class='mat-select-arrow']";
		public static final String CheckboxInactiveStatus_xpath = "//span[text()='Active']//following::mat-pseudo-checkbox[@ng-reflect-state='checked']";
		public static final String TableRowValueStatus_xpath = "//td[@role ='gridcell' and text() = 'D']";
		public static final String TitleStatus_xpath = "//mat-select[@id='status']";
		
		public static final String headerInitiativeXpath = "//button[@class = 'mat-sort-header-button' and contains(text(),'Initiative')]";
		public static final String headerTotalChasesXpath = "//button[@class = 'mat-sort-header-button' and contains(text(),'Total Chases ')]";
		public static final String headerPopulationXpath = "//button[@class = 'mat-sort-header-button' and contains(text(),'Population')]";
		public static final String headerMeasureXpath = "//button[@class = 'mat-sort-header-button' and contains(text(),'Measure')]";
		public static final String headerVersionXpath = "//button[@class = 'mat-sort-header-button' and contains(text(),'Version')]";
		
	//=============================================================================================================================================
	//=============================================================================================================================================
	//AdminService
		public static final String headingNewSvccTypeXpath="//h2[contains(text(),'New Service Type')]";
        public static final String headingUpdateSvcTypeXpath="//h2[contains(text(),'Update Service Type')]";
		public static final String button_services = "//a[contains(@id,'service-types')]";
		public static final String button_add_service = "//*[@id='add-service']";
		public static final String field_name = "//input[@ng-reflect-placeholder ='Code']";
		public static final String field_description = "//input[@ng-reflect-placeholder ='Description']";
		public static final String dateRequiredCheckboxXpath = "//mat-checkbox[@id='date-required']";
		public static final String date_vali_expression = "//*[@ng-reflect-placeholder ='Date Validation Expression']";
		public static final String rslt_vali_expression = "//*[@ng-reflect-placeholder ='Result Validation Expression']";
		public static final String resultRequiredChkBoxXpath = "//mat-checkbox[@id='result-required']";
		public static final String dsblRsltRqrdChkboxXpaht = "//mat-checkbox[@id='result-required' and contains(@class,'mat-checkbox-disabled')]";
		public static final String fieldResulTypeXpath = "//mat-select[@id='result-type']";
		public static final String fieldDisableResulTypeXpath = "//mat-select[@id='result-type' and @aria-disabled='true']";
		public static final String resulTypeXbuttonXpath = "//mat-select[@id='result-type']//following::button[@id='clearResultTypes']";
		public static final String select_result_type_txt = "//*[@class='mat-option-text' and contains (text(), 'Text')]";
		public static final String select_result_type_nmrk = "//*[@class='mat-option-text' and contains (text(), 'Numeric')]";
		public static final String field_result_option = "//*[@ng-reflect-placeholder ='Result Options' and @ng-reflect-add-on-blur='true']";
		public static final String fieldResultUnitXpath = "//mat-select[@id='result-unit' and@ng-reflect-placeholder='Result Unit']";
		public static final String resultUnitXbuttonXpath = "//mat-select[@id='result-unit' and@ng-reflect-placeholder='Result Unit']//following::button[@id='clearResultUnits']";
		public static final String result_unit_kg ="//*[@class='mat-option-text' and contains (text(), ' /kg ')]";
		public static final String result_unit_lb ="//*[@class='mat-option-text' and contains (text(), ' lb')]";
		public static final String resultMg24hXpath ="//span[@class='mat-option-text' and contains (text(), 'mg/24h')]";
		public static final String resultG24hXpath ="//span[@class='mat-option-text' and contains (text(), 'g/24h')]";
		public static final String applicable_age_range_start = "//*[@ng-reflect-placeholder ='Applicable Age Range (Start)']";
		public static final String applicable_age_range_end = "//*[@ng-reflect-placeholder ='Applicable Age Range (End)']";
		public static final String applicable_gender = "//*[@id='gender']";
		public static final String gender_dropdown = "//*[@class='mat-option-text']";
		public static final String filter_services = "//*[@id='filter']";
		public static final String srvc_add_button = "//*[@id='add']";
		public static final String srvc_cancel_button = "//*[@id='cancel']";
		public static final String item_per_page_dd = "//*[@class='mat-select-arrow-wrapper']";
		public static final String item_per_page_default = "//*[@ng-reflect-aria-label='Items per page:']";
		public static final String item_per_page_drpdwn_list = "//*[@class='mat-option-text' and contains (text(), '100')]";
		public static final String splitItemXpath = "//div[@class='mat-paginator-range-label']";
		public static final String msg_service_created = "//div[@aria-live='assertive' and contains (text(), 'Service Type created')]";
		public static final String msg_service_updated = "//div[@aria-live='assertive' and contains (text(), 'Service Type updated')]";
		public static final String msgSvcDeactivated_xpath = "//span[contains(text(),'Service Type deactivated')]";
		public static final String adminSvcEditButtonXpath = "(//button[@id='edit'])[1]";
		public static final String admin_srvc_delete_button = "(//*[@id='delete'])[1]";
		public static final String srvc_update_button = "//*[@id='add']";
		public static final String title_admin_srvc_updt_XPATH = "//h2[@class = 'mat-dialog-title' and contains(text(),'Update Service Type')]";
		public static final String title_new_srvc_updt_XPATH = "//h2[@class = 'mat-dialog-title' and contains(text(), 'New Service Type')]";
		public static final String servicesExpansionpanelXpath = "//div[text()='Services']//following::mat-expansion-panel-header[@role = 'button' and @ aria-expanded='false']";
		
	//=============================================================================================================================================
	//=============================================================================================================================================
	//AdminServiceMapping
		
	    
		public static final String Measure = "//mat-select[@id='measure']";
		public static final String title_measure = "//mat-card-title[text()=' Measure Dictionary ']";
	    public static final String Measure_dd_list = "//*[@class='mat-option-text']";
	    public static final String version_dd_field = "//mat-select[@ng-reflect-id='version' and @id = 'version']";
	    public static final String allVersionRowsXpath = "//tr[contains(@class,'mat-row' )]//following::td[contains(@class,'cdk-column-measureVersionStatus') and text()='Active']";
	    public static final String version_2019_otober_update = "//*[@class='mat-option-text' and text() = ' 2019 October Update ']";
	    public static final String Version_dd =  "//*[@class='mat-option-text']";
	    public static final String Filterfield_avail_srvc = "//*[@id='unmapped-services-filter']";
	    public static final String Filterfield_mpd_srvc = "//*[@id='mapped-services-filter']";
	    public static final String aval_srvd_add_btn = "(//*[@id='add'])[1]";
	    public static final String aval_srvd_add_btn2 = "(//*[@id='add'])[2]";
	    public static final String mpd_srvd_rmv_btn = "//*[@id='remove']";
		public static final String service_NewMapping_field = "//*[@id=\"mat-select-5\"]/div/div[1]/span";
		public static final String BPDiastolicService = "//*[@id=\"mat-option-14\"]/span";
		public static final String Add_Button_NewMapping = "//*[@id=\"mat-dialog-0\"]/app-mapping-dialog/form/mat-dialog-actions/button[1]";
		public static final String CancelButton_NewMapping = "//*[@id=\"mat-dialog-0\"]/app-mapping-dialog/form/mat-dialog-actions/button[2]/span";
		public static final String total_row = "//*[@class='mat-paginator-range-label']";
		public static final String msg_service_mmapped = "//div[@aria-live='assertive' and text() = 'Service Type Mapped']";
		public static final String msg_service_alrd_mmapped = "//div[@aria-live='assertive' and text() = 'Service Type already mapped']";
		public static final String msg_service_unmmapped = "//div[@aria-live='assertive' and text() = 'Service Type Unmapped']";
		public static final String availableServicesHeaderCodeXpath = "//h3[contains(text(),'Mapped Services')]/preceding::button[@class='mat-sort-header-button' and contains(text(),'Code')]";
		public static final String availableServicesCodeXpath = "//td[contains(@class,'cdk-column-serviceTypeCode')]";
		public static final String availableServicesHeaderDescriptionXpath = "//h3[contains(text(),'Mapped Services')]/preceding::button[@class='mat-sort-header-button' and contains(text(),'Description')]";
		public static final String mappedServicesHeaderCodeXpath = "//h3[contains(text(),'Mapped Services')]/following::button[@class='mat-sort-header-button' and contains(text(),'Code')]";
		public static final String mappedServicesHeaderDescriptionXpath = "//h3[contains(text(),'Mapped Services')]/following::button[@class='mat-sort-header-button' and contains(text(),'Description')]";
		public static final String sortInitial2ndColXpath = "(//th[@role ='columnheader'])[2]";
		public static final String sortInitial3rdColXpath = "(//th[@role ='columnheader'])[3]";
		public static final String sortInitial4thColXpath = "(//th[@role ='columnheader'])[4]";
	//=============================================================================================================================================
	//=============================================================================================================================================
	//AdminMeasureDefinition


	    public static final String header_definition =  "(//div[@class='mat-tab-label-content'])[1]";
	    public static final String button_add_measure = "//button[@id='add']";
	    public static final String organizationCodeXpath= "//input[@ng-reflect-placeholder='Organization Code']";
	    public static final String sourceOrganizationCodeXpath= "//input[@ng-reflect-placeholder='Source Organization Code']";
	    public static final String fieldShortname=  "//input[@ng-reflect-placeholder='Short Name']";
	    public static final String fieldShordescription= "//input[@ng-reflect-placeholder='Description']";
	    public static final String fieldSource= "//mat-select[@ng-reflect-placeholder='Source']";
	    public static final String measureStatusXpath= "//mat-select[@ng-reflect-placeholder='Measure Status']";
		public static final String dropdown_list = "//*[@class='mat-option-text']";
	    public static final String def_button_add=  "(//*[@class='mat-button-wrapper' and contains (text(),'Add')])[2]";
	    public static final String def_button_cancel= "//*[@class='mat-button-wrapper' and contains (text(),'Cancel')]";
	    public static final String gridTableXpath = "//tbody[@role = 'rowgroup']";
	    public static final String defFilterXpath = "//input[@id='filter']";
	    public static final String title_New_defin_dialog_XPATH = "//h2[@class = 'mat-dialog-title' and text() = 'New Measure']";
	    public static final String msg_measure_created = "//div[@aria-live='assertive' and text() = 'Measure created']";
		public static final String msg_measure_updated = "//div[@aria-live='assertive' and text() = 'Measure updated']";
		public static final String mesure_def_created_row_xpath = "//td[contains(@class,'cdk-column-name')]";
		public static final String btn_update_icon = "//mat-icon[@role= 'img' and text() = 'edit']";
		public static final String btn_update = "//button[@type = 'submit']";
		public static final String delete_update = "(//button[@id='delete'])[1]";
		public static final String MD_header1 = "(//button[@class = 'mat-sort-header-button'])[1]";
		public static final String MD_header4 = "(//button[@class = 'mat-sort-header-button'])[4]";
		public static final String MD_organization_name_xpath = "(//button[@class = 'mat-sort-header-button'])[4]";
		public static final String MD_organization_code_xpath = "//button[@class = 'mat-sort-header-button' and text() = 'Organization Code']";
		
		public static final String recordStatusXpath = "//button[@class = 'mat-sort-header-button' and text() = 'Record Status']";
		public static final String headerMeasureStatusXpath = "//button[@class = 'mat-sort-header-button' and text() = 'Measure Status']";
		public static final String headerSourceOrgCodeXpath = "//button[@class = 'mat-sort-header-button' and text() = 'Source Organization Code']";
		public static final String headerSourceXpath = "//button[@class = 'mat-sort-header-button' and text() = 'Source']";
		
		public static final String recordStatusValueXpath = "(//td[contains(@class,'cdk-column-status')])[1]";
		public static final String createdByXpath = "(//td[contains(@class,'cdk-column-createdBy')])[1]";
		
		public static final String msg_definitiona_deleted = "//div[@aria-live='assertive' and text() = 'Measure Deactivated']";
		
	    public static final String def_button_add_enabled =  "//span[text()='Add']/parent::button[@ng-reflect-disabled='false']";
	    public static final String def_button_add_disabled =  "//span[text()='Add']/parent::button[@ng-reflect-disabled='true']";
	    public static final String Measure_organization_xpath = "//mat-select[@ng-reflect-placeholder='Organization' and @aria-required='true']";
	//=============================================================================================================================================
	//=============================================================================================================================================
	//AdminMeasureVersion

	    public static final String header_versions =  "(//div[@class='mat-tab-label-content'])[2]";
        public static final String measure_dropdown =  "//*[@id='measure']";
        public static final String AMD_measure_dropdown_list = "//*[@class='mat-option-text']";
        public static final String Select_ABA_Measure = "//span[@class = 'mat-option-text' and contains (text(),'Adult BMI Assessment')]";
        public static final String button_add_version = "//*[@id='add-version']";
        public static final String Select_Version = "//span[@class = 'mat-option-text' and contains (text(),' 2019 October Update ')]";
        public static final String field_version_name= "//input[@ng-reflect-placeholder='Version Name']";
        public static final String field_version_desc= "//input[@ng-reflect-placeholder='Description']";
        public static final String has_relevant_dates= "//span[@class='mat-checkbox-label' and text() = ' Has relevant dates ']";
        public static final String helpNotesXpath = "//textarea[@ng-reflect-placeholder='Help Notes']";
        public static final String version_drop_dn = "//*[@id='version']";
        public static final String select_version_dd = "//*[@class='mat-option-text']";
        public static final String v_button_add= "//button[@id='save']";
		public static final String v_button_cancel= "//button[@id='cancel']";
		public static final String attachment_tab_xpath= "//div[@role = 'tab']/following::div[@class = 'mat-tab-label-content' and text() = 'Attachments']";
		public static final String button_select_files =  "//input[@type='file']"; 
		public static final String button_upload_files = "//button[@id='upload']";
		public static final String title_New_Version_dialog_XPATH = "//h2[@class = 'mat-dialog-title']";
		public static final String msg_version_created = "//div[@aria-live='assertive' and text() = 'Measure version added']";
		public static final String close_bnt_attachment = "//span[@class = 'mat-button-wrapper' and text() = 'Close']";
		public static final String no_versions_for_the_measure_msg = "//span[@class = 'details-error']";
		public static final String createdOnDateXpath = "(//td[contains(@class,'cdk-column-createdOn ')])[1]";
		public static final String updateButtonXpath = "//mat-icon[@role = 'img' and text() = 'edit']";
		public static final String statusDropDownXpath = "//mat-select[@id='status']";
		public static final String attachmentDeleteButton = "//mat-icon[@role='img' and text() = 'delete']";
		public static final String msgVersionDeletedXpath= "//div[@aria-live='assertive' and text() = 'Version deactivated']";
		
		public static final String headerVersionNameXpath= "(//button[@class='mat-sort-header-button' and contains(text(),'Version')])[1]";
		public static final String headerVersionStatusXpath= "(//button[@class='mat-sort-header-button' and contains(text(),'Version')])[2]";
		public static final String headerDescriptionXpath= "//button[@class='mat-sort-header-button' and contains(text(),'Description')]";
		public static final String headerMVCreatedOnXpath= "//button[@class='mat-sort-header-button' and contains(text(),'Created On')]";
		public static final String headerMVCreatedByXpath= "//button[@class='mat-sort-header-button' and contains(text(),'Created By')]";
		public static final String headerRecordStatusXpath= "//button[@class='mat-sort-header-button' and contains(text(),'Record Status')]";
	//===============================================================================================================
	//===============================================================================================================
	//AdminMeasureElement
		public static final String header_element =  "(//div[@class='mat-tab-label-content'])[3]";
	    public static final String button_add_element = "//*[@id='add']";
	    public static final String measure_element_xpath = "//button[@id='add']";
	    public static final String field_code = "//input[@ng-reflect-placeholder='Code']";
	    public static final String element_field_description = "//*[@ng-reflect-placeholder='Description']";
	    public static final String field_type= "//mat-select[@ng-reflect-placeholder='Type']";
	    public static final String element_organization_dd_xpath= "//mat-select[@ng-reflect-placeholder='Organization' and@aria-required = 'true' ]";
	    public static final String elementOrganizationXbuttonXpath= "//mat-select[@ng-reflect-placeholder='Organization' and@aria-required = 'true' ]//following::button[@id='clear']";
	    public static final String dd_list_type= "//*[@class='mat-option-text']";
	    public static final String ele_button_add= "(//*[@id='add'])[2]";
	    public static final String ele_button_cancel= "//*[@id='cancel']";
	    public static final String ele_button_delete= "(//button[@id='delete'])[1]";
	    public static final String field_filter = "//input[@id='filter']";
	    public static final String title_New_element_dialog_XPATH = "//h2[@class = 'mat-dialog-title' and text() = 'New Element']";
	    public static final String button_edit_element = "(//*[@id='edit'])[1]";
	    public static final String msg_element_deleted = "//div[@aria-live='assertive' and text() = 'Element Deactivated']";
	    
	    
	//===============================================================================================================
	//===============================================================================================================
	//AdminMeasureElementMapping
		   public static final String header_element_mapp = "(//div[@class='mat-tab-label-content'])[4]";
	       public static final String measure_dropdown_Ele_map = "//*[@id='measure']";
	       public static final String measure_dropdown_ver_Ele_map = "//*[@class='mat-option-text']";
	       public static final String field_ver_drp_dn= "//*[@id='version']";
	       public static final String field_available_ele =  "//*[@id='unmapped-elements-filter']";
	       public static final String field__ele_mapped =  "//*[@id='mapped-elements-filter']";
	       public static final String add_ele_plus_btn = "(//*[@id='add'])[1]";
	       public static final String add_ele_minus_btn =  "(//*[@id='remove'])[1]";
	       public static final String measure_dropdown_list = "//*[@class='mat-option-text']";
	       public static final String title_New_ele_map_dialog_XPATH = "//h2[@class = 'mat-dialog-title' and text() = 'New Element']";
	       

	//===============================================================================================================
	//===============================================================================================================

    //Chase Generator
	 
	    public static final String button_chase = "//*[@id=\"mat-expansion-panel-header-1\"]/span[1]/mat-panel-title";
	   	public static final String button_chase_generators = "//a[@id='chase-generators']";
	   	public static final String add_chase_generators = "//button[@id='add']";
	   	public static final String name_field = "//input[@id='name' and @aria-required='true']";
	   	public static final String field_initiatives = "//mat-select[@id='initiative' and@aria-required='true']";
	   	public static final String initiative_dd_list = "//span[@class = 'mat-option-text' and contains (text(),' MI Hybrid 2019 ')]";
	   	public static final String number_of_chase = "//input[@id='number-of-chases' and @aria-required='true']";
	   	public static final String exclude_member_chk_bx = "//*[@id='exclude-members']";
	   	public static final String data_driven_radio_bx = "//mat-radio-button[@id='mat-radio-2']";
	   	public static final String event_driven_radio_bx = "//mat-radio-button[@id='mat-radio-3']";
	   	public static final String start_date = "//input[@id='start-date' and @aria-required='true' ]";
	   	public static final String end_date = "//input[@id='end-date' and @aria-required='true' ]";
	   	public static final String add_base_rule = "//button[@id='add']";
	   	public static final String addModifiersButtonXpath = "//button[@id='add-modifiers']";
	   	public static final String base_rule_field = "//mat-select[@ng-reflect-placeholder= 'Base Rule']";
	   	public static final String modifierRuleDropDownXpaht1 = "(//mat-select[@ng-reflect-placeholder= 'Modifier Rule'])[1]";
	   	public static final String modifierRuleDropDownXpaht2 = "(//mat-select[@ng-reflect-placeholder= 'Modifier Rule'])[2]";
	   	
	   	public static final String base_rule_field_dd = "//span[@class = 'mat-option-text' and contains (text(),' chaserule2 ')]";
	   	public static final String point_field = "//*[@formcontrolname= 'points']";
	   	public static final String addModifierPointFieldXpath1 = "(//button[@id='add-modifiers'] //following::input[@formcontrolname= 'points'])[1]";
	   	public static final String addModifierPointFieldXpath2 = "(//button[@id='add-modifiers'] //following::input[@formcontrolname= 'points'])[2]";
	   	public static final String add_modifiers_btn = "//button[@id='add-modifiers']";
	   	public static final String remove_bnt = "//button[@id='remove']";
	   	public static final String cancel_bnt = "//button[@id='cancel']";
	   	public static final String save_generate_btn = "//button[@id='save']";
	   	public static final String focus_population = "//mat-select[@id='population' and@aria-required='true']";
	   	public static final String focus_population_dd = "//span[@class = 'mat-option-text' and contains (text(),'Eligible Population')]";
	   	public static final String measure = "//mat-select[@id='measure' and @aria-required='true' ]";
	   	public static final String measure_dd = "//span[@class = 'mat-option-text' and contains (text(),'ABA')]";
	   	public static final String version = "//mat-select[@id='version' and @aria-required='true' ]";
	   	public static final String version_dd = "//span[@class = 'mat-option-text' and contains (text(),'2019 October Update')]";
	   	public static final String service_type = "//mat-select[@id='services']";
	   	public static final String service_type_dd = "//mat-pseudo-checkbox[contains(@class,'mat-option-pseudo-checkbox')]";
	   	public static final String numerator = "//mat-select[@id='numerator']";
	   	public static final String numeratorXbuttonXpath = "//mat-select[@id='numerator']//following::button[@id = 'clear']";
	   	public static final String chaseMemberListGroupXbuttonXpath = "//mat-select[@ng-reflect-placeholder='Group' and @id='group']//following::button[@id = 'clear']";
	   	
	   	public static final String appointmentMngmntAssigneeXpath = "//mat-select[@id='assignee']";
	   	public static final String appointmentMngmntAssigneeXbuttonXpath = "(//mat-select[@id='assignee']//following::button[@id = 'clear'])[1]";
	   	public static final String auditMngmntAuditorXbuttonXpath = "//mat-select[@ng-reflect-placeholder='Auditor']//following::button[@id = 'clear']";
	   	public static final String numerator_dd = "//span[@class = 'mat-option-text' and contains (text(),'Adult BMI Assessment')]";
		public static final String title_Chase_gen_dialog_XPATH = "//mat-card-title[@class = 'mat-card-title' and text() = ' Add Chase Generator ']";
		public static final String CG_header1 = "(//button[@class = 'mat-sort-header-button'])[1]";
		public static final String existing_rules_name = "//span[@class = 'mat-option-text' and text() =' "+ChaseRulesDelete.username+" ']";
		public static final String CG_filter = "//input[@id='filter']";
		public static final String edit_bnt = "(//button[@id='edit'])[1]";
		
		public static final String runAuditToolTipXpath="(//button[contains(@id,'run')])[1]";
		public static final String CG_execution_btn_xpath = "(//mat-icon[@role = 'img' and text() = 'play_arrow'])[1]";
		public static final String msgAuditGenExecutionXpath = "//span[text()='Your job has been successfully submitted']";
		public static final String msgAuditRunLabelCreatedXpath = "//span[text()='Audit Generator Run Label created']";
		public static final String msgAuditRunLabelNotCreatedForEndedXpath = "//span[text()='Record cannot be modified when initiative is in status Ended']";
		public static final String msgAuditGenUpdateXpath = "//span[text()='Audit generator updated']";
		public static final String msgAuditGenRunLabelUpdateXpath = "//span[text()='Audit Generator Run Label updated']";
		public static final String msgAuditGenCreatedXpath = "//span[text()='Audit generator created']";
		public static final String chaseGenDropDownXpath = "//mat-select[@id='generator' and  @placeholder='Chase Generator' and @aria-required='false']";
		public static final String chaseGenXbuttonXpath = "//mat-select[@id='generator']//following::button[@id = 'generatorClear']";
		
		

		//===============================================================================================================
		//===============================================================================================================

	    //Rules

	        public static final String rules_dd = "//mat-panel-title[@class='mat-expansion-panel-header-title' and text() = ' Rules ']"; 
		    public static final String button_rules = "//a[@id='rules']";
		    public static final String rulesTypeButtonXpath = "//a[@id='rule-types']";
		    public static final String rules_filter = "//*[@id='filter']";
		   	public static final String add_rule_button = "//*[@id='add']";
		   	public static final String rule_name_field = "//*[@id='name']";
		   	public static final String rule_contex = "//*[@id='context']";
		   	public static final String rule_contex_chase = "//span[@class = 'mat-option-text' and contains (text(),'Chase')]";
		   	public static final String rule_contex_audit = "//span[@class = 'mat-option-text' and contains (text(),'Audit')]";
		   	public static final String rule_contex_initiative = "//span[@class = 'mat-option-text' and contains (text(),' Initiative ')]";
		   	public static final String base_point = "//*[@id='base-points']";
		   	public static final String addGroupXpath = "//button[@id='add']";
		   	public static final String addConditionXpath = "//button[@id='add-condition']";
		   	public static final String data_source_dd_service_table = "//span[@class = 'mat-option-text' and contains (text(),' Service Table ')]";
		   	public static final String dataSourceClaimTableDropDown = "//span[@class = 'mat-option-text' and contains (text(),' Claim Table')]";
		   	public static final String data_source_dd_function = "//span[@class = 'mat-option-text' and contains (text(),' Function')]";
		   	public static final String data_element_dd_service_type = "//span[@class = 'mat-option-text' and text() = ' Service Type ']";
		   	public static final String dataElementDropDownCompositeServiceTypeXpath = "//span[@class = 'mat-option-text' and contains(text() , 'Composite Service Type')]";
		   	public static final String compositeServiceTypeXpath = "//a[@id = 'editComposite' and @title='Edit Composite Service Type']";
            public static final String dataElementDdServiceDate = "//span[@class = 'mat-option-text' and contains (text(),' Service Date ')]";
            public static final String data_element_dd_service_Assignee = "//span[@class = 'mat-option-text' and contains (text(),' Assignee')]";
            public static final String data_element_dd_service_Ownerid = "//span[@class = 'mat-option-text' and contains (text(),' Owner ID ')]";
            public static final String dataElementDdAnyOfTheClaimsCodesXpath = "//span[@class = 'mat-option-text' and contains (text(),' Any of the claims codes (DRG, PS, etc) ')]";
            public static final String data_element_dd_function_month = "//span[@class = 'mat-option-text' and contains (text(),' Month with practitioner')]";
            public static final String data_element_dd_function_number = "//span[@class = 'mat-option-text' and contains (text(),' Number of visit ')]";
            public static final String data_element_dd_claim_revenue = "//span[@class = 'mat-option-text' and contains (text(),' Revenue Code')]";
            public static final String data_element_dd_claim_code = "//span[@class = 'mat-option-text' and contains (text(),'Any of the claims code')]";
            public static final String data_element_dd_claim_place = "//span[@class = 'mat-option-text' and contains (text(),'Place of Service')]";
            public static final String data_element_dd_claim_procedure = "//span[@class = 'mat-option-text' and contains (text(),'Procedure Code')]";
		   	public static final String data_element_dd_palce_of_srv_cd = "//*[@class = 'mat-option-text' and contains (text(), ' Place of Service Code ')]";
		   	public static final String text_value_BMI = "//span[@class = 'mat-option-text' and contains (text(),' BMI')]";
		   	public static final String textValueXpath = "//span[@class = 'mat-option-text' and contains (text(),' BMDT ')]";
		   	public static final String numaric = "//*[@id='numeric-value']";
		   	public static final String qualifier_drop_down = "//span[@class='mat-option-text' and (text() =' NCQA - October 2018 ')]";
		   	public static final String remove_btn = "//*[@id='remove']";
			public static final String greaterThanButtonXpath = "//div[@class='mat-button-toggle-label-content' and contains (text(),'>')]";
			public static final String smallerThanButtonXpath = "//div[@class='mat-button-toggle-label-content' and contains (text(),'<')]";
			public static final String inButtonXpath = "//div[@class='mat-button-toggle-label-content' and text() =' IN ']";
			public static final String notInButtonXpaht = "//div[@class='mat-button-toggle-label-content' and contains (text(),'NOT IN')]";
			public static final String greaterThanOrEqueslToButtonXpath = "//div[@class='mat-button-toggle-label-content' and contains (text(),'>=')]";
			public static final String smallerThanOrEquelToButtonXpath = "//div[@class='mat-button-toggle-label-content' and contains (text(),'<=')]";
			public static final String dateFieldXpath1 = "(//input[@id='date-value'])[1]";
			public static final String dateFieldXpath2 = "(//input[@id='date-value'])[2]";
			public static final String save = "//*[@id='save']";
			public static final String cancel = "//button[@id='cancel']";
			public static final String delete_btn = "//*[@id='delete']";
			public static final String title_Add_Rules_dialog_XPATH = "//mat-card-title[@class = 'mat-card-title' and text() = ' Add Rule ']";
			public static final String msg_rule_created = "//div[@aria-live='assertive' and text() = 'Rule created']";
			public static final String data_source1 = "(//*[@id='data-source'])[1]";
			public static final String data_source2 = "(//*[@id='data-source'])[2]";
			public static final String data_source3 = "(//*[@id='data-source'])[3]";
			public static final String dataElementDropDown = "(//*[@id='data-element'])[1]";
			public static final String data_element2 = "(//*[@id='data-element'])[2]";
			public static final String data_element3 = "(//*[@id='data-element'])[3]";
			public static final String textDropDownXpath = "(//*[@id='text-value'])[1]";
			public static final String text2 = "(//*[@id='text-value'])[2]";
			public static final String text3 = "(//*[@id='text-value'])[3]";
			public static final String qualifierDropDownXpath = "(//*[@id='qualifier'])[1]";
			public static final String qualifier2 = "(//*[@id='qualifier'])[2]";
			public static final String qualifier3 = "(//*[@id='qualifier'])[3]";
			public static final String date1 = "(//*[@id='date-value'])[1]";
			public static final String date2 = "(//*[@id='date-value'])[2]";
			public static final String date3 = "(//*[@id='date-value'])[3]";
			public static final String date4 = "(//*[@id='date-value'])[4]";
			public static final String equilto_btn2 = "(//div[@class='mat-button-toggle-label-content' and contains (text(),'=')])[4]";
			public static final String equilto_btn3 = "(//div[@class='mat-button-toggle-label-content' and contains (text(),'=')])[7]";
			public static final String equilto_btn4 = "(//div[@class='mat-button-toggle-label-content' and contains (text(),'=')])[10]";
			public static final String executed_rule = "(//button[@id = 'view'])[1]";
			public static final String disable_contex_chase = "//mat-select[@ng-reflect-placeholder='Context' and @aria-disabled='true' ]";
			public static final String disable_data_source = "//mat-select[@ng-reflect-placeholder='Data Source' and @aria-disabled='true' ]";
			public static final String disable_data_element = "//mat-select[@ng-reflect-placeholder='Data Element' and @aria-disabled='true' ]";
			public static final String disable_text = "//mat-select[@ng-reflect-placeholder='Text' and @aria-disabled='true' ]";
			public static final String disable_qualifier = "//mat-select[@ng-reflect-placeholder='Qualifier' and @aria-disabled='true' ]";
            public static final String text_value_ACE ="//span[@class = 'mat-option-text' and contains (text(),' ACE ')]";
            public static final String equaltoToButtonXpath = "(//div[@class='mat-button-toggle-label-content' and text() = ' = '])[1]";
            public static final String Lessthanequalbttn_XPATH="(//div[@class='mat-button-toggle-label-content' and contains (text(),' <= ')])[3]";
            public static final String greaterThanOrEqualToBttnXpath="(//div[@class='mat-button-toggle-label-content' and contains (text(),' >= ')])[2]";
            public static final String msg_rule_deletedted = "//div[@aria-live='assertive' and text() = 'Rule deleted']";
            public static final String rulesDropDownFromInitiativeHeaderTabXpath = "//mat-select[@ng-reflect-placeholder='Rules']";
            
            
          
        	
			

			//===============================================================================================================
			//===============================================================================================================

		    //Provider Groups
			 
			    public static final String provider_group = "//*[@id='provider-groups']";
			    public static final String add_provider_group = "//*[@id='add']";
			    public static final String organization =  "//*[@id='organization']";    
			    public static final String anyDropDownXpath =  "//span[@class = 'mat-option-text']"; 
			    public static final String select_organization_dd = "//span[@class = 'mat-option-text' and contains (text(),' Health Plan of Michigan')]";
			    public static final String PG_name_field = "//*[@id='name']";
			    public static final String group_type = "//mat-select[@id='group-type']";
			    public static final String select_grouptype_dd = "//span[@class = 'mat-option-text' and contains (text(),' Custom Group')]";
			    public static final String abstraction_method = "//*[@id='abstraction-method']";
			    public static final String select_abstraction_method_dd = "//span[@class = 'mat-option-text' and contains (text(),' Office Visit')]";
			    public static final String organization_type = "//*[@id='organization-type']";
			    public static final String organizationTypeXButtonXpath = "//*[@id='organization-type']//following::button[@id='clear']";
			    public static final String select_org_type_dd = "//span[@class = 'mat-option-text' and contains (text(),' Individual Provider')]";
			    public static final String TIN = "//*[@id='tin']";
			    public static final String contact_name = "//*[@id='contact']";
			    public static final String contactMethod1Xpath = "//mat-select[@id='contact-method-1']";
			    public static final String contactMethod1XbuttonXpath = "//mat-select[@id='contact-method-1']//following::button[@id='clearConatact']";
			    public static final String select_contact_method1_dd = "//span[@class = 'mat-option-text' and contains (text(),' Telephone')]";
			    public static final String contact_info_1 = "//*[@id='contact-info-1']";
			    public static final String contactMethod2Xpath = "//*[@id='contact-method-2']";
			    public static final String contactMethod2XbuttonXpath = "//mat-select[@id='contact-method-2']//following::button[@id='clearConatact2']";
			    public static final String select_contact_method2_dd = "//span[@class = 'mat-option-text' and contains (text(),' Electronic Mail Address ')]";
			    public static final String contact_info_2 = "//*[@id='contact-info-2']";
			    public static final String address_line_1 = "//*[@id='address-1']";
			    public static final String address_line_2 = "//*[@id='address-2']";
			    public static final String city = "//*[@id='city']";
			    public static final String state = "//*[@id='state']";
			    public static final String zip_code = "//*[@id='postal-code']";
			    public static final String medicalRecordVendorXpath = "//mat-select[@id='vendor']";
			    public static final String medicalRecordVendorXbuttonXpath = "//mat-select[@id='vendor']//following::button[@id='clearVendor'] ";
			    public static final String select_medical_record_vndr_dd = "//span[@class = 'mat-option-text' and contains (text(),' EPIC Systems ')]";
			    public static final String EMR_System = "//mat-select[@id='emr-system']";
			    public static final String select_emr_system_dd = "//span[@class = 'mat-option-text' and contains (text(),' Cerner ')]";
			    public static final String notes = "//*[@id='notes']";
			    public static final String PG_add_button = "//button[@id='submit']";
			    public static final String PG_cancel_button = "//button[@id='cancel']";
			    public static final String title_add_pro_grp_dialog_XPATH = "//h2[@class = 'mat-dialog-title' and text() = ' Add Provider Group']";
			    public static final String title_provider_search = "//h2[@class = 'mat-dialog-title' and text() = 'Provider Search']";
			    public static final String title_locaation_search = "//h2[@class = 'mat-dialog-title' and text() = 'Location Search']";
			    public static final String PG_mapping_button = "(//mat-icon[@class = 'mat-icon material-icons' and text() = 'compare_arrows'])[1]";
			    public static final String PG_search_icon = "//*[@id='provider-search']";
			    public static final String PG_loc_search_icon = "//*[@id='location-search']";
			    public static final String PG_loc_search_dialog = "//h2[@class= 'mat-dialog-title' and text() = 'Location Search']";
			    public static final String PG_id_field = "(//*[@id='provider'])[2]";
			    public static final String PG_loc_id_field = "//*[@id='member']";
			    public static final String PG_search_button = "//*[@id='search']";
			    public static final String PG_provider_list = "//h2[text()='Provider Search']/following::input[@type = 'checkbox']";
			    public static final String PG_location_list = "//h2[text()='Location Search']/following::input[@type = 'checkbox']";
			    public static final String available_provider_checkbox = "//h3[text() = 'Providers Mapped']/preceding::input[@type = 'checkbox']";
			    public static final String provider_mapped_checkbox = "//h3[text() = 'Providers Mapped']/following::input[@type = 'checkbox']";
			    public static final String available_provider_checkbox1 = "(//h3[text() = 'Providers Mapped']/preceding::input[@type = 'checkbox'])[1]";
			    public static final String provider_mapped_checkbox1 = "(//h3[text() = 'Providers Mapped']/following::input[@type = 'checkbox'])[1]";
			    public static final String map_button_xpath= "//button[@id='add-provider']";
			    public static final String unmap_button_xpath= "//button[@id='remove-provider']";
			    public static final String available_provider_xpath= "//h3[text() = 'Available Providers']";
			    public static final String PG_provider_list1 = "(//td[contains(@class,'cdk-column-select')])[5]";
			    public static final String PG_provider_list2 = "(//td[contains(@class,'cdk-column-select')])[8]";
			    public static final String PG_select_button = "//*[@id='select']";
			    public static final String PG_plus_button = "//*[@id='add']";
			    public static final String PG_minus_button = "//*[@id='remove']";
			    
			    public static final String msgProviderGroupCreatedXpath= "//span[contains(text(),'Group criteria created')]";
			    public static final String msgProviderGroupUpdateXpath= "//span[contains(text(),'Group updated')]";
			    
			    public static final String msg_provider_mapped = "//div[@aria-live='assertive' and contains(text(),'Mappings have been')]";
			    public static final String msg_provider_unmapped = "//div[@aria-live='assertive' and contains(text(),'Mappings have been')]";
			    public static final String PG_location_radio_box = "(//div[@class = 'mat-radio-label-content'])[2]";
			    public static final String PG_provider_radio_box = "(//div[@class = 'mat-radio-label-content'])[1]";
			    
			    public static final String columnHeaderGroupNameXpath = "//button[@type = 'button' and contains(text(),'Group Name')]";
			    public static final String columnHeaderGroupTyeXpath = "//button[@type = 'button' and contains(text(),'Group Type')]";
			    public static final String columnHeaderOrgTyeXpath = "//button[@type = 'button' and contains(text(),'Organization Type')]";
			    public static final String columnHeaderTinXpath = "//button[@type = 'button' and contains(text(),'TIN')]";
			    public static final String columnHeaderContact1Xpath = "//button[@type = 'button' and contains(text(),'Contact 1')]";
			    public static final String columnHeaderContact2Xpath = "//button[@type = 'button' and contains(text(),'Contact 2')]";
			    public static final String columnHeaderStatusXpath = "//button[@type = 'button' and contains(text(),'Status')]";
			    public static final String pgMappingButtonXpath = "//div[contains(@class,'mat-button-ripple') and @ng-reflect-disabled='false']//preceding::mat-icon[@role= 'img' and contains(text(),'compare_arrows')]";
			    
			    
			  
			  //===============================================================================================================
				//===============================================================================================================

			    //Organization
				 
				    public static final String Organization = "//*[@id='organizations']";
				    public static final String add_Organization = "//*[@id='add']";
				    public static final String org_filter =  "//*[@id='filter']";    
				    public static final String org_name_field =  "//*[@id='name']"; 
				    public static final String parent_Organization = "//mat-select[@id='parent-organization']";
				    public static final String parentOrganizationXbuttonXpath = "//mat-select[@id='parent-organization']//following::button[@id='clear']";
				    public static final String code = "//*[@id='code']";
				    public static final String org_add_button = "//*[@id='submit']";
				    public static final String org_cancel_button = "//button[@id='cancel']";
				    public static final String orgEditButtonXpath = "(//button[@id='edit'])[1]";
				    public static final String title_add_org_dialog_XPATH = "//h2[@class = 'mat-dialog-title' and text() = 'Add Organization']";
				    public static final String orgNameXpath = "(//td[contains(@class,'cdk-column-name')])[1]";
				    public static final String parentOrgXpath = "(//td[contains(@class,'cdk-column-parentOrganization')])[1]";
				    public static final String orgCodeXpath = "(//td[contains(@class,'cdk-column-code')])[1]";
				    public static final String organizationUpdateButtonXpath = "//button[@id='submit']";
				    public static final String MsgUpdateOrganizationXpath = "//span[text()='Organization updated']";
				    public static final String MsgCreateOrganizationXpath = "//span[text()='Organization created']";
				    
				    public static final String orgHeaderNameXpath = "//button[@class = 'mat-sort-header-button' and contains(text(), 'Name')]";
					public static final String parentOrgHeaderXpath = "//button[@class = 'mat-sort-header-button' and contains(text(), 'Parent Organization')]";
				  
				    
				    
				  //===============================================================================================================
					//===============================================================================================================

				    //Jobs
				  
				    
				    
				    
				    
				    public static final String btn_jobs = "//*[@id='jobs']";
				    public static final String jobs_filter = "//*[@id='filter']";
				    public static final String jobs_next_page_paginator ="(//*[@class='mat-paginator-icon'])[3]";
				    public static final String jobs_previous_page_paginator ="(//*[@class='mat-paginator-icon'])[2]";
				    public static final String jobs_first_page_paginator ="(//*[@class='mat-paginator-icon'])[1]";
				    public static final String jobs_last_page_paginator ="(//*[@class='mat-paginator-icon'])[4]";
				    public static final String jobs_item_per_page_default = "//span[@class = 'ng-tns-c21-16 ng-star-inserted' and text() = '15']";
				    public static final String jobs_item_per_page_drop_down = "//div[@class = 'mat-select-arrow-wrapper']";
				    public static final String column_header_type = "//button[text()='Type']";
				    public static final String column_header_name = "//button[text()='Name']";
				    public static final String column_header_initiative = "//button[text()=' Initiative ']";
				    public static final String column_header_status = "//button[text()='Status']";
				    public static final String column_header_startedby = "//button[text()=' Started By ']";
				    public static final String column_header_creationdate = "//button[text()=' Creation Date ']";
				    public static final String column_header_startdate = "//button[text()=' Start Date ']";
				    public static final String column_header_enddate= "//button[text()='End Date']";
				    public static final String document_created_row_type = "(//td[contains(@class,'cdk-column-type')])[1]";
				    public static final String document_created_row_name = "(//td[contains(@class,'cdk-column-name')])[1]";
				    public static final String document_created_row_initiative = "(//td[contains(@class,'cdk-column-initiative')])[1]";
				    public static final String document_created_row_startedby= "(//td[contains(@class,'cdk-column-createdBy')])[1]";
				    public static final String documentCreatedRowCreationDate = "(//td[contains(@class,'cdk-column-creationDate')])[1]";
				    public static final String document_created_row_startdate = "(//td[contains(@class,'cdk-column-startDate')])[1]";
				    public static final String documentreatedRowEtartDate = "(//td[contains(@class,'cdk-column-endDate')])[1]";
				    public static final String document_created_row_enddate = "(//td[contains(@class,'cdk-column-endDate')])[1]";
				    public static final String document_created_row_jobstatus = "(//td[contains(@class,'cdk-column-jobStatus')])[1]";
				    public static final String document_created_row_jobstatusFailed = "(//td[contains(@class,'cdk-column-jobStatus') and text()= ' Failed '])[1]";
				    public static final String document_created_row_jobstatusRunning = "(//td[contains(@class,'cdk-column-jobStatus') and text()= ' Running '])[1]";
				    public static final String document_created_row_jobstatusCompleted = "(//td[contains(@class,'cdk-column-jobStatus') and text()= ' Completed '])[1]";
				    public static final String rowPopulationXpath = "(//td[contains(@class,'cdk-column-population')])[1]";
				    public static final String rowMeasureXpath = "(//td[contains(@class,'cdk-column-measure')])[1]";
				    public static final String rowVersionXpath = "(//td[contains(@class,'cdk-column-measureVersion')])[1]";
				  


				    
			 
				    //===============================================================================================================
					//===============================================================================================================

				    //User
				    public static final String userManagementXpath = "//mat-panel-title[@class = 'mat-expansion-panel-header-title' and text() = ' System Administration ']";
				    public static final String users= "//a[@id='users']";
				    public static final String users_filter= "//*[@id='filter']";
				    public static final String users_edit_btn= "(//button[@id='edit'])[1]";
				    public static final String users_delet_btn= "(//button[@id='delete'])[1]";
				    public static final String invite_user_btn= "//button[@id='invite']";
				    public static final String invite_user_email_field= "//*[@id='emails']";
				    public static final String invite_user_application_dd= "//*[@id='applications']";
				    public static final String invite_user_group_pp= "(//*[@id='groups'])[2]";
				    public static final String inviteBtnXpath= "(//button[@id='invite'])[2]";
				    public static final String cancel_btn= "//*[@id='cancel']";
				    public static final String update_btn= "//button[@id='submit']";
				    public static final String text_matchin= "(//td[contains(@class,'cdk-column-email')])[1]";
				    public static final String title_user_dialog_XPATH = "//h2[@class = 'mat-dialog-title']";
				    public static final String TableRowValueAcctStatus_xpath = "//mat-icon[text()='email']//preceding::tr[1]/td[2][text()=' Pending Registration ']";
				    public static final String IconEmail_xpath = "//mat-icon[text()='email']";
					public static final String ButtonEditUser_xpath = "//mat-icon[text()='edit']";
					public static final String TitleUpdateUserGroup_xpath = "//h2[contains(@text(),'')]";
					public static final String TitleGroupsUser_xpath = "//mat-select[@id='groups']";
					public static final String ButtonDisabledAdmin_xpath = "//mat-icon[text()='group_add']//following::div[@ng-reflect-disabled='true']";
					public static final String DropdownGroups_xpath = "//mat-select[@placeholder='Groups']//following::div[@class='mat-select-arrow']";
					public static final String CheckboxSelectedAdminGroups_xpath = "//span[text()=' mr-admin ']//parent::mat-option[@aria-selected='true']";
					public static final String CheckboxNotSelectedAdminGroups_xpath = "//span[text()=' mr-admin ']//parent::mat-option[@aria-selected='false']";
					public static final String CheckboxUnselectedAdminGroups_xpath = "//span[text()=' mr-admin ']//parent::mat-option[@aria-selected='false']";
					public static final String ButtonUpdateUser_xpath = "//span[text()=' Update ']";
					public static final String MsgUpdateUser_xpath = "//span[text()='User has been updated']";
					public static final String MenuLogout_xpath = "//a[@id='logout']";
					public static final String UnknownUsermsg_xpath = "//simple-snack-bar[contains(@class,'mat-simple-snackbar')]/span[1]";
					public static final String group_dd_xpath = "//mat-select[@id = 'groups']";
					public static final String checked_Testgrp_xpath = "//mat-pseudo-checkbox[@ng-reflect-state='checked']//following::span[@class = 'mat-option-text' and contains(text() , ' mr-mobile-users ')]";
					public static final String unchecked_Testgrp_xpath = "//mat-option[@role='option' and @aria-selected='false' ]//following::span[@class = 'mat-option-text' and contains(text(), 'mr-mobile-users')]";
					public static final String Title_User_xpath = "//mat-card-title[@class='mat-card-title']";
					public static final String userAccountUnlockedInputBoxXpath = "//mat-checkbox[@id = 'account-locked']//child::input[@id = 'account-locked-input'  and @aria-checked = 'true']";
					public static final String userAccountLockedInputBoxXpath = "//mat-checkbox[@id = 'account-locked']//child::input[@id = 'account-locked-input'  and @aria-checked = 'false']";
					public static final String chaseManagementAssigneeDropDownXpath = "//mat-select[@id='assignee']";
					public static final String chaseManagementAssigneeDropDownValueXpath = "//span[@class ='mat-option-text' and contains(text(),'Zahan, Sarwar')]";
					public static final String userAccountUnlockIconXpath = "//button[@id='unlock']";
					public static final String MsgUnlockUserAccountXpath = "//span[text()='User Account has been unlocked']";
					
					
					public static final String userAccountStatusHeaderXpath="//button[@class='mat-sort-header-button' and contains(text(),'Account Status ')]";
                    public static final String userEmailHeaderXpath="//button[@class='mat-sort-header-button' and contains(text(),'Email')]";
					
				    //===============================================================================================================
					//===============================================================================================================

				    //Group
				   
				    public static final String groupXpath= "//a[@id='groups']";
				    public static final String groupEditBtnXpath= "(//button[@id='edit'])[1]";
				    public static final String groupDeletBtnXpath= "(//button[@id='delete'])[1]";
				    public static final String groupAddBtnXpath= "//button[@id='add']";
				    public static final String groupNameFieldXpath= "//input[@id='name']";
				    public static final String groupAddBtn1Xpath= "//button[@id='submit']";
				    public static final String groupCancelBtnXpath= "//button[@id='cancel']";
				    public static final String msgGroupCreatedXpath = "//div[@aria-live='assertive' and text() = 'Group created']"; 
				    public static final String msgSomethingWentWrongXpath = "//div[@aria-live='assertive' and text() = 'Something went wrong']"; 
				    
				    
				    
				    //Lock Unlock
				    //====================================================================================================================
				    public static final String TitleWelcome_xpath = "//div[contains(text(),'Welcome')]";
			        public static final String ButtonAdmin_xpath = "//span[text()='Admin']";
			        //AdminPage - User Management
			        public static final String MenuSysADmin_xpath = "//mat-panel-title[@class='mat-expansion-panel-header-title' and contains(text(),' System Administration ')]";
			        public static final String MenuUsers_xpath = "//a[@id='users']";
			        public static final String TitleUsers_xpath = "//mat-card-title[@class='mat-card-title' and contains(text(),'Users')]";
			        public static final String InputUsers_xpath = "//input[@placeholder='Filter']";
			        public static final String TableColumnActiveStatus_xpath = "//td[contains(@class,'mat-column-accountActive') and text()=' Active, Locked ']";
			        public static final String TableColumnEmail_xpath = "//td[contains(@class,'mat-column-email') and text()=' rohit.aurora@mhplan.com ']";
			        public static final String unlockBttnXpath="(//button[contains(@id,'unlock')])[1]";
			        public static final String TableColumnActions_xpath = "(//mat-icon[@role='img' and text()='lock_open'])[1]";
			        public static final String MsgUnlockUser_xpath = "//div[@aria-live='assertive' and text() = 'User Account has been unlocked']"; 
			        public static final String MsgInitialLoginFailedAttempt_xpath = "//div[@aria-live='assertive' and text() = 'Login Failed. You have 2 more attempts(s) left before your QMS account is locked.']";
				   	public static final String MsgSecondLoginFailedAttempt_xpath = "//div[@aria-live='assertive' and text() = 'Login Failed. You have 1 more attempts(s) left before your QMS account is locked.']";
				   	public static final String MsgFinalFailedLoginAttempt_xpath = "//div[@aria-live='assertive' and contains(text(),'Your QMS account is locked.')]";
				   	public static final String forgot_passowrd_xpath = "//span[@class = 'mat-button-wrapper' and text() = ' Forgot password? ']";
				   	public static final String email_field_xpath = "//*[@id='email']";
				   	public static final String reset_button_xpath= "//app-password-reset-dialog[@class='ng-star-inserted']//button[1]";
				   	public static final String password_reset_msg_xpath = "//span[text() = 'Password reset email sent']";


//==========================================================================================================


				  //03-14-2019 - Deepa for Forgot Password validation
				   	public static final String headerEmailXpath = "(//td[contains(@class,'mat-column-email')])[1]";
				   	public static final String TableAcctStatusRowEmail_xpath = "(//td[contains(@class,'mat-column-accountActive')])[1]";
				   	public static final String headerNameXpath = "(//td[contains(@class,'mat-column-name')])[1]";
				   	public static final String TableRowValueAcctStat_xpath = "(//td[contains(@class,'mat-column-accountActive')])[1]";
				   	public static final String TitleEditUser_xpath = "//h2[contains(text(),'Update User')]";

 //==================================================================================================================================
				   	public static final String msg_mapped_eliment = "//span[contains(text(),'Successfully mapped Element')]";
				   	
//==================================================================================================================================	
				   	//Active/Inactive Status
		              public static final String Status_dropdown_xpath = "(//mat-select[@id='status']//following::div[@class='mat-select-arrow'])[1]";
		              public static final String Checkbox_active_Status_checked_xpath = "//mat-pseudo-checkbox[@ng-reflect-state='checked']//following::span[text()=' Active ']";
		              public static final String Checkbox_inactive_Status_checked_xpath = "//mat-pseudo-checkbox[@ng-reflect-state='checked']//following::span[text()=' Inactive ']";
		              public static final String Checkbox_active_Status_unchecked_xpath = "//mat-option[@role = 'option' and @aria-selected='false']//following::span[text() = ' Active ']";
		              public static final String Checkbox_inactive_Status_unchecked_xpath = "//mat-option[@role = 'option' and @aria-selected='false']//following::span[text() = ' Inactive ']";
		              public static final String Table_Row_Inactive_Status_xpath = "(//td[@role ='gridcell' and text() = 'Inactive'])[1]";
		              public static final String Table_Row_active_Status_xpath = "(//td[@role ='gridcell' and contains(text() , 'Active')])[1]";
		              public static final String pgStatusDropDownXpath = "(//mat-select[@id='status']//following::div[@class='mat-select-arrow'])[1]";
		              
	//================================================================================================================================              
		//new xpath for initiative 	   	
		              
		               public static final String mpStartDateXpath = "//input[@id='measurement-period-start-date']";
		               public static final String mpEndDateXpath = "//input[@id='measurement-period-end-date']";
		               public static final String measurementCycleXpath = "//mat-select[@ng-reflect-placeholder='Measurement Cycle' and @ng-reflect-id='measurement-cycle']";
		               public static final String measurementCycleXbuttonXpath = "//mat-select[@ng-reflect-placeholder='Measurement Cycle' and @ng-reflect-id='measurement-cycle']//following::button[@id = 'clear']";
		               public static final String Ini_measure_tab_xpath = "//div[@class = 'mat-tab-label-content' and text() = 'Measures']";
		               public static final String iniDerivedCconstantsTabXpath = "//div[@class = 'mat-tab-label-content' and text() = 'Derived Constants']";
		               public static final String colHeaderMeasureNameXpath ="//button[@class = 'mat-sort-header-button' and contains(text() , 'Measure Name')]";
		               public static final String colHeaderMeasurDeescXpath ="//button[@class = 'mat-sort-header-button' and contains(text() , 'Measure Description')]";
		               public static final String colHeaderVersionNameXpath ="//button[@class = 'mat-sort-header-button' and contains(text() , 'Version Name')]";
		               public static final String colHeaderVersionDescXpath ="//button[@class = 'mat-sort-header-button' and contains(text() , 'Version Description')]";
		               public static final String colHeaderOrgiIdXpath ="//button[@class = 'mat-sort-header-button' and contains(text() , 'Organization ID')]";
		               public static final String colHeaderWorkflowStatusXpath ="//button[@class = 'mat-sort-header-button' and contains(text() , 'Workflow Status')]";
		               public static final String colHeaderRecordStatusXpath ="//button[@class = 'mat-sort-header-button' and contains(text() , 'Record Status')]";
		               public static final String iniMeasureAddMeasureVersiongDialogXpath ="//h2[@class = 'mat-dialog-title' and text() = 'Measure Version Search']";
		               public static final String iniMeasureAddMeasureVersiongButtonXpath ="//button[@id='add']";
		               public static final String iniMeasureFieldMeasureNameXpath ="//input[@id='measure']";
		               public static final String iniMeasureFieldVersionNameXpath ="//input[@id='version']";
		               public static final String iniMeasureSearchButtonXpath ="//button[@id='search']";
		               public static final String iniMeasureDescriptionCheckboxXpath ="(//td[contains(@class,'cdk-column-measureDescription')])[1]";
		               public static final String iniMeasureNameCheckboxXpath ="(//div[contains(@class,'mat-checkbox-inner-container')])[2]";
		               public static final String iniMeasureSelectButtonXpath ="//button[@id='select']";
		               public static final String iniMeasureCancelButtonXpath ="//button[@id='cancel']";
		               public static final String measureVersionMappeXpath= "//div[@aria-live='assertive' and text() = 'Measure version mapped']";
		               public static final String colHeaderDCStatusValueDescXpath ="//button[@class = 'mat-sort-header-button' and contains(text() , 'Value Description')]";
		               public static final String colHeaderDCStatusValueXpath ="//button[@class = 'mat-sort-header-button' and contains(text() , 'Value')]";
		               public static final String colHeaderDCStatusXpath ="//button[@class = 'mat-sort-header-button' and contains(text() , 'Status')]";
		               public static final String firstDayMeasurementPeriodDateXpath="(//td[contains(@class,'cdk-column-valueDescription ')]//following::td[contains(@class,'cdk-column-value ')])[3]";
		               public static final String organization_code_xpath= "//input[@ng-reflect-placeholder='Organization Code']";
		               public static final String source_organization_code_xpath= "//input[@ng-reflect-placeholder='Source Organization Code']";
		               public static final String measure_dd_xpath= "//mat-select[@ng-reflect-placeholder='Measure Status']";
		               public static final String assigneeNotApplicableXpath = "//span[@class='mat-option-text' and text() = ' N/A ']";

                        //public static final String MD_organization_code_xpath = "//input[@ng-reflect-placeholder='Source Organization Code']";
                       public static final String providerInfoNameXpath = "//p[@class='mat-line' and contains(text() , 'Cvs Pharmacy')]";

                       public static final String providerInfoNameCommaXpath = "//mat-card-subtitle[@class='mat-card-subtitle' and text() = ' Provider Details ']//following::p[@class='mat-line' and contains(text() , ',')]";
                       

                     //================================================================================================================================              
               		//Code Set
                       public static final String codeSetXpath = "//mat-panel-title[@class='mat-expansion-panel-header-title' and contains(text(),'Reference Data')]/following::a[@ng-reflect-router-link='code-sets']";
                       public static final String codeSetVersionXath= "//span[ contains(text() , 'Code Set Version')]";
                       public static final String codeSetVersionDropDownValueXath= "//span[@class='mat-option-text' and  contains(text() , 'Mohammed_codeset_version_test 3493')]";
                       public static final String codeSetNameXath= "//mat-select[@ng-reflect-placeholder='Code Set Name']";
                       public static final String codeSetNameXbuttonXath= "//mat-select[@ng-reflect-placeholder='Code Set Name']//following::button[@id='clear']";
                       public static final String medicationListCodeSetNameXath= "(//span[@class ='mat-option-text' and contains(text(),' Medications ')])[1]";
                       public static final String valueSetCodeSetNameXath= "(//span[@class ='mat-option-text' and contains(text(),' Fracture ')])[1]";
                       public static final String valueSetCodeSetDeleteNameXath= "(//span[@class ='mat-option-text' and contains(text(),' Fracture_delete ')])[1]";
                       
                       public static final String headerRecordStatusXath= "//button[@type = 'button' and text()= 'Record Status']";
                       public static final String eyeIconXath= "(//button[@id= 'view']//following::mat-icon[@role = 'img'])[1]";
                       public static final String titleMedicalDetailsXath= "//h2[@class = 'mat-dialog-title' and text() = 'Medication Details']";
                       public static final String genericProductNameXath= "//h2[@class = 'mat-dialog-title' and text() = 'Medication Details']//following::b[text() = 'Generic Product Name:']";
                       public static final String pakageSizeNameXath= "//h2[@class = 'mat-dialog-title' and text() = 'Medication Details']//following::b[text() = 'Package Size:']";
                       public static final String descriptionXath= "//h2[@class = 'mat-dialog-title' and text() = 'Medication Details']//following::b[text() = 'Description:']";
                       public static final String unitXath= "//h2[@class = 'mat-dialog-title' and text() = 'Medication Details']//following::b[text() = 'Unit:']";
                       public static final String routeXath= "//h2[@class = 'mat-dialog-title' and text() = 'Medication Details']//following::b[text() = 'Route:']";
                       public static final String doseXath= "//h2[@class = 'mat-dialog-title' and text() = 'Medication Details']//following::b[text() = 'Dose:']";
                       public static final String drugIdXath= "//h2[@class = 'mat-dialog-title' and text() = 'Medication Details']//following::b[text() = 'Drug ID:']";
                       public static final String formXath= "//h2[@class = 'mat-dialog-title' and text() = 'Medication Details']//following::b[text() = 'Form:']";
                       public static final String drugNameXath= "//h2[@class = 'mat-dialog-title' and text() = 'Medication Details']//following::b[text() = 'Drug Name:']";
                       public static final String medConversionFactorXath= "//h2[@class = 'mat-dialog-title' and text() = 'Medication Details']//following::b[text() = 'MED Conversion Factor:']";
                       public static final String closeButtonXath= "//button[@id='close']";
                       public static final String xButtonXath= "//button[@id='clear']";
                       public static final String coloumHeaderCodeXpath= "//button[@class = 'mat-sort-header-button' and text() = 'Code']";
                       public static final String coloumHeaderDefinitionXpath= "//button[@class = 'mat-sort-header-button' and text() = 'Definition']";
                       public static final String coloumHeaderTypeCodeXpath= "//button[@class = 'mat-sort-header-button' and text() = 'Type Code']";
                       public static final String coloumHeaderTypeDescriptionXpath= "//button[@class = 'mat-sort-header-button' and text() = 'Type Description']";
                       public static final String importButtonXpath= "//button[@id='import']";
                       public static final String codeSetFilterXpath= "//input[@id='filter']";
                       public static final String titleImportCodeSetfileXpath = "//h2[@class = 'mat-dialog-title' and text() = 'Import Code Set File']";
                       public static final String selectCsvFileXpath= "//span[@class ='mat-button-wrapper' and text() = ' Select CSV File ']";
                       public static final String uploadButtonXpath= "//span[@class ='mat-button-wrapper' and text() = ' Upload ']";
                       public static final String codeSetImportedMessageXpath="//span[contains(text(),'Your job has been successfully submitted')]";
                       public static final String templateDropDownXpath="//mat-select[@id='template-types']";
                       public static final String templateDropDownValueSetXpath="//mat-option[@role='option' and @ng-reflect-value='VAL_SET']";
                       public static final String templateDropDownMedListXpath="//mat-option[@role='option' and @ng-reflect-value='MED_LIST']";
                       public static final String appendRadioButtontXpath="(//mat-radio-group[@role = 'radiogroup']//following::mat-radio-button[@tabindex='-1'])[1]";
                       public static final String deleteAndInsertRadioButtontXpath="(//mat-radio-group[@role = 'radiogroup']//following::mat-radio-button[@tabindex='-1'])[2]";
                       public static final String latestStatusDateXpath="(//td[contains(@class,'cdk-column-latest-status-date')])[1]";
                       public static final String jobRunManagerJobNameXpath="(//td[contains(@class,'cdk-column-job-name')])[1]";
                       
                       public static final String latestStatusDateHeaderXpath="//th[@id = 'latest-status-date-header']";
                       public static final String latestStatusDateAscendingXpath="//th[@id = 'latest-status-date-header' and @aria-sort = 'ascending']";
                       public static final String latestStatusDatedescendingXpath="//th[@id = 'latest-status-date-header' and @aria-sort = 'descending']";
                       public static final String codeSetVersionXpath="//button[@id='code-set-version']";
                       public static final String codeSetVersionDialogBoxXpath="//h2[@class='mat-dialog-title' and contains(text(),' New Code Set Version')]";
                       public static final String codeSetVersionNameXpath="//input[@id='name']";
                       public static final String codeSetVersionDescXpath="//input[@id='description']";
                       public static final String codeSetVersionOrgXpath="//mat-select[@id='organization' and @aria-required='true']";
                       public static final String codeSetVersionSourceXpath="//mat-select[@id='source' and @aria-required='true']";
                       public static final String codeSetVersionStartDateXpath="//input[@id='start-date' and @aria-required='true']";
                       public static final String codeSetVersionEndDateXpath="//input[@id='end-date' and @aria-required='true']";
                       public static final String codeSetVersionAddButtonXpath="//button[@id='add']";
                       public static final String existingCodeSetVersionNameXpath = "//span[@class = 'mat-option-text' and contains(text() ,' "+testCodeSet.user+" ')]";
                       public static final String sortAscorderXpath = "//th[contains(@class,'mat-column') and @aria-sort='ascending']";
                       public static final String sortDescndorderXpath = "//th[contains(@class,'mat-column') and @aria-sort='descending']";
                       public static final String codeNameXpath="(//td[contains(@class,'cdk-column-code')])[1]";
                       public static final String definitionNameXpath="(//td[contains(@class,'cdk-column-definition')])[1]";
                       
                       //======================================================================================================================================
                       //Job Queue
                       public static final String jobQueueXpath="//mat-panel-title[@class='mat-expansion-panel-header-title' and text() = ' Job Queue ']";
                       public static final String jobTypeLibraryXpath="//div[@class='mat-list-item-content' and contains(text(), 'Job Type Library')]";
                       public static final String jobRunManagerXpath="//div[@class='mat-list-item-content' and text() = ' Job Run Manager ']";
                       public static final String jobNameXpath="//td[contains(@class,'cdk-column-job-name')]";
                       public static final String headerJobTypeXpath="//button[@class='mat-sort-header-button' and contains(text(),' Job Type ')]";
                       public static final String headerJobNameXpath="//button[@class='mat-sort-header-button' and contains(text(),' Job Name ')]";
                       public static final String headerRequestingUserXpath="//button[@class='mat-sort-header-button' and contains(text(),' Requesting User ')]";
                       public static final String headerCreatedOnXpath="//button[@class='mat-sort-header-button' and contains(text(),' Created On ')]";
                       public static final String headerLastStatusDateXpath="//button[@class='mat-sort-header-button' and contains(text(),' Latest Status Date ')]";
                       public static final String headerLatestStatusXpath="(//button[@class='mat-sort-header-button' and contains(text(),'Latest Status')])[2]";
                       public static final String headerElapsedTimeXpath="//button[@class='mat-sort-header-button' and contains(text(),' Elapsed Time ')]";
                       
                       public static final String elapsedTimeXpath="(//td[contains(@class,'cdk-column-elapsed-run-time')])[1]";
                       public static final String headerNotesXpath="//button[@class='mat-sort-header-button' and contains(text(),' Notes ')]";
                       public static final String headerActionsXpath="//th[@id='actions-header' and contains(text(),' Actions ')]";
                       public static final String documentCreatedRowJobTypeXpath = "(//td[contains(@class,'cdk-column-job-type')])[1]";
                       public static final String requestingUserXpath= "(//mat-card-title[contains(text(),' Job Run Manager')]//following::td[contains(@class,'cdk-column-requesting-user')])[1]";
                       public static final String jobRunDeatilButtonXpath= "(//mat-card-title[contains(text(),' Job Run Manager')]//following::button[contains(@id, 'view')])[1]";
                       public static final String jobRunDeatilTitleXpath= "//mat-card-title[@class ='mat-card-title' and contains(text(),' Job Run Detail ')]";
                       
                       
                       public static final String jobRunDeatilStatusColXpath= "(//button[@class='mat-sort-header-button' and contains(text(),' Status')])[1]";
                       public static final String jobRunDeatilStatusDateColXpath= "//button[@class='mat-sort-header-button' and contains(text(),' Status Date')]";
                       public static final String jobRunDeatilNotesColXpath= "//button[@class='mat-sort-header-button' and contains(text(),'Notes')]";
                       public static final String jobRunDeatilStatusColAscendingOrderXpath= "//th[@id='status-header' and @aria-sort='ascending']";
                       public static final String jobRunDeatilStatusDateAscendingOrderXpath= "//th[@id='status-date' and @aria-sort='ascending']";
                       public static final String jobRunDeatilNotesAsscendingOrderXpath= "//th[@id='notes-header' and @aria-sort='ascending']";
                       public static final String jobRunDeatilStatusColDescendingOrderXpath= "//th[@id='status-header' and @aria-sort='descending']";
                       public static final String jobRunDeatilStatusDateDescendingOrderXpath= "//th[@id='status-date' and @aria-sort='descending']";
                       public static final String jobRunDeatilNotesDescendingOrderXpath= "//th[@id='notes-header' and @aria-sort='descending']";
                       public static final String jobRunDetainlColumnStatusNameXpath = "(//td[contains(@class,'cdk-column-status')])[1]";
                       public static String statusDateXpath = "(//td[contains(@class,'cdk-column-status-date')])[1]";
                       
                       
                       public static final String headerJTLNameXpath="//button[@class='mat-sort-header-button' and contains(text(),'Name')]";
                       public static final String headerJTLDescriptionXpath="//button[@class='mat-sort-header-button' and contains(text(),'Description')]";
                       public static final String headerJTLModifiedOnXpath="//button[@class='mat-sort-header-button' and contains(text(),'Modified On')]";
                       public static final String headerJTLMOdifiedByXpath="//button[@class='mat-sort-header-button' and contains(text(),'Modified By')]";
                       public static final String jobTypeLibNameValueXpath= "(//td[contains(@class,'cdk-column-name')])[1]";
                       public static final String jobTypeLibDescValueXpath= "(//td[contains(@class,'cdk-column-description')])[1]";
                       
                       public static final String serviceCompFSAXpath="//span[contains(@class,'mat-option-text') and contains(text(),'CMP_FSA - Functional Status Assessment Composite')]";
                       public static final String serviceCompRotaVirusXpath="//span[contains(@class,'mat-option-text') and contains(text(),' CMP_ROTAVIRUS - ROTAVIRUS Composite Test ')]";
                       
                       public static final String warningRedForFSAXpath="//span[contains(text(),'Please ensure at least 1 component service is  entered')]/preceding::mat-icon[@role='img' and text()='error_outline']";
                	   
                	 
                	   public static final String tabAmbulationXpath="//span[contains(text(),'AMBULATION')]";
                	   public static final String tabCogstatusXpath ="//span[contains(text(),'COGSTATUS')]";
                	   public static final String tabHearingXpath ="//span[contains(text(),'HEARING')]";
                	   public static final String tabOtherfiXpath="//span[contains(text(),'OTHERFI')]";
                	   public static final String tabSpeechXpath ="//span[contains(text(),'SPEECH')]";
                	   public static final String tabVisionXpath ="//span[contains(text(),'VISION')]";
                	   public static final String warningImgXpath ="//mat-icon[@role='img' and contains(text(),'warning')]";
                	   public static final String statusTypeDropDownXpath ="//mat-select[@id='status-type']";
                	   public static final String statusTypeDrDwApprooveXpath ="//span[@class='mat-option-text' and contains(text(),'Approved')]";
                	   public static final String statusTypeDrDwNotApprooveXpath ="//span[@class='mat-option-text' and contains(text(),' Not Approved')]";
                	   public static final String statusTypeDrDwVoidXpath ="//span[@class='mat-option-text' and contains(text(),'Void')]";
                	   
                	   
                	   public static final String tabRotaVirus2D1Xpath="(//span[contains(text(),'ROTAVIRUS2D')])[1]";
                	   public static final String tabRotaVirus2D2Xpath="(//span[contains(text(),'ROTAVIRUS2D')])[2]";
                	   public static final String tabRotaVirus3D1Xpath="(//span[contains(text(),'ROTAVIRUS3D')])[1]";
                	   public static final String tabRotaVirus3D2Xpath="(//span[contains(text(),'ROTAVIRUS3D')])[2]";
                	   public static final String tabRotaVirus3D3Xpath="(//span[contains(text(),'ROTAVIRUS3D')])[3]";
                	   
                	   
                	   
                	   public static final String checkedCompBpSysXpath="(//span[contains(text(),'BPSYSTOLIC service must be entered at least 1 time')]/preceding::mat-icon[@role='img' and text()='check_circle'])[2]";
                	   public static final String checkedCompBpDiaXpath="//span[contains(text(),'BPDIASTOLIC service must be entered at least 1 time')]/preceding::mat-icon[@role='img' and text()='check_circle']";
                	   public static final String editedNotesCompFSAXpath="(//td[@role = 'gridcell' and  contains(text(),'AMBULATION')]//following::td[contains(@class,'cdk-column-notes') and contains(text(),'Updated FSA notes')])[1]";
                	   public static final String editedNotesCompRotaVirusXpath="(//td[@role = 'gridcell' and  contains(text(),'ROTAVIRUS2D')]//following::td[contains(@class,'cdk-column-notes') and contains(text(),'Updated RotaVirus notes')])[1]";
                       
                     // Verify Navigation-Menu-Expand-Collapse feature
                	   
                	   public static final String navigationListXpath ="(//mat-nav-list[@class='mat-nav-list mat-list-base' and @role = 'navigation'])[1]";
                	   public static final String navigationBarOpenXpath ="//mat-icon[@role = 'img' and contains(text(),'chevron_left')]";
                	   public static final String navigationBarCloseXpath ="//mat-icon[@role = 'img' and contains(text(),'chevron_right')]";
                	   
                	   
                	
                		public static final String adminJobQueueDrpdwnExpandedXpath ="//mat-panel-title[contains(text(),'Job Queue')]/parent::span/parent::mat-expansion-panel-header[@aria-expanded='true']";
                		
                		public static final String adminJobQueueDrpdwnCollapsedXpath ="//mat-panel-title[contains(text(),'Job Queue')]/parent::span/parent::mat-expansion-panel-header[@aria-expanded='false']";
                		
                		public static final String adminAuditsDrpdwnExpandedXpath ="//mat-panel-title[contains(text(),'Audits')]/parent::span/parent::mat-expansion-panel-header[@aria-expanded='true']";
                		
                		public static final String adminAuditsDrpdwnCollapsedXpath ="//mat-panel-title[contains(text(),'Audits')]/parent::span/parent::mat-expansion-panel-header[@aria-expanded='false']";
                		
                	   
                	   
                       
                      
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       


}
