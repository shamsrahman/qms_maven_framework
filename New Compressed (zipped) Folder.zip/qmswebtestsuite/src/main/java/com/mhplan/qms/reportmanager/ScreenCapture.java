package com.mhplan.qms.reportmanager;




import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

import com.mhplan.qms.DriverScript;

public class ScreenCapture {
	public static String screenShotCapture(String path) throws Exception {
		Robot robot = new Robot();
		String filePath = path;
		File file = new File(filePath);
		file.mkdir();
		String imgfileName = DriverScript.Test_Case_ID+"_" + PrepareReport.getCurrentTimeStamp("yyyy_MM_dd_hh_mm_ss_a") + ".png"; //"yyyy_MM_dd:hh:mm:ss a"
		BufferedImage screenShot = robot.createScreenCapture(new Rectangle(
				Toolkit.getDefaultToolkit().getScreenSize()));
		ImageIO.write(screenShot, "PNG", new File(filePath + "/" + imgfileName)); //LVCOMMENTED-0826
		return imgfileName;
	}
}

