package com.mhplan.qms.ConfigManager;
public class SQLConfig {

	
	//SQL Quries will go here
}
