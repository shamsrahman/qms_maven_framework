package com.mhplan.qms;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import jxl.read.biff.BiffException;
//import oracle.jdbc.OracleConnection;
//import oracle.jdbc.OracleResultSet;
//import oracle.jdbc.OracleStatement;

import org.apache.http.entity.StringEntity;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.mhplan.qms.ConfigManager.FileLoc;
import com.mhplan.qms.UtilManager.ExcelUtility;
import com.mhplan.qms.UtilManager.PropertiesUtility;
import com.mhplan.qms.common.BaseClass;
import com.mhplan.qms.reportmanager.PrepareReport;

//public class DriverScript extends TestCaseSpecificClass {
public class DriverScript extends BaseClass{

String header = null;
public static String indexHeader = null;
public static String indexHeader_email = null;
//public static String[] sheetNames; 
//Master Sheet Global Variables
//public static String sheet = null;
public static String rowid = null;
public static int iRowId;
public static int iTotalTestSetRows;
public static int iMasterRowId;
public static String sMachine = null;
public static String sAppUrl = null; 
public static String sUsername = null;
public static String sPassword = null;
public static String sMySQL_URL = null;
public static String sDB_UserName = null;
public static String sDB_Password = null;
public static String sWorkingDirPath;
public static int i;
public static boolean bSwitchFrame=false;

public static String htmlLink = null; // htmlLink to index file
public static String folderPath = null; // local report folder

public static String Environment; // IDT5, etc
public static String Phase; // Smoke, Regression, SIT
public static String Release; // release build: 5.2, 5.3, etc.s
public static String Application; // 
//public static String Country; // CDMA, Europe, etc.
public static String SuiteName; //Test Suite Name

public static int iTC_ID; // keep track of the testID
public static String Test_Case_ID; // keep track of the testID
public static String Test_Case_Name; // keep track of the tcName
public static String Test_Case_Description; // keep track of the testID

public static String Production; // Pre_Production or Production

public static Properties objMapProp=null; // load object repository properties for map

public static Properties objWebActivitiesProp = null;
//public static OracleResultSet rset=null;
//public static OracleStatement stmt=null;
//public static OracleConnection ocon=null;
//public static  HashMap<Integer, HashMap<String, String>> mExcelData=null;
public static  HashMap<Integer, HashMap<String, String>> mMasterSheetData=null;
public static  HashMap<Integer, HashMap<String, String>> mTestSetSheetData=null;
public static  HashMap<Integer, HashMap<String, String>> mEnvTestData=null;
public static String sSoapActionUrl; // keep track of the testID
public static String sIndexHTMLFileName=""; // keep track of the testID
public static String sIndexHTMLFileNameemail=""; // keep track of the testID
//final Logger logger = Logger.getLogger(this.getClass().getName());
//final Logger logger = Logger.getLogger(this.getClass().getName());
public static Logger log = Logger.getLogger(DriverScript.class.getName());//
ExcelUtility objExcelUtility = new ExcelUtility();
PropertiesUtility objPropertiesUtility = new PropertiesUtility();
//DBUtility objDBUtility = new DBUtility();
@BeforeMethod
public void beforeMethod() {
System.out.println("@BeforeMethod");
}
@AfterMethod
public void afterMethod() {
System.out.println("@AfterMethod");
}
@BeforeTest
public void beforeTest() {
System.out.println("@BeforeTest");
try {
// ExecuteCommand("C:\\Automation\\killprocess.bat");
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
prop = objPropertiesUtility.fnLoadObjects(FileLoc.sConfigPath, "global.properties");
    
}

@AfterTest
public void afterTest() {
System.out.println("@AfterTest");
if (driver != null)
driver.quit();
if (incdriver != null)
incdriver.quit();

try {
//// ExecuteCommand("C:\\Automation\\killprocess.bat");
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}


// ============================================================ DRIVER SCRIPT ============================================================

@Test
public void run() throws Exception {

try {
String sWorkingDir = System.getProperty("user.dir"); 
sWorkingDirPath=sWorkingDir;
String sPackageClass = "";
sPackageClass = this.getClass().getPackage().getName();
System.out.println(sPackageClass);
DOMConfigurator.configure(FileLoc.sConfigPath+"log4j.xml");
//SimpleDateFormat logFileDateFormat = new SimpleDateFormat("yyyy-MM-dd");
//System.setProperty("current.date", logFileDateFormat.format(new Date()));
log.info("First Log4j Message");

mMasterSheetData = objExcelUtility.fnGetExcelData(FileLoc.sTestDataPath+ FileLoc.sFileName,"Master", "");
for (int masterRow = 1; masterRow <= mMasterSheetData.size(); masterRow++) 
{ 
//iMasterRowId = Integer.toString(masterRow);
iMasterRowId = masterRow;

if(mMasterSheetData.get(masterRow).get("FLAG").equalsIgnoreCase("Y")) 
{
Environment = mMasterSheetData.get(masterRow).get("Environment");
Application = mMasterSheetData.get(masterRow).get("Application");
Production = mMasterSheetData.get(masterRow).get("Production");
Phase = mMasterSheetData.get(masterRow).get("Phase");
Release = mMasterSheetData.get(masterRow).get("Release");

SuiteName = mMasterSheetData.get(masterRow).get("Suite_Name");
//sheet = mMasterSheetData.get(masterRow).get("Phase");
sMachine = mMasterSheetData.get(masterRow).get("Machine").toString().trim();
sAppUrl = mMasterSheetData.get(masterRow).get("AppUrl").toString().trim();
sUsername = mMasterSheetData.get(masterRow).get("Username").toString().trim();
sPassword = mMasterSheetData.get(masterRow).get("Password").toString().trim();
sMySQL_URL = mMasterSheetData.get(masterRow).get("MySQL_URL").toString().trim();
sDB_UserName = mMasterSheetData.get(masterRow).get("DB_UserName").toString().trim();
sDB_Password = mMasterSheetData.get(masterRow).get("DB_Password").toString().trim();

System.out.println("Environment....." + Environment);
System.out.println("Application....." + Application);
System.out.println("Production....." + Production);
System.out.println("Phase....." + Phase);
System.out.println("Release....." + Release);
System.out.println("SuiteName....." + SuiteName);
System.out.println("sMachine....." + sMachine);
System.out.println("sAppUrl....." + sAppUrl);
System.out.println("sUsername....." + sUsername);


indexHeader = PrepareReport.repGenerateIndexHeader(Environment, Application, Production, Phase);
indexHeader_email = PrepareReport.repGenerateIndexHeaderemail(Environment, Application, Production, Phase);
mTestSetSheetData = objExcelUtility.fnGetExcelData(FileLoc.sTestDataPath+ FileLoc.sFileName,"TestSet",""); //Get TestSet hash map 
mEnvTestData = objExcelUtility.fnGetExcelData(FileLoc.sTestDataPath+ FileLoc.sFileName,Phase, "Test_Case_ID");    //Get Smoke/SIT/Regression hash map 

/////////////////////////////////////////////
//for (int iTCRow = 1; iTCRow <=mTestSetSheetData.size(); iTCRow++)
for (int iTCRow = 1; iTCRow <=iTotalTestSetRows; iTCRow++)
{  
//RowId = Integer.toString(iTCRow);
iRowId=iTCRow;
if(mTestSetSheetData.containsKey(iTCRow))
{
Test_Case_ID = mTestSetSheetData.get(iTCRow).get("Test_Case_ID");
iTC_ID = Integer.parseInt(Test_Case_ID);
if( mTestSetSheetData.get(iTCRow).get(Phase).equalsIgnoreCase("Y"))  //Test case check
{ 
   sIndexHTMLFileName="index.html";   //in case data is missing for a test case, index.html would be default index file, else will be overridden as below 
   try {
if(mEnvTestData.get(iTC_ID)!=null)
{
//sIndexHTMLFileName = "index_"+mEnvTestData.get(iTC_ID).get("Test_Case_ID")+"_"+InetAddress.getLocalHost().getHostName()+".html";
sIndexHTMLFileName = "index_"+mMasterSheetData.get(masterRow).get("Phase")+"_"+InetAddress.getLocalHost().getHostName()+".html";
sIndexHTMLFileNameemail = "index_"+mMasterSheetData.get(masterRow).get("Phase")+"_"+InetAddress.getLocalHost().getHostName()+"_email"+".html";
//WebServiceClientUtility.fnGAAPreCondition(); --Commented by LV
//Overriding with specific user id/password if any, else use credential from master sheet
if(!mEnvTestData.get(iTC_ID).get("Username").equalsIgnoreCase("") && !mEnvTestData.get(iTC_ID).get("Password").equalsIgnoreCase(""))
{
sUsername= mEnvTestData.get(iTC_ID).get("Username").toString().trim();
sPassword= mEnvTestData.get(iTC_ID).get("Password").toString().trim();
}
}
else
{
log.info("Test case failed for Test Case ID"+Test_Case_ID+". Function or Data missing...");
}
} catch (Exception e) {
log.error("Test case failed for Test Case ID"+Test_Case_ID+". Data missing or Web service failure ",e);
} 
try 
{
Test_Case_Name = mTestSetSheetData.get(iTCRow).get("Test_Case_Name");
Test_Case_Description = mTestSetSheetData.get(iTCRow).get("Test_Case_Description");
fnInitializeGlobalVariables();
fnExecuteFunction(sPackageClass+ "."+Phase+"Testcases", mTestSetSheetData.get(iTCRow).get("FunctionName"));
} catch (Exception e) 
{
System.out.println("@@@ Exception in executeTest @@@");
System.out.println(e);
}
}
}
else
{
System.out.println("No Test Case present at row : " + iTCRow);
log.info("No Test Case present at row : " + iTCRow);
}
} //End Test case loop
try {
if (driver!=null)
{
fnSignOutTC();
} 
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
finally
{
System.out.println("Local HTML report folder: " + folderPath);
System.out.println("Local HTML report index: " + folderPath + "/" + sIndexHTMLFileName);
obj.createTestResultsWithTimestamp(folderPath);
//obj.fnWriteResultsToATMDB(htmlLink);
PrepareReport.openHTMLreport(); 
PrepareReport.slNo = 0;
PrepareReport.totalExecuted = 0;
PrepareReport.totalPass = 0;
PrepareReport.totalFail = 0;
}
}
} // End of Suite/Master sheet loop

} catch (Exception e) {
if (driver!=null)
{
fnSignOutTC();
}
System.out.println(e);
}

finally {
obj = null;
}

}


// ============================================================ DRIVER SCRIPT ============================================================

} // end of Test

