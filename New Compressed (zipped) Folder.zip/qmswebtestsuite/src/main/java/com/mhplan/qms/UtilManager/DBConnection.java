package com.mhplan.qms.UtilManager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	public final static Connection getConnection(String url, String loginName, String Password) throws Exception

	{

		Connection connection = null;
		try {

			connection = DriverManager.getConnection(url, loginName, Password);

			System.out.println(connection);

		} catch (Throwable t) {

			System.out.println("Connection Failed! Check output console");
			t.printStackTrace();

		}

		if (connection != null)

		{
			System.out.println("You made it, take control your database now!");
		} else

		{
			System.out.println("Failed to make connection!");
		}

		return connection;

	}

	public final static Connection closeConnection(Connection connection) throws SQLException {

		if (connection != null)

		{
			connection.close();

		}
		return connection;
	}
}
