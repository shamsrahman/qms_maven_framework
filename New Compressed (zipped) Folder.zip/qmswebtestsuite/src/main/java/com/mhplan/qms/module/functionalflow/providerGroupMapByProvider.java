//Test case is to verify the functionality of Matching a provider group  search by provider.

package com.mhplan.qms.module.functionalflow;

import java.util.List;
import com.mhplan.qms.DriverScript;
import com.mhplan.qms.ObjectRepository.Admin;
import com.mhplan.qms.ObjectRepository.ProviderGrpEditButton;
import com.mhplan.qms.UtilManager.CommonDAO;
import com.mhplan.qms.UtilManager.SQLMap;

public class providerGroupMapByProvider extends DriverScript {

	testProviderGroup TPG = new testProviderGroup();
	CommonDAO dao = new CommonDAO();
	private static String providerId;
	public static String user;
	public int Randinit;
	public int i;


	public boolean ProvidergroupMapping() {

		boolean returnresult = true;

		try {
			obj.repAddData("Provider Group Mapping", "", "", "");

			List<SQLMap> providerGroupMappingDetails = dao.getProviderId(DriverScript.sMySQL_URL, dao.ProviderId_query,
					DriverScript.sDB_UserName, DriverScript.sDB_Password);

			if (providerGroupMappingDetails != null) {

				providerId = providerGroupMappingDetails.get(i).getProviderId();
				obj.repAdddbData("Query Results", "Database Query results in ProviderId",
						"Database Query results in ProviderId", "Pass");
				log.info(providerId);

				// Calling following methods
				TPG.providerGroupStart();
				// TPG.itemPerPageDroDown();
				existingProviderGroupMapButton();
				searchPage();
				mapAndUnmap();

			} else {

				obj.repAdddbData("Query Results", "Database Query results in ProviderId",
						"Database Query doesn't result in ProviderId", "Fail");
			}

		} catch (Exception e) {
			close_add_prov_grp_dialog();
			DriverScript.log.info(e);
			returnresult = false;
		}

		try {
			// Switching the application
			clickByXpath(Admin.SwitchApplications_Admin_XPATH, "Switch Application");
		} catch (Exception e) {
			DriverScript.log.info(e);

		}
		return returnresult;

	}

	public boolean close_add_prov_grp_dialog() {
		boolean returnresult = true;
		try {
			// If provider search title dialog is exists more than 45 seconds then click on
			// the cancel button.
			if (fnWaitForObjectExist(45, Admin.title_provider_search, "Provider Group dialog"))
				clickByXpathJS(Admin.PG_cancel_button, "cancel button", 0);
		} catch (Exception e) {
			DriverScript.log.info(e);
			returnresult = false;
		}
		return returnresult;
	}

	public boolean existingProviderGroupMapButton() {
		boolean returnresult = true;
		try {
			// Clicking on existing provider group mapping button.
            sendKeyByXpath(Admin.filterTextFiledXpath ,TPG.username," Provider Group Name");
			fnWaitForObjectExist(30, ProviderGrpEditButton.existingProviderGroupActiveStatus, " Active Status");
			clickByXpath(ProviderGrpEditButton.existingProviderGroupMappingButton, "  Mapping button");
		} catch (Exception e) {
			DriverScript.log.info(e);
			returnresult = false;
		}
		return returnresult;
	}

	public boolean searchPage() {
		boolean returnresult = true;
		try {

			// Provider Search
			clickByXpath(Admin.PG_search_icon, " Search icon");
			sendKeyByXpath(Admin.PG_id_field, providerId, "Provider Id");
			clickByXpath(Admin.PG_search_button, " Search button");
			fnWaitForObjectExist(45, Admin.title_provider_search, "Provider search dialog");
			Thread.sleep(4000);
			count = getCountXpath(10, Admin.PG_provider_list);
			System.out.println("The totla count is " + count);

			for (int i = 1; i < count; ++i) {
				clickByXpathJS(Admin.PG_provider_list, "Provider list", i);
			}

			clickByXpath(Admin.PG_select_button, " Select button");
		} catch (Exception e) {
			DriverScript.log.info(e);
			returnresult = false;
		}
		return returnresult;
	}

	public boolean mapAndUnmap() {
		boolean returnresult = true;
		try {
			// Adding and removing provider .
			fnWaitForObjectExist(45, Admin.available_provider_xpath, "Available Provider");
			count = getCountXpath(10, Admin.available_provider_checkbox);
			Randinit = fnRandomtwoNum(1, count - 1);
				
			//Clicking randomly on Available Providers check box.
			clickByXpathJS(Admin.available_provider_checkbox, "Provider list",Randinit);
			clickByXpath(Admin.map_button_xpath, " Map button");
			fnWaitForObjectExist(45, Admin.msg_provider_mapped, "Mapping have been");
			
			//Clicking on the first record of Providers Mapped check box.
			clickByXpathJS(Admin.provider_mapped_checkbox, "Provider list", 1);
			clickByXpath(Admin.unmap_button_xpath, " Unmap button");
			fnWaitForObjectExist(20, Admin.msg_provider_unmapped, "Mapping have been");
			clickByXpathJS(Admin.available_provider_checkbox1, "Provider list", 0);
			fnWaitForObjectExist(45, Admin.map_button_xpath, "Map button");
			clickByXpath(Admin.map_button_xpath, " Map button");
			clickByXpathJS(Admin.provider_mapped_checkbox1, "Provider list", 0);
			fnWaitForObjectExist(45, Admin.unmap_button_xpath, "Unmap button");
			clickByXpath(Admin.unmap_button_xpath, " Unmap button");
			fnWaitForObjectExist(20, Admin.msg_provider_unmapped, "Mapping have been");

		} catch (Exception e) {
			DriverScript.log.info(e);
			returnresult = false;
		}
		return returnresult;
	}
}
