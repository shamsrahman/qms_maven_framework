//Test case is to verify the functionality of Matching a provider group  search by location.


package com.mhplan.qms.module.functionalflow;
import java.util.List;
import com.mhplan.qms.DriverScript;
import com.mhplan.qms.ObjectRepository.Admin;
import com.mhplan.qms.ObjectRepository.ProviderGrpEditButton;
import com.mhplan.qms.UtilManager.CommonDAO;
import com.mhplan.qms.UtilManager.SQLMap;


public class providerGroupMapByLocation extends DriverScript {
	testProviderGroup TPG = new testProviderGroup();
	providerGroupMapByProvider TPGMBP = new providerGroupMapByProvider();
	CommonDAO dao = new CommonDAO();
	private static String locationId;
	public int Randinit;
	public static String user;

	public boolean ProvidergroupMapping(){

		boolean returnresult = true;
		

		try {
			    obj.repAddData("Provider Group Mapping", "", "", "");
			    
			    List<SQLMap> locationGroupMappingDetails = dao.getLocationId(DriverScript.sMySQL_URL, dao.LocationId_query,
						DriverScript.sDB_UserName, DriverScript.sDB_Password);

				if (locationGroupMappingDetails != null) {

					locationId = locationGroupMappingDetails.get(i).getLocationId();
					obj.repAdddbData("Query Results", "Database Query results in LocationId",
							"Database Query results in LocationId", "Pass");
					log.info(locationId);
			    
			     //Calling following methods
			     TPG.providerGroupStart();
                 TPGMBP.existingProviderGroupMapButton();
			     searchPage();
			     TPGMBP.mapAndUnmap();
			     clickByXpath(Admin.provider_group," Click on provider group");
			     deleteRecord();
				 driver.switchTo().alert().dismiss();
				 deleteRecord();
			     driver.switchTo().alert().accept();
			     inactivDeleteButton();
			     
			     
				} else {

					obj.repAdddbData("Query Results", "Database Query results in LocationId",
							"Database Query doesn't result in LocationId", "Fail");
				}
			   
			 
		}catch(Exception e) {
			close_add_prov_grp_dialog();
			DriverScript.log.info(e);
			returnresult=false;
		}

		try {
			//Switching the application
			clickByXpath(Admin.SwitchApplications_Admin_XPATH,"Switch Application");
		}
			   catch(Exception e) {
				DriverScript.log.info(e);
				
			}	
				return returnresult;
				
		}
	
	public boolean close_add_prov_grp_dialog(){
		boolean returnresult = true;
		try {
			// If location search title dialog is exists more than 45 seconds then click on the cancel button.
			if (fnWaitForObjectExist (45,Admin.title_locaation_search , "Location Search dialog"))
				clickByXpathJS(Admin.PG_cancel_button,"cancel button",0);
		}catch(Exception e) {
			DriverScript.log.info(e);
			returnresult=false;
		}
		return returnresult;
	}
	

	
	public boolean deleteRecord(){
		boolean returnresult = true;
		try {
			//Deleting provider group.
            sendKeyByXpath(Admin.filterTextFiledXpath ,TPG.username," Provider Group Name");
			clickByXpath(ProviderGrpEditButton.existingProviderGroupDeleteButton,"  Delete button");
	
		}catch(Exception e) {
			DriverScript.log.info(e);
			returnresult=false;
		}
		return returnresult;
	}
	
	public boolean searchPage(){
		boolean returnresult = true;
		try {
			//Provider search.
			   clickByXpath(Admin.PG_location_radio_box," Location Radio box");
			    clickByXpath(Admin.PG_loc_search_icon," Location Search icon");
			    fnWaitForObjectExist(20,Admin.PG_loc_search_dialog,"Location Search");
			    sendKeyByXpath(Admin.PG_loc_id_field, locationId, "Location Id");
			    clickByXpath(Admin.PG_search_button," Search button");
			    fnWaitForObjectExist(45,Admin.title_locaation_search,"Location search dialog");
			    Thread.sleep(4000);
			    count = getCountXpath(10, Admin.PG_location_list);
				for(int i=1;i<count;++i) {
					clickByXpathJS(Admin.PG_location_list ,"Location list",i);
				    }
			    clickByXpath(Admin.PG_select_button," Select button");
	
		}catch(Exception e) {
			DriverScript.log.info(e);
			returnresult=false;
		}
		return returnresult;
	}

	
	public boolean inactivDeleteButton(){
		boolean returnresult = true;
		try {
			  //Verifying provider group deleted and button is inactinve. 
			 clickByXpath(Admin.Status_dropdown_xpath," Status Drop down");
			 clickByXpath(Admin.Checkbox_inactive_Status_unchecked_xpath," Inactive Status");
		     fnWaitForObjectExist (30,ProviderGrpEditButton.existingProviderGroupInactiveStatus , " Inactive Status");
		     doubleClickByXpath(Admin.field_filter," Filter box");
		}catch(Exception e) {
			DriverScript.log.info(e);
			returnresult=false;
		}
		return returnresult;
	}
	
}
