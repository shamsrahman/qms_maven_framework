package com.mhplan.qms.ConfigManager;


public class FileLoc {

	public static final String sProjPath = System.getProperty("user.dir")+"//";
	public static final String sTestDataPath = System.getProperty("user.dir")+"//src/main//resources//TestData//";
	public static final String sConfigPath = System.getProperty("user.dir")+"//src/main//resources//config//";
	public static final String sFileName = "QMS_Automation_Data.xls";
	public static final String sPropFile = System.getProperty("user.dir")+"//src/main//resources//config//global.properties"; // properties file
	public static final String sObjRepPath = "src//main//java//com//mhplan//qms//ObjectRepository//"; // object repository folder path
	public static final String sReportsPath =System.getProperty("user.dir")+"/HTMLFiles";
	public static final String sChromeDriverPath = System.getProperty("user.dir")+"//src//main//resources//config//";
	public static final String sFilePath = System.getProperty("user.dir")+"//src//main//resources//config//MRAttachments//";
	public static final String sReportPath = "D://Users//n8238//Downloads//";
	
}
