package com.mhplan.qms;

import com.mhplan.qms.module.functionalflow.ChaseManagement_SortFilter;
import com.mhplan.qms.module.functionalflow.ActiveInactiveServiceType;
import com.mhplan.qms.module.functionalflow.AddMedicalRecords;
import com.mhplan.qms.module.functionalflow.TestAdminDocument;
import com.mhplan.qms.module.functionalflow.testAdminDocumentNegativeTestCase;
import com.mhplan.qms.module.functionalflow.testAdminInitiatives;
import com.mhplan.qms.module.functionalflow.testAdminInitiativesNegScenario;
import com.mhplan.qms.module.functionalflow.testAdminMeasureDefinition;
import com.mhplan.qms.module.functionalflow.testAdminMeasureElement;
import com.mhplan.qms.module.functionalflow.testCodeSet;
import com.mhplan.qms.module.functionalflow.testAdminMeasureVersion;
import com.mhplan.qms.module.functionalflow.testAdminServiceTxt;
import com.mhplan.qms.module.functionalflow.testAdminServiceUpdate;
import com.mhplan.qms.module.functionalflow.testAdminUpdateDocument;
import com.mhplan.qms.module.functionalflow.testAuditGenerator;
import com.mhplan.qms.module.functionalflow.testAdminServiceMapping;
import com.mhplan.qms.module.functionalflow.TestAdminServiceNegativeScenario;
import com.mhplan.qms.module.functionalflow.TestAuditGeneratorRunLabel;
import com.mhplan.qms.module.functionalflow.testAdminServiceNumeric;
import com.mhplan.qms.module.functionalflow.TestAuditRules;
import com.mhplan.qms.module.functionalflow.TestBadLogin;
import com.mhplan.qms.module.functionalflow.testChaseGenerator;
import com.mhplan.qms.module.functionalflow.testChaseRules;
import com.mhplan.qms.module.functionalflow.testOrganization;
import com.mhplan.qms.module.functionalflow.testProviderGroup;
import com.mhplan.qms.module.functionalflow.TestUpdateInitiative;
import com.mhplan.qms.module.functionalflow.testUpdateMeasureDefinition;
import com.mhplan.qms.module.functionalflow.testUpdateMeasureElements;
import com.mhplan.qms.module.functionalflow.testUsers;
import com.mhplan.qms.module.functionalflow.providerGroupMapByLocation;
import com.mhplan.qms.module.functionalflow.providerGroupMapByProvider;
import com.mhplan.qms.module.functionalflow.ReadOnlyMedRec;
import com.mhplan.qms.module.functionalflow.AddRecordinAppmntMngmnt;
import com.mhplan.qms.module.functionalflow.AppointmentManagement;
import com.mhplan.qms.module.functionalflow.AuditGenRunLabelForInitiativeWrkflStatus;
import com.mhplan.qms.module.functionalflow.AuditManagement;
import com.mhplan.qms.module.functionalflow.CareGaps;
import com.mhplan.qms.module.functionalflow.ChaseManagement;
import com.mhplan.qms.module.functionalflow.ChaseMemberList;
import com.mhplan.qms.module.functionalflow.ChaseRulesDelete;
import com.mhplan.qms.module.functionalflow.CheckRecordcreated;
import com.mhplan.qms.module.functionalflow.CompServicesUnderAuditMngmnt;
import com.mhplan.qms.module.functionalflow.ElementTypes;
import com.mhplan.qms.module.functionalflow.HeaderListofRecords;
import com.mhplan.qms.module.functionalflow.ImmunizationCrosswalk;
import com.mhplan.qms.module.functionalflow.JobTypeLibrary;
import com.mhplan.qms.module.functionalflow.LockUnlockUser;
import com.mhplan.qms.module.functionalflow.ManualChases;
import com.mhplan.qms.module.functionalflow.MedRecCompRotaVirus;
import com.mhplan.qms.module.functionalflow.MedicalRecord_Audit_Notes;
import com.mhplan.qms.module.functionalflow.MedicalRecord_Buttons_and_UI;
import com.mhplan.qms.module.functionalflow.MemberSearch;
import com.mhplan.qms.module.functionalflow.ModifyAccordionStyles;
import com.mhplan.qms.module.functionalflow.TestCheckboxesinListRecords;
import com.mhplan.qms.module.functionalflow.TestForgotPassowrd;
import com.mhplan.qms.module.functionalflow.TestInitiativeRule;
import com.mhplan.qms.module.functionalflow.testGroup;
import com.mhplan.qms.module.functionalflow.testJobs;
import com.mhplan.qms.module.functionalflow.TestMRAdded;
import com.mhplan.qms.module.functionalflow.PPCMembers;
import com.mhplan.qms.module.functionalflow.ShowServicesLMRTable;
import com.mhplan.qms.module.functionalflow.ChasemngmntCountRows;
import com.mhplan.qms.module.functionalflow.CheckMeasureTypeInitCG;
import com.mhplan.qms.module.functionalflow.TestMyProfile;
import com.mhplan.qms.module.functionalflow.TestRunAuditGenerator;
import com.mhplan.qms.module.functionalflow.TestmemberAddedinMR;
import com.mhplan.qms.module.functionalflow.ValidateService;
import com.mhplan.qms.module.functionalflow.WorkQueue;
import com.mhplan.qms.module.functionalflow.checkForDocinMedRecToBeActive;
import com.mhplan.qms.module.functionalflow.checkForIconsOfMedRec;
import com.mhplan.qms.module.functionalflow.checkInitiativeRecStatus;
import com.mhplan.qms.module.functionalflow.checkMREntryForInittve;
import com.mhplan.qms.module.functionalflow.checkMedRecInitiativeType;
import com.mhplan.qms.module.functionalflow.compServiceType;
import com.mhplan.qms.module.functionalflow.compSvcPartialWellChildVisits;
import com.mhplan.qms.module.functionalflow.ExternalSources;
import com.mhplan.qms.module.functionalflow.initiativeWorkFlowStatus;
import com.mhplan.qms.module.functionalflow.medRecCompBloodPressure;
import com.mhplan.qms.module.functionalflow.medRecCompFSA;
import com.mhplan.qms.module.functionalflow.testInitiativesTabs;
import com.mhplan.qms.module.functionalflow.testJobQueue;
import com.mhplan.qms.reportmanager.PrepareReport;

public class RegressionTestcases extends DriverScript {

	testAdminInitiatives TAIN = new testAdminInitiatives();
	TestAdminDocument TADOC = new TestAdminDocument();
	testAdminUpdateDocument TAUDOC = new testAdminUpdateDocument();
	testChaseGenerator TCGEN = new testChaseGenerator();
	testChaseRules TRules = new testChaseRules();
	TestAuditRules TARules = new TestAuditRules();
	testAdminMeasureVersion TAMVer = new testAdminMeasureVersion();
	testProviderGroup TPG = new testProviderGroup();
	testAdminServiceMapping TASMP = new testAdminServiceMapping();
	testAdminMeasureDefinition TAMD = new testAdminMeasureDefinition();
	testAdminMeasureElement TAMELE = new testAdminMeasureElement();
	testCodeSet TCSet = new testCodeSet();
	testAdminServiceTxt TAS = new testAdminServiceTxt();
	testAdminServiceNumeric TASNmrk = new testAdminServiceNumeric();
	testAdminServiceUpdate TASUpdt = new testAdminServiceUpdate();
	testUpdateMeasureDefinition TUMD = new testUpdateMeasureDefinition();
	HeaderListofRecords headerlist = new HeaderListofRecords();
	TestMRAdded TestMR = new TestMRAdded();
	AppointmentManagement AppMNGMnt = new AppointmentManagement();
	ChaseManagement CHSMNG = new ChaseManagement();
	CareGaps Gapsincare = new CareGaps();
	ElementTypes Eletype = new ElementTypes();
	ChasemngmntCountRows Chaserows = new ChasemngmntCountRows();
	TestCheckboxesinListRecords chckboxes = new TestCheckboxesinListRecords();
	AddRecordinAppmntMngmnt AddRcrdApMt = new AddRecordinAppmntMngmnt();
	testOrganization TOrg = new testOrganization();
	AddMedicalRecords AddMR = new AddMedicalRecords();
	testUpdateMeasureElements TUME = new testUpdateMeasureElements();
	providerGroupMapByProvider TPGMSBP = new providerGroupMapByProvider();
	providerGroupMapByLocation TPGMSBL = new providerGroupMapByLocation();
	TestUpdateInitiative TUINI = new TestUpdateInitiative();
	testUsers TU = new testUsers();
	testJobs TJ = new testJobs();
	testGroup TG = new testGroup();
	ChaseRulesDelete CRDS = new ChaseRulesDelete();
	testAuditGenerator AG = new testAuditGenerator();
	testInitiativesTabs RANDP = new testInitiativesTabs();
	testAdminInitiativesNegScenario AINS = new testAdminInitiativesNegScenario();
	TestAdminServiceNegativeScenario ASNS = new TestAdminServiceNegativeScenario();
	testAdminDocumentNegativeTestCase TADOCNS = new testAdminDocumentNegativeTestCase();
	LockUnlockUser LUuser = new LockUnlockUser();
	AuditManagement Audmgmt = new AuditManagement();
	TestmemberAddedinMR TestMP = new TestmemberAddedinMR();
	ChaseMemberList ChMmbrlist = new ChaseMemberList();
	WorkQueue WQ = new WorkQueue();
	TestBadLogin BadLgn = new TestBadLogin();
	CheckRecordcreated chckMR = new CheckRecordcreated();
	ValidateService valsvc = new ValidateService();
	TestForgotPassowrd FPWD = new TestForgotPassowrd();
	MedicalRecord_Buttons_and_UI MRBUI = new MedicalRecord_Buttons_and_UI();
	MedicalRecord_Audit_Notes MRAN = new MedicalRecord_Audit_Notes();
	ChaseManagement_SortFilter CHSMNGSF = new ChaseManagement_SortFilter();
	TestMyProfile MYPROFILE = new TestMyProfile();
	PPCMembers PPCMMBRS = new PPCMembers();
	ModifyAccordionStyles ModNvgtnMenu = new ModifyAccordionStyles();
	MemberSearch memberSearch = new MemberSearch();
	checkInitiativeRecStatus chckInitStat = new checkInitiativeRecStatus();
	initiativeWorkFlowStatus initWFStat = new initiativeWorkFlowStatus();
	testJobQueue TJQ = new testJobQueue();
	ExternalSources ExtrnlSrc = new ExternalSources();
	checkMedRecInitiativeType MRInitType = new checkMedRecInitiativeType();
	CheckMeasureTypeInitCG chckTypeMsr = new CheckMeasureTypeInitCG();
	TestAuditGeneratorRunLabel tagrl = new TestAuditGeneratorRunLabel();
	TestRunAuditGenerator trag = new TestRunAuditGenerator();
	ImmunizationCrosswalk immcrswlk = new ImmunizationCrosswalk();
	checkMREntryForInittve changeInitCheckMR = new checkMREntryForInittve();
	compServiceType compSvcType = new compServiceType();
	checkForIconsOfMedRec chckIFIconEnabled = new checkForIconsOfMedRec();
	JobTypeLibrary jtl = new JobTypeLibrary();
	medRecCompBloodPressure compBP = new medRecCompBloodPressure();
	medRecCompFSA compFSA = new medRecCompFSA();
	ManualChases manChase = new ManualChases();
	ShowServicesLMRTable showSvc = new ShowServicesLMRTable();
	MedRecCompRotaVirus mrcomrv = new MedRecCompRotaVirus();
	TestInitiativeRule tir = new TestInitiativeRule();
	compSvcPartialWellChildVisits compPWCV = new compSvcPartialWellChildVisits();
	checkForDocinMedRecToBeActive checkDocType = new checkForDocinMedRecToBeActive();
	CompServicesUnderAuditMngmnt compSvcAudMgmnt = new CompServicesUnderAuditMngmnt();
	ReadOnlyMedRec ROMR = new ReadOnlyMedRec();
	ActiveInactiveServiceType aist = new ActiveInactiveServiceType();
	AuditGenRunLabelForInitiativeWrkflStatus agrlfiws = new AuditGenRunLabelForInitiativeWrkflStatus();

	

	public Boolean bLoginFlag = true;

	public PrepareReport fn1001(PrepareReport obj) throws Exception {

		Boolean bAddMRFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bAddMRFlag = AddMR.AddaMember();
			obj.repAddData("Test Result", "", "", "");
			if (bAddMRFlag == true) {
				obj.repAddData("Adding MedRec", "Medical Record should be Added successfully",
						"Adding Medical Record was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing Member", "Medical Record should be Added successfully",
						"Adding Medical Record  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Add a Medical Record Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add a Medical Record Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1002(PrepareReport obj) throws Exception {

		Boolean btestMRFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			btestMRFlag = AddMR.AddaMember();
			obj.repAddData("Test Result", "", "", "");
			if (btestMRFlag == true) {
				obj.repAddData("Adding MEdRec", "Medical Record should be Added successfully",
						"Adding Medical Record was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing Member", "Medical Record should be Added successfully",
						"Adding Medical Record  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Add a Medical Record Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add a Medical Record Completed");
		}
		return obj;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////
	public PrepareReport fn1003(PrepareReport obj) throws Exception {

		Boolean bheaderlistFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bheaderlistFlag = headerlist.headerListOfRecords();
			obj.repAddData("Test Result", "", "", "");
			if (bheaderlistFlag == true) {
				obj.repAddData("Updating Medical Records", "Medical Records should be updated Successfully",
						"Updating Medical Record was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Updating Medical Records", "Medical Records should be updated Successfully",
						"Updating Medical Record  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Updating Medical Records Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function Updating Medical Records Completed");
		}
		return obj;
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1004(PrepareReport obj) throws Exception {

		Boolean bAppmntmgmntFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bAppmntmgmntFlag = AppMNGMnt.Appointmgmnt();
			obj.repAddData("Test Result", "", "", "");
			if (bAppmntmgmntFlag == true) {
				obj.repAddData("Appointment Management", "Appointment should be managed  Successfully",
						"Managing Apointment  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Appointment Management", "Appointment should be managed  Successfully",
						"Managing Apointment   Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to  Appointment Management  Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Appointment Management Completed");
		}
		return obj;
	}

	///////////////////////////////////////////////////////////////////////////////////////
	public PrepareReport fn1005(PrepareReport obj) throws Exception {

		Boolean bChsemgmntFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bChsemgmntFlag = CHSMNG.ImplementChaseMangement();
			obj.repAddData("Test Result", "", "", "");
			if (bChsemgmntFlag == true) {
				obj.repAddData("Chase Management", "Chases should be found successfully",
						"Finding Chases was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Chase Management", "Chases should be found successfully",
						"Finding Chases was not Successful", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Find Chases Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Find Chases Completed");
		}
		return obj;
	}

	//////////////////////////////////////////////////////////////////////////////////
	public PrepareReport fn1006(PrepareReport obj) throws Exception {

		Boolean bgapsFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bgapsFlag = Gapsincare.FindgapsinCAre();
			obj.repAddData("Test Result", "", "", "");
			if (bgapsFlag == true) {
				obj.repAddData("Chase Management", "Care Gaps should be found successfully",
						"Finding Care Gaps  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Chase Management", "Chases should be found successfully",
						"Finding Care Gaps  was not Successful", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Care Gaps  Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Care Gaps  Completed");
		}
		return obj;
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1009(PrepareReport obj) throws Exception {

		Boolean bChckboxeslag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bChckboxeslag = chckboxes.TestCheckboxes();
			obj.repAddData("Test Result", "", "", "");
			if (bChckboxeslag == true) {
				obj.repAddData("Validating Checkboxes of List of records", "Checkbox(s) should be checked successfully",
						"Selecting Checkboxes was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Validating Checkboxes of List of records", "Checkbox(s) should be checked successfully",
						"Selecting Checkboxes  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Validate Checkboxes of List of records Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Validate Checkboxes of List of records Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1010(PrepareReport obj) throws Exception {

		Boolean bAddrcrdApmtFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bAddrcrdApmtFlag = AddRcrdApMt.AddrecordinAPMgmnt();
			obj.repAddData("Test Result", "", "", "");
			if (bAddrcrdApmtFlag == true) {
				obj.repAddData("Adding Record in Appointment Management",
						" Record in Appointment Management should be Added successfully",
						"Adding Record in Appointment Management was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Adding Record in Appointment Management",
						"Record in Appointment Management should be Added successfully",
						"Adding Record in Appointment Management  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function Adding Record in Appointment Management Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Adding Record in Appointment Management Completed");
		}
		return obj;
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1011(PrepareReport obj) throws Exception {

		Boolean bAudmgtFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bAudmgtFlag = Audmgmt.implementAudits();
			obj.repAddData("Test Result", "", "", "");
			if (bAudmgtFlag == true) {
				obj.repAddData("Audit Management", " Finding  Audits should be  successful",
						"Finding  Audits was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Audit Management", "Finding  Audits should be  successful", "Finding  Audits  Failed",
						"Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function Finding  Audits  Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function Finding  Audits  Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1012(PrepareReport obj) throws Exception {

		Boolean bMmbrprvdrFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bMmbrprvdrFlag = TestMP.CheckMmbrPrvdrinfo();
			obj.repAddData("Test Result", "", "", "");
			if (bMmbrprvdrFlag == true) {
				obj.repAddData("Checkig for Member/Provider Presence",
						"Checking Existence of Members/Providers should be done successfully",
						"Checking Existence of Members/Providers was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Checkig for Member/Provider Presence",
						"Checking Existence of Members/Providers should be done successfully",
						"Checking Existence of Members/Providers  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function Checking Existence of Members/Providers  Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of  Checking Existence of Members/Providers  Completed");
		}
		return obj;
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1013(PrepareReport obj) throws Exception {

		Boolean bChasemmbrFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bChasemmbrFlag = ChMmbrlist.GetChasememberlist();
			obj.repAddData("Test Result", "", "", "");
			if (bChasemmbrFlag == true) {
				obj.repAddData("Chase member List", "Generating Chase Member List should be done successfully",
						"Generating Chase Member List was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Chase member List", "Generating Chase Member List should be done successfully",
						"Generating Chase Member List  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Generating Chase Member List Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution Generating Chase Member List Completed");
		}
		return obj;
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1014(PrepareReport obj) throws Exception {

		Boolean bWorkQueueFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bWorkQueueFlag = WQ.GetWorkQueue();
			obj.repAddData("Test Result", "", "", "");
			if (bWorkQueueFlag == true) {
				obj.repAddData("Chase member List", "Display of  Work Queue should be done successfully",
						"Work Queue display was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Chase member List", "Display of  Work Queue should be done successfully",
						"Work Queue display Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Display Work Queue Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Display of Work Queue Completed");
		}
		return obj;
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1015(PrepareReport obj) throws Exception {

		Boolean bbadloginFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bbadloginFlag = fnbadLoginAttempt();
			}

			obj.repAddData("Test Result", "", "", "");
			if (bbadloginFlag == false) {
				obj.repAddData(" Verifying Invalid Login ", "Login Failed. Message should be displayed  ",
						"Display of error message was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Verifying Invalid Login", "Login Failed.Message should be displayed",
						"Display of Error message  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Login Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Login was Successful");
		}
		return obj;
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1016(PrepareReport obj) throws Exception {

		Boolean bCheckMRcrtdFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bCheckMRcrtdFlag = chckMR.CheckRecordcreated();
			obj.repAddData("Test Result", "", "", "");
			if (bCheckMRcrtdFlag == true) {
				obj.repAddData("Chase member List", "Check for Med Record Created should be done successfully",
						"Check for Med Record Created was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Chase member List", "Check for Med Record Created should be done successfully",
						"Check for Med Record Created  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function Check for Med Record Created Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution Check for Med Record Created Completed");
		}
		return obj;
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1017(PrepareReport obj) throws Exception {

		Boolean bvalidatesvcFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bvalidatesvcFlag = valsvc.ValSVCinitrule();
			obj.repAddData("Test Result", "", "", "");
			if (bvalidatesvcFlag == true) {
				obj.repAddData("Chase member List", "Validating Service should be done successfully",
						"Validating Service  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Chase member List", "Validating Service should be done successfully",
						"Validating Service  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Execution of Function to Validate a Service  Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Validate a Service Completed");
		}
		return obj;
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1022(PrepareReport obj) throws Exception {

		Boolean brecStatFlag = true;

		log.info("Executing function to check for Initiative record Status.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			brecStatFlag = chckInitStat.checkInitRecStatus();
			obj.repAddData("Test Result", "", "", "");
			if (brecStatFlag == true) {
				obj.repAddData("Checking Record Status of Initiative and its existence in Drop downs of MR",
						"Initiative with D-RecStat should not be present in the drop down ",
						"Not Finding Initiative with D-RecStat  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Checking Record Status of Initiative and its existence in Drop downs of MR",
						"Initiative with D-RecStat should not be present in the drop down",
						" Not Finding Initiative with D-RecStat Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Check Record Status of Initiative and its existence in Drop downs of MR Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info(
					"Execution of Checking Record Status of Initiative and its existence in Drop downs of MR Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1023(PrepareReport obj) throws Exception {

		Boolean bworkFlowStatFlag = true;

		log.info("Executing function to check for Initiative Work Flow  Status in all MedRec Drop downs.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bworkFlowStatFlag = initWFStat.checkInitWorkFlowStatus();
			obj.repAddData("Test Result", "", "", "");
			if (bworkFlowStatFlag == true) {
				obj.repAddData("Checking Initiative Work Flow  Status in all MedRec Drop downs ",
						"Initiative  Work Flow  Status should be displayed in all MedRec Drop downs",
						"Initiative  Work Flow  Status is displayed in all MedRec Drop downs", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Checking Record Status of Initiative and its existence in Drop downs of MR",
						"Initiative  Work Flow  Status should be displayed in all MedRec Drop downs",
						" Initiative  Work Flow  Status is not displayed in all MedRec Drop downs", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Check Initiative  Work Flow  Status from MedRec drop downs Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Check Initiative  Work Flow  Status from MedRec drop downs Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1024(PrepareReport obj) throws Exception {

		Boolean bExtrnlSrcFlag = true;

		log.info("Executing function to search External Sources started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bExtrnlSrcFlag = ExtrnlSrc.externalSourcesInfo();
			obj.repAddData("Test Result", "", "", "");
			if (bExtrnlSrcFlag == true) {
				obj.repAddData("Adding external Source", "External Source should be Added successfully",
						"Adding External Source was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing External Source", "External Source should be Added successfully",
						"Adding External Source  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Add an External Source Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add an External Source Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1025(PrepareReport obj) throws Exception {

		Boolean bcheckMRInitFlag = true;

		log.info("Executing function to check for Medical Record's Initiative Type Started ....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bcheckMRInitFlag = MRInitType.checkInitType();
			obj.repAddData("Test Result", "", "", "");
			if (bcheckMRInitFlag == true) {
				obj.repAddData("Checking For Medical Record Initiative Type",
						"Medical Record Initiative Type should be checked for, successfully",
						"Medical Record Initiative Type-Check was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Checking For Medical Record Initiative Type",
						"Medical Record Initiative Type should be checked for, successfully",
						"Medical Record Initiative Type-Check  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Medical Record Initiative Type-Check Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Medical Record Initiative Type-Check Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1026(PrepareReport obj) throws Exception {

		Boolean bchckTypeMsrFlag = true;

		log.info("Executing function to check for Care Gaps's Initiative Type Started ....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bchckTypeMsrFlag = chckTypeMsr.checkCGInitType();
			obj.repAddData("Test Result", "", "", "");
			if (bchckTypeMsrFlag == true) {
				obj.repAddData("Checking For Care Gaps's Initiative Type",
						"Care Gaps's Initiative Type should be checked for, successfully",
						"Care Gaps's Initiative Type-Check was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Checking For Care Gaps's Initiative Type",
						"Care Gaps's Initiative Type should be checked for, successfully",
						"Care Gaps's Initiative Type-Check  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Care Gaps's Initiative Type-Check Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Care Gaps's Initiative Type-Check Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1027(PrepareReport obj) throws Exception {

		Boolean bchckInitFlag = true;

		log.info("Executing function to Change Initiative and check for member details to be cleared.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bchckInitFlag = changeInitCheckMR.changeInitandCheck();
			obj.repAddData("Test Result", "", "", "");
			if (bchckInitFlag == true) {
				obj.repAddData("Adding MedRec",
						"Changing Initiative and checking for member details to be cleared should be done successfully",
						"Changing Initiative and checking for member details to be cleared was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing Member",
						"Changing Initiative and checking for member details to be cleared should be done successfully",
						"Changing Initiative and checking for member details to be cleared- Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Change Initiative and check for member details to be cleared - Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info(
					"Execution of Function to Change Initiative and check for member details to be cleared -Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1028(PrepareReport obj) throws Exception {

		Boolean bcompSVTypeFlag = true;

		log.info("Executing function to Add A Composite Service Type.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bcompSVTypeFlag = compSvcType.addCompsteSvcType();
			obj.repAddData("Test Result", "", "", "");
			if (bcompSVTypeFlag == true) {
				obj.repAddData("Adding Composite Service Type", "Composite Service Type should be Added successfully",
						"Adding Composite Service Type was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing Composite Service Type", "Composite Service Type should be Added successfully",
						"Adding Composite Service Type  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Add a Composite Service Type Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add a Composite Service Type Completed");
		}
		return obj;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1029(PrepareReport obj) throws Exception {

		Boolean bcheckIconFlag = true;

		log.info("Executing function to check for Medical Record's Display of Icons.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bcheckIconFlag = chckIFIconEnabled.checkForIcons();
			obj.repAddData("Test Result", "", "", "");
			if (bcheckIconFlag == true) {
				obj.repAddData("Adding MEdRec", "Medical Record's Display of Icons should  be shown successfully",
						" Medical Record's Display of Icons  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing Member", "Medical Record's Display of Icons should  be shown successfully",
						"Medical Record's Display of Icons  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Add Medical Record's Display of Icons Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add Medical Record's Display of Icons Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1030(PrepareReport obj) throws Exception {

		Boolean bcompBPFlag = true;

		log.info("Executing function to add a Composite Service(Blood pressure) started .....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bcompBPFlag = compBP.compBP();
			obj.repAddData("Test Result", "", "", "");
			if (bcompBPFlag == true) {
				obj.repAddData("Adding Comp BP", "Composite Service(Blood Pressure) should be Added successfully",
						"Adding Composite Service(Blood Pressure) was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing CompBP", "Composite Service(Blood Pressure) should be Added successfully",
						"Adding Composite Service(Blood Pressure)  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Add a Composite Service(Blood Pressure) Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add a Composite Service(Blood Pressure) Completed");
		}
		return obj;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1032(PrepareReport obj) throws Exception {

		Boolean bmanChaseFlag = true;

		log.info("Executing function to add a Manual Chase started .....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bmanChaseFlag = manChase.implementManualChases();
			obj.repAddData("Test Result", "", "", "");
			if (bmanChaseFlag == true) {
				obj.repAddData("Adding Manual Chase", "Manual Chase should be Added successfully",
						"Adding Manual Chase was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing Manual Chase", "Manual Chase should be Added successfully",
						"Adding Manual Chase  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Add a Manual Chase Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add a Manual Chase Completed");
		}
		return obj;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1033(PrepareReport obj) throws Exception {

		Boolean bshowSvcFlag = true;

		log.info("Executing function to GetServices from List Medical records table started .....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bshowSvcFlag = showSvc.getServicesList();
			obj.repAddData("Test Result", "", "", "");
			if (bshowSvcFlag == true) {
				obj.repAddData("Adding Manual Chase",
						"GetServices from List Medical records table should be done successfully",
						"Getting Services from List Medical records table  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing Manual Chase",
						"GetServices from List Medical records table should be done successfully",
						" Getting Services from List Medical records table Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Get Services from List Medical records table Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Get Services from List Medical records table Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1036(PrepareReport obj) throws Exception {

		Boolean bcompPWCVFlag = true;

		log.info("Executing function to add a Composite Service(Partial Well Child Visits) started .....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bcompPWCVFlag = compPWCV.compPWCV();
			obj.repAddData("Test Result", "", "", "");
			if (bcompPWCVFlag == true) {
				obj.repAddData("Adding Comp PWCV",
						"Composite Service(Partial Well Child Visits) should be Added successfully",
						"Adding Composite Service(Partial Well Child Visits) was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing Comp PWCV",
						"Composite Service(Partial Well Child Visits) should be Added successfully",
						"Adding Composite Service(Partial Well Child Visits)  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Add a Composite Service(Partial Well Child Visits) Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add a Composite Service(Partial Well Child Visits) Completed");
		}
		return obj;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1039(PrepareReport obj) throws Exception {

		Boolean bcheckDocFlag = true;

		log.info("Executing function to Check for Active Document Display in MedRec.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bcheckDocFlag = checkDocType.checkForMedRecDocBeingActive();
			obj.repAddData("Test Result", "", "", "");
			if (bcheckDocFlag == true) {
				obj.repAddData("Check for Active Document Display in MedRec.",
						"Check for Active Document Display in MedRec should be done  Successfully",
						"Check for Active Document Display in MedRec  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Check for Active Document Display in MedRec ",
						"Check for Active Document Display in MedRec should be done  Successfully",
						"Check for Active Document Display in MedRec   Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to  Appointment Management  Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Appointment Management Completed");
		}
		return obj;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1040(PrepareReport obj) throws Exception {

		Boolean bcompAudmgtFlag = true;

		log.info("Executing function to search for  Composite Services to Manage Audits.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bcompAudmgtFlag = compSvcAudMgmnt.implementAuditCompSvc();
			obj.repAddData("Test Result", "", "", "");
			if (bcompAudmgtFlag == true) {
				obj.repAddData("Composite Services-Audit Management",
						" Finding  Composite Services to Manage Audits should be  successful",
						"Finding  Audits was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Composite Services-Audit Management",
						"Finding  Composite Services to Manage Audits should be  successful", "Finding  Audits  Failed",
						"Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function Finding  Composite Services to Manage Audits  Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function Finding  Composite Services to Manage Audits  Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	public PrepareReport fn1041(PrepareReport obj) throws Exception {

		Boolean bROMRFlag = true;

		log.info("Executing function to Check for Read Only Behavior of Medical Record.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bROMRFlag = ROMR.checkReadOnlyMedRecBehavior();
			obj.repAddData("Test Result", "", "", "");
			if (bROMRFlag) {
				obj.repAddData("Checking Read Only MedRec", "Check for Read Only Behavior of Medical Record should be done  successfully",
						"Check for Read Only Behavior of Medical Record was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Checking Read Only MedRec", "Check for Read Only Behavior of Medical Record should be Added successfully",
						"Check for Read Only Behavior of Medical Record  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Check for Read Only Behavior of Medical Record Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Check for Read Only Behavior of Medical Record Completed");
		}
		return obj;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	// Add initiatives

	////////////////////////////////////////////////////////////////////////////////////////////////
	public PrepareReport fn1051(PrepareReport obj) throws Exception {

		Boolean bTAINFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTAINFlag = TAIN.addInitiatives();
			obj.repAddData("Test Result", "", "", "");
			if (bTAINFlag == true) {
				obj.repAddData("Creating Initiatives", "Initiative should be Added successfully",
						"Create initiative was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing Member", "Initiative should be Added successfully",
						"Create initiative  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create Initiave Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Create Initiative Completed");
		}
		return obj;
	}

	// Add Document
	//////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1052(PrepareReport obj) throws Exception {

		Boolean bTADOCFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTADOCFlag = TADOC.AddDocument();
			obj.repAddData("Test Result", "", "", "");
			if (bTADOCFlag == true) {
				obj.repAddData("Creating Document", "Document should be Added successfully",
						"Add Document was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing Member", "Document should be Added successfully", "Add Document  Failed",
						"Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Create document Completed");
		}
		return obj;
	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Chase Generator

	public PrepareReport fn1053(PrepareReport obj) throws Exception {

		Boolean bTCGENFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTCGENFlag = TCGEN.ChaseGenerator();
			obj.repAddData("Test Result", "", "", "");
			if (bTCGENFlag == true) {
				obj.repAddData("Chase Generator", "Chase generator should be Added successfully",
						"Chase Generator was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Chase Generator", "Chase generator should be Added successfully",
						"Chase Generator Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Chase Generator Completed");
		}
		return obj;
	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Chase Rules
	public PrepareReport fn1054(PrepareReport obj) throws Exception {

		Boolean bTRulesFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTRulesFlag = TRules.ChaseRules();

			obj.repAddData("Test Result", "", "", "");
			if (bTRulesFlag == true) {
				obj.repAddData("Chase Generator", "Chase generator should be Added successfully",
						"Chase Generator was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Chase Generator", "Chase generator should be Added successfully",
						"Chase Generator Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Chase Rules Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Audit Rules
	public PrepareReport fn1055(PrepareReport obj) throws Exception {

		Boolean bTARulesFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTARulesFlag = TARules.AuditRules();

			obj.repAddData("Test Result", "", "", "");
			if (bTARulesFlag == true) {
				obj.repAddData("Chase Generator", "Chase generator should be Added successfully",
						"Chase Generator was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Chase Generator", "Chase generator should be Added successfully",
						"Chase Generator Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Audit Rules Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Admin Measure Version
	public PrepareReport fn1056(PrepareReport obj) throws Exception {

		Boolean bTAMVerFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTAMVerFlag = TAMVer.MeasureVersion();

			obj.repAddData("Test Result", "", "", "");
			if (bTAMVerFlag == true) {
				obj.repAddData("Admin measure version", "Measure Version should be Added successfully",
						"Measure Version was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Admin measure version", "Measure Version should be Added successfully",
						"Measure Version Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Admin Measure Version Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Provider Group
	public PrepareReport fn1057(PrepareReport obj) throws Exception {

		Boolean bTPGFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTPGFlag = TPG.Providergroup();

			obj.repAddData("Test Result", "", "", "");
			if (bTPGFlag == true) {
				obj.repAddData("provider group", "provider group should be Added successfully",
						"provider group was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("provider group", "provider group should be Added successfully", "Provider group Failed",
						"Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Provider Group Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Admin Service Mapping
	public PrepareReport fn1058(PrepareReport obj) throws Exception {

		Boolean bTASMPFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTASMPFlag = TASMP.AddServiceMapping();

			obj.repAddData("Test Result", "", "", "");
			if (bTASMPFlag == true) {
				obj.repAddData("Admin service mapping", "Admin service  should be Mapped successfully",
						"Admin Service was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Admin service mapping", "Admin service  should be Mapped successfully",
						"Admin service Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Admin Service Mapping Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Measure Definition
	public PrepareReport fn1059(PrepareReport obj) throws Exception {

		Boolean bTAMDFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTAMDFlag = TAMD.MeasureDefinition();

			obj.repAddData("Test Result", "", "", "");
			if (bTAMDFlag == true) {
				obj.repAddData("Admin Measure Definition", "Admint measure definition should be added successfully",
						"Admint measure definition  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Admin Measure Definition", "Admint measure definition should be added successfully",
						"Admint measure definition Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Measure Definition Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Measure Element
	public PrepareReport fn1060(PrepareReport obj) throws Exception {

		Boolean bTAMELEFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTAMELEFlag = TAMELE.MeasureElement();

			obj.repAddData("Test Result", "", "", "");
			if (bTAMELEFlag == true) {
				obj.repAddData("Admin Measure Element", "Admint measure Element should be added successfully",
						"Admint measure Element  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Admin Measure Element", "Admint measure Element should be added successfully",
						"Admint measure Element Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Measure Element Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Measure Element Mapping
	public PrepareReport fn1061(PrepareReport obj) throws Exception {

		Boolean bTCSetMFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTCSetMFlag = TCSet.codeSet();

			obj.repAddData("Test Result", "", "", "");
			if (bTCSetMFlag == true) {
				obj.repAddData("Admin Measure Element", "Admint measure Elemen tMapping should be added successfully",
						"Admint measure Element Mapping  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Admin Measure Element", "Admint measure Element Mapping should be added successfully",
						"Admint measure Element Mapping Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Measure Element Mapping Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Admin Service txt
	public PrepareReport fn1062(PrepareReport obj) throws Exception {

		Boolean bTASFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTASFlag = TAS.AddService();

			obj.repAddData("Test Result", "", "", "");
			if (bTASFlag == true) {
				obj.repAddData("Admin Service", "Admin Service should be added successfully",
						"Admin Service  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Admin Service", "Admin Serviceshould be added successfully", "Admin Service Failed",
						"Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Admin Service text Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Admin Service numberic
	public PrepareReport fn1063(PrepareReport obj) throws Exception {

		Boolean bTASNmrkFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTASNmrkFlag = TASNmrk.AdminServiceNmrk();

			obj.repAddData("Test Result", "", "", "");
			if (bTASNmrkFlag == true) {
				obj.repAddData("Admin Service", "Admin Service should be added successfully",
						"Admin Service  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Admin Service", "Admin Serviceshould be added successfully", "Admin Service Failed",
						"Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Admin Service numeric Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Admin Service Update
	public PrepareReport fn1064(PrepareReport obj) throws Exception {

		Boolean bTASUpdtFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTASUpdtFlag = TASUpdt.AdminServiceUpdt();

			obj.repAddData("Test Result", "", "", "");
			if (bTASUpdtFlag == true) {
				obj.repAddData("Admin Service", "Admin Service should be updated successfully",
						"Admin Service update was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Admin Service", "Admin Service should be updated successfully",
						"Admin Service updated Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Admin Service Update Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Admin Organization
	public PrepareReport fn1065(PrepareReport obj) throws Exception {

		Boolean bTOrgFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTOrgFlag = TOrg.AddOrganization();

			obj.repAddData("Test Result", "", "", "");
			if (bTOrgFlag == true) {
				obj.repAddData("Admin Organization", "Admin Organization should be created successfully",
						"Admin Organization was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Admin Organization", "Admin Organization should be created successfully",
						"Admin Organization  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Admin Organization Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Update Document
	public PrepareReport fn1066(PrepareReport obj) throws Exception {

		Boolean bTAUDOCFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTAUDOCFlag = TAUDOC.UpdateDocument();

			obj.repAddData("Test Result", "", "", "");
			if (bTAUDOCFlag == true) {
				obj.repAddData("Update document", "Document should be updated successfully",
						"Update document was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Update document", "Document should be updated successfully", "Update document  Failed",
						"Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Update Document Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Measure Definition Updated
	public PrepareReport fn1067(PrepareReport obj) throws Exception {

		Boolean bTUMDFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTUMDFlag = TUMD.UpdateDocument();

			obj.repAddData("Test Result", "", "", "");
			if (bTUMDFlag == true) {
				obj.repAddData("Update measure definition", "Measure Definition should be updated successfully",
						"Update Measure Definition was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Update measure definition", "Measure Definition should be updated successfully",
						"Update Measure Definition  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Measure Definition Updated Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Job
	public PrepareReport fn1068(PrepareReport obj) throws Exception {

		Boolean bTJFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTJFlag = TJ.jobs();

			obj.repAddData("Test Result", "", "", "");
			if (bTJFlag == true) {
				obj.repAddData("Jobs", "Jobs should be successfully", "Jobs was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Jobs", "Jobs should be successfully", "Jobs  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Jobs Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Jobs Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Measure Element Updated
	public PrepareReport fn1069(PrepareReport obj) throws Exception {

		Boolean bTUMEFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTUMEFlag = TUME.UpdateElement();

			obj.repAddData("Test Result", "", "", "");
			if (bTUMEFlag == true) {
				obj.repAddData("Update element", "Update element should be successfully",
						"Update element was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Update element", "Update element should be successfully", "Update element  Failed",
						"Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Update element Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Update element Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Provider Group mapping search by provider
	public PrepareReport fn1070(PrepareReport obj) throws Exception {

		Boolean bTPGMSBPFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTPGMSBPFlag = TPGMSBP.ProvidergroupMapping();

			obj.repAddData("Test Result", "", "", "");
			if (bTPGMSBPFlag == true) {
				obj.repAddData("Provider group Mapping", "Provider group Mapping should be successfully",
						"Provider group Mapping was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Provider group Mapping ", "Provider group Mapping should be successfully",
						"Provider group Mapping  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Update element Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Provider Group mapping search by provider Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Provider Group mapping search by provider
	public PrepareReport fn1071(PrepareReport obj) throws Exception {

		Boolean bTPGMSBLFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTPGMSBLFlag = TPGMSBL.ProvidergroupMapping();

			obj.repAddData("Test Result", "", "", "");
			if (bTPGMSBLFlag == true) {
				obj.repAddData("Provider group Mapping", "Provider group Mapping should be successfully",
						"Provider group Mapping was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Provider group Mapping ", "Provider group Mapping should be successfully",
						"Provider group Mapping  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Update element Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Provider Group mapping search by location Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// User
	public PrepareReport fn1072(PrepareReport obj) throws Exception {

		Boolean bTUFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTUFlag = TU.users();

			obj.repAddData("Test Result", "", "", "");
			if (bTUFlag == true) {
				obj.repAddData("Users ", "Users should be successfully", "Users was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Users ", "Users should be successfully", "Users  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Users Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Users Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Group
	public PrepareReport fn1073(PrepareReport obj) throws Exception {

		Boolean bTGFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTGFlag = TG.group();

			obj.repAddData("Test Result", "", "", "");
			if (bTGFlag == true) {
				obj.repAddData("Group ", "Group should be successfully", "Group was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Group ", "Group should be successfully", "Group  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Group Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Group Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Update Initiative
	public PrepareReport fn1074(PrepareReport obj) throws Exception {

		Boolean bTUINIFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTUINIFlag = TUINI.UpdateInitiative();

			obj.repAddData("Test Result", "", "", "");
			if (bTUINIFlag == true) {
				obj.repAddData("Update Initiative ", "Update Initiative should be successfully",
						"Update Initiative was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Update Initiative ", "Update Initiative should be successfully",
						"Update Initiative  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Update Initiative Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Update Initiative Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Chase rules delete scenario
	public PrepareReport fn1075(PrepareReport obj) throws Exception {

		Boolean bCRDSFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bCRDSFlag = CRDS.ChaseRules();

			obj.repAddData("Test Result", "", "", "");
			if (bCRDSFlag == true) {
				obj.repAddData("Chase Rules  ", "Chase Rules delete should be successfully",
						"Chase Rules delete was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Chase Rules ", "Chase Rules delete should be successfully",
						"Chase Rules delete  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Update Initiative Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Chase rules delete Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Audit Generator
	public PrepareReport fn1076(PrepareReport obj) throws Exception {

		Boolean bAGFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bAGFlag = AG.AuditGenerator();

			obj.repAddData("Test Result", "", "", "");
			if (bAGFlag == true) {
				obj.repAddData("Audit Generator ", "Audit Generator should be successfully",
						"Audit Generator was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Audit Generator ", "Audit Generator should be successfully", "Audit Generator Failed",
						"Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Update Initiative Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Audit Generator Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Initiative tabs
	public PrepareReport fn1077(PrepareReport obj) throws Exception {

		Boolean bRANDPFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bRANDPFlag = RANDP.initiativeTabs();

			obj.repAddData("Test Result", "", "", "");
			if (bRANDPFlag == true) {
				obj.repAddData("Initiative tabs ", "Initiative tabs should be successfully",
						"Initiative tabs was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Initiative tabs ", "Initiative tabs should be successfully", "Initiative tabs Failed",
						"Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Update Initiative Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Initiative tabs Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Add initiative negative scenario
	public PrepareReport fn1078(PrepareReport obj) throws Exception {

		Boolean bAINSFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bAINSFlag = AINS.AddInitiatives();

			obj.repAddData("Test Result", "", "", "");
			if (bAINSFlag == true) {
				obj.repAddData("Add initiave ", "Save button should not be enabled", "Save button is disable", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Add initiave ", "Save button should not be enabled", "Save button is enable", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Update Initiative Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add initiative negative scenario Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Admin Service negative scenario
	public PrepareReport fn1079(PrepareReport obj) throws Exception {

		Boolean bASNSFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bASNSFlag = ASNS.AddService();

			obj.repAddData("Test Result", "", "", "");
			if (bASNSFlag == true) {
				obj.repAddData("Admin Service ", "Save button should not be enabled", "Save button is disable", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Admin Service ", "Save button should not be enabled", "Save button is enable", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Update Initiative Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Admin Service negative scenario Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Add Document - Negative scenario

	public PrepareReport fn1031(PrepareReport obj) throws Exception {

		Boolean bTADOCNCFlag = true;

		log.info("Executing function to validate add document screen started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTADOCNCFlag = TADOCNS.AddDocumentNegativeTC();
			obj.repAddData("Test Result", "", "", "");
			if (bTADOCNCFlag == true) {
				obj.repAddData("Add Document screen", "Document screen validation successful",
						"Add Document Negative test cases were Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Add Document screen", "Document screen validation successful",
						"Add Document Negative test cases Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add Document - Negative scenario Completed");
		}
		return obj;

	}

	//////////////////////////////////////////////////////////////////////////////////////////
	// Lock and Unlock
	// =========================================================================
	public PrepareReport fn1034(PrepareReport obj) throws Exception {
		Boolean bUALULFlag = true;
		Boolean bbadloginFlag = true;

		log.info("Executing function to validate locking and unlocking a user started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {

			if (driver == null) {
				bbadloginFlag = fnbadLoginAttempt();
			}

			if (driver == null) {
				bbadloginFlag = fnbadLoginAttempt();
			}

			if (driver == null) {
				bbadloginFlag = fnbadLoginAttempt();
			}
			bUALULFlag = LUuser.LockUnlock();
			obj.repAddData("Test Result", "", "", "");

			if (bUALULFlag == true) {
				obj.repAddData(" Verifying user locking and unlocking", "Validate user locking unlocking",
						"User unlocked and login was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Verifying user locking and unlocking", "Validate user locking unlocking",
						"User unlocked and login Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to validate unlocking a user and login failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Validating unlocking user and login is Successful");
		}
		return obj;
	}

	// =================================================================================
	// forgot password

	public PrepareReport fn1080(PrepareReport obj) throws Exception {

		Boolean bFPWDFlag = true;

		log.info("Executing function to validate add document screen started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			bFPWDFlag = FPWD.ForgotPassword();
			obj.repAddData("Test Result", "", "", "");
			if (bFPWDFlag == true) {
				obj.repAddData("Add Document screen", "Document screen validation successful",
						"Add Document Negative test cases were Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Add Document screen", "Document screen validation successful",
						"Add Document Negative test cases Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to forgot password Completed");
		}
		return obj;

	}

	// =================================================================================
	// Medical Record button and User Interface

	public PrepareReport fn1081(PrepareReport obj) throws Exception {

		Boolean bMRBUIFlag = true;

		log.info("Executing function to validate add document screen started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bMRBUIFlag = MRBUI.Medicar_rec_btn_UI();
			obj.repAddData("Test Result", "", "", "");
			if (bMRBUIFlag == true) {
				obj.repAddData("Medical Record User Interface", "Medical Record User Interface successful",
						"Medical Record User Interface were Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Medical Record User Interface", "Medical Record User Interface successful",
						"Medical Record User Interface Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Medical Record button and User Interface Completed");
		}
		return obj;

	}

	// =================================================================================
	// Medical Record audit notes

	public PrepareReport fn1082(PrepareReport obj) throws Exception {

		Boolean bMRANFlag = true;

		log.info("Executing function to validate add document screen started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bMRANFlag = MRAN.Medicar_rec_audit_notes();
			obj.repAddData("Test Result", "", "", "");
			if (bMRANFlag == true) {
				obj.repAddData("Medical Record Audit notes", "Medical Record Audit notes successful",
						"Medical Record Audit notes were Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Medical Record Audit notes", "Medical Record Audit notes successful",
						"Medical Record Audit notes Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Create document Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function  Medical Record audit notes Completed");
		}
		return obj;

	}

	// Chase Management Sorting and Filter
	///////////////////////////////////////////////////////////////////////////////////////
	public PrepareReport fn1035(PrepareReport obj) throws Exception {

		Boolean bChsemgmntFlag = true;

		log.info("Executing function to validate sorting and filtering in chase management started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bChsemgmntFlag = CHSMNGSF.ChaseMangementSortFilter();
			obj.repAddData("Test Result", "", "", "");
			if (bChsemgmntFlag == true) {
				obj.repAddData("Chase Management Sort Filter",
						"Chases sorting and filter should be validated successfully", "Sort and Filter were Successful",
						"Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Chase Management Sort Filter",
						"Chases sorting and filter should be validated successfully",
						"Sort and Filter were not Successful", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to validate Sort and Filter were Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Sort and Filter were Completed");
		}
		return obj;
	}

	///////////////////////////////////////////////////////////////////////////////////////
	public PrepareReport fn1018(PrepareReport obj) throws Exception {

		Boolean bEletypeFlag = true;

		log.info("Executing function to  Created/Display Element Types started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bEletypeFlag = Eletype.ElementTypes_Measure();
			obj.repAddData("Test Result", "", "", "");
			if (bEletypeFlag == true) {
				obj.repAddData("Element Types", "Element Types should be displayed successfully",
						"Display of Element Types was  Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Element Types", "Element Types should be displayed successfully",
						"Display of Element Types was not Successful", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Display of Element Types Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Display of Element Types  Completed");
		}
		return obj;
	}

	// My Profile validation

	///////////////////////////////////////////////////////////////////////////////////////

	public PrepareReport fn1019(PrepareReport obj) throws Exception {

		Boolean bcntChserowsFlag = true;

		log.info("Executing function to Display  Number of Chase Row Modals .....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bcntChserowsFlag = Chaserows.CountChaseRowModals();
			obj.repAddData("Test Result", "", "", "");
			if (bcntChserowsFlag == true) {
				obj.repAddData("Number of Chase Row Modals",
						"Number of Chase Row Modals should be displayed successfully",
						"Display of Number of Chase Row Modals was  Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Number of Chase Row Modals",
						"Number of Chase Row Modals should be displayed successfully",
						"Display of Number of Chase Row Modals was not Successful", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Display of Number of Chase Row Modals Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Display Number of Chase Row Modals  Completed");
		}
		return obj;

	}

	///////////////////////////
	public PrepareReport fn1037(PrepareReport obj) throws Exception {

		Boolean bMyProfileFlag = true;

		log.info("Executing function to validate my profile screen started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bMyProfileFlag = MYPROFILE.TestMyProfile();
			obj.repAddData("Test Result", "", "", "");
			if (bMyProfileFlag == true) {
				obj.repAddData("My Profile", "My Profile should be validated successfully",
						"My Profile validation were Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("My Profile", "My Profile should be validated successfully",
						"My Profile validation were not Successful", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to validate my profile screen Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to validate my profile Completed");

		}
		return obj;
	}

	// Validation of Member Search and Member Tabs under Member menu //
	public PrepareReport fn1038(PrepareReport obj) throws Exception {
		Boolean bMemberMenuFlag = true;

		log.info("Executing function to validate member menu started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bMemberMenuFlag = memberSearch.SearchMember();
			obj.repAddData("Test Result", "", "", "");
			if (bMemberMenuFlag == true) {
				obj.repAddData("Member Menu", "Member menu should be validated successfully",
						"Member menu validation were Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Member Menu", "Member menu should be validated successfully",
						"Member menu validation were not Successful", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to validate member menu Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to validate member menu Completed");

		}
		return obj;
	}

	///////////////////////////
	public PrepareReport fn1020(PrepareReport obj) throws Exception {

		Boolean bcountdaysFlag = true;

		log.info("Executing function to Count days between Due dateplus21 and FirstTrimester date.");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bcountdaysFlag = PPCMMBRS.MemberseligibleforPPC();
			obj.repAddData("Test Result", "", "", "");
			if (bcountdaysFlag == true) {
				obj.repAddData("Count days between Due dateplus21 and FirstTrimester date",
						"Counting days between Due dateplus21 and FirstTrimester date should be displayed successfully",
						"Counting days between Due dateplus21 and FirstTrimester date was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Count days between Due dateplus21 and FirstTrimester date",
						"Counting days between Due dateplus21 and FirstTrimester date should be displayed successfully",
						"Counting days between Due dateplus21 and FirstTrimester date was not Successful", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Count days between Due dateplus21 and FirstTrimester date Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Count days between Due dateplus21 and FirstTrimester date Completed");

		}
		return obj;
	}

	///////////////////////////
	public PrepareReport fn1021(PrepareReport obj) throws Exception {

		Boolean bmodmenuFlag = true;

		log.info("Executing function for  Navigation-Menu-Expand-Collapse feature.");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bmodmenuFlag = ModNvgtnMenu.CheckMenuExpansion_Collapse();
			obj.repAddData("Test Result", "", "", "");
			if (bmodmenuFlag == true) {
				obj.repAddData("Navigation Menu Expand-Collapse feature",
						"Testing Navigation Menu Expand-Collapse feature should be done successfully",
						"Testing Navigation Menu Expand-Collapse feature  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Navigation Menu Expand-Collapse feature",
						"Testing Navigation Menu Expand-Collapse feature should be done successfully",
						"Testing Navigation Menu Expand-Collapse feature  was not Successful", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Check Navigation Menu Expand-Collapse feature Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Check  Navigation Menu Expand-Collapse feature Completed");
		}
		return obj;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Audit Generator Run Labels
	public PrepareReport fn1084(PrepareReport obj) throws Exception {

		Boolean btagrlFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			btagrlFlag = tagrl.AuditGeneratorRunLabel();

			obj.repAddData("Test Result", "", "", "");
			if (btagrlFlag == true) {
				obj.repAddData("Audit Generator Run Label ", "Audit Generator Run Label should be successfully",
						"Audit Generator Run Label was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Audit Generator Run Label ", "Audit Generator Run Label should be successfully",
						"Audit Generator Run Label Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Audit Generator Run Label Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Audit Generator Run Label Completed");
		}
		return obj;

	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Run Audit Generator
	public PrepareReport fn1085(PrepareReport obj) throws Exception {

		Boolean btragFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			btragFlag = trag.RunAuditGenerator();

			obj.repAddData("Test Result", "", "", "");
			if (btragFlag == true) {
				obj.repAddData(" Run Audit Generator ", "Run Audit Generator should be successfully",
						" Run Audit Generator was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Run Audit Generator ", " Run Audit Generator should be successfully",
						" Run Audit Generator Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to  Run Audit Generator Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to  Run Audit Generator Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Job Queue
	public PrepareReport fn1083(PrepareReport obj) throws Exception {

		Boolean bTJQFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bTJQFlag = TJQ.jobQueue();

			obj.repAddData("Test Result", "", "", "");
			if (bTJQFlag == true) {
				obj.repAddData("Jobs", "Job Queue should be successfully", "Job Queue was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Job Queue", "Job Queue should be successfully", "Job Queue  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Jobs Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Job Queue Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////// Immunization Crosswalk/////////////////

	public PrepareReport fn1086(PrepareReport obj) throws Exception {

		Boolean bimmcrswlkFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bimmcrswlkFlag = immcrswlk.immunizationCrosswalkVersions();

			obj.repAddData("Test Result", "", "", "");
			if (bimmcrswlkFlag == true) {
				obj.repAddData("Immunization Crosswalk", "Immunization Crosswalk should be successfully",
						"Immunization Crosswalk was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Immunization Crosswalk", "Immunization Crosswalk should be successfully",
						"Immunization Crosswalk Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Immunization Crosswalk Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Immunization Crosswalk Completed");
		}
		return obj;

	}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////// Job Type Library/////////////////

	public PrepareReport fn1087(PrepareReport obj) throws Exception {

		Boolean bjtlFlag = true;

		log.info("Executing function to search for a member started.....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bjtlFlag = jtl.jobTypeLib();

			obj.repAddData("Test Result", "", "", "");
			if (bjtlFlag == true) {
				obj.repAddData("Job Type Library", "Job Type Library should be successfully",
						"Job Type Library was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Job Type Library", "Job Type Library should be successfully", "Job Type Library Failed",
						"Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Job Type Library Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Job Type Library Completed");
		}
		return obj;

	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////
	// FSA Composite Service

	public PrepareReport fn1088(PrepareReport obj) throws Exception {

		Boolean bcompFSAFlag = true;

		log.info("Executing function to add a Composite Service(FSA) started .....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bcompFSAFlag = compFSA.compFSA();
			obj.repAddData("Test Result", "", "", "");
			if (bcompFSAFlag == true) {
				obj.repAddData("Adding Comp FSA", "Composite Service FSA should be Added successfully",
						"Adding Composite Service FSA was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing CompFSA", "Composite Service FSA should be Added successfully",
						"Adding Composite Service FSA  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Add a Composite Service FSA Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add a Composite Service FSA Completed");
		}
		return obj;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////
	// Rota Virus Composite Service

	public PrepareReport fn1089(PrepareReport obj) throws Exception {

		Boolean bmrcomrvFlag = true;

		log.info("Executing function to add a Composite Service(Rota Virus) started .....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			bmrcomrvFlag = mrcomrv.compRotaVirus();
			obj.repAddData("Test Result", "", "", "");
			if (bmrcomrvFlag == true) {
				obj.repAddData("Adding Comp Rota Virus", "Composite Service Rota Virus should be Added successfully",
						"Adding Composite Service Rota Virus was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Searcing Comp Rota Virus", "Composite Service Rota Virus should be Added successfully",
						"Adding Composite Service Rota Virus  Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Add a Composite Service Rota Virus Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add a Composite Service Rota Virus Completed");
		}
		return obj;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////
	// Rule Definitions -Test Initiative Rule

	public PrepareReport fn1090(PrepareReport obj) throws Exception {

		Boolean btirFlag = true;

		log.info("Executing function to add Initiative Rule started .....");

		header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

		try {
			if (driver == null) {
				bLoginFlag = fnLoginAttempt();
			}
			btirFlag = tir.InitiativeRules();
			obj.repAddData("Test Result", "", "", "");
			if (btirFlag == true) {
				obj.repAddData("Creating Initiative Rule", "Initiative Rule should be Added successfully",
						"Adding Initiative Rule  was Successful", "Pass");
				PrepareReport.totalPass++;
			} else {
				obj.repAddData("Initiative Rule", "Initiative Rule should be Added successfully",
						"Adding Initiative Rule Failed", "Fail");
				PrepareReport.totalFail++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			testCaseFlow = false;
			obj.repAddData("Error handler", "There should not be any error/exception in the test",
					"Exception found in current test", "Fail");
			PrepareReport.totalFail++;
			log.error("Function to Add Initiative Rule Failed", e);
		} finally {

			obj.repGenerateResult(Test_Case_Name, header);
			obj.repGenerateIndexReport(indexHeader);
			obj.repGenerateIndexReportemail(indexHeader_email);
			header = null;
			log.info("Execution of Function to Add a Initiative Rule Completed");
		}
		return obj;
	}


	
	////////////////////////////////////////////////////////////////////////////////////////////
	//Active Inactive service type//////////////////////////////////////////////////////////////

		public PrepareReport fn1091(PrepareReport obj) throws Exception {

			Boolean baistFlag = true;

			log.info("Executing function to active inactive service type .....");

			header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

			try {
				if (driver == null) {
					bLoginFlag = fnLoginAttempt();
				}
				baistFlag = aist.activeInactiveService();
				obj.repAddData("Test Result", "", "", "");
				if (baistFlag == true) {
					obj.repAddData("active inactive service type", "active inactive service type should be successfully",
							"active inactive service type  was Successful", "Pass");
					PrepareReport.totalPass++;
				} else {
					obj.repAddData("active inactive service type", "active inactive service type be  successfully",
							"active inactive service type Failed", "Fail");
					PrepareReport.totalFail++;
				}
			} catch (Exception e) {
				e.printStackTrace();
				testCaseFlow = false;
				obj.repAddData("Error handler", "There should not be any error/exception in the test",
						"Exception found in current test", "Fail");
				PrepareReport.totalFail++;
				log.error("Function active inactive service type Failed", e);
			} finally {

				obj.repGenerateResult(Test_Case_Name, header);
				obj.repGenerateIndexReport(indexHeader);
				obj.repGenerateIndexReportemail(indexHeader_email);
				header = null;
				log.info("Execution of Function active inactive service type Completed");
			}
			return obj;
		}

	
		
		
		////////////////////////////////////////////////////////////////////////////////////////////
		//Audit Gen Run Labels for Initiative workflow status//////////////////////////////////////////////////////////////

			public PrepareReport fn1092(PrepareReport obj) throws Exception {

				Boolean bagrlfiwsFlag = true;

				log.info("Executing function to active inactive service type .....");

				header = PrepareReport.repGenerateHeader(SuiteName, Test_Case_Name, Application, Test_Case_Description);

				try {
					if (driver == null) {
						bLoginFlag = fnLoginAttempt();
					}
					bagrlfiwsFlag = agrlfiws.AudGenRunLabelForIniFnFlow();
					obj.repAddData("Test Result", "", "", "");
					if (bagrlfiwsFlag == true) {
						obj.repAddData("Audit Gen Run Label ", "Audit Gen Run Label  should be successfully",
								"Audit Gen Run Label   was Successful", "Pass");
						PrepareReport.totalPass++;
					} else {
						obj.repAddData("Audit Gen Run Label ", "Audit Gen Run Label should be successfully",
								"Audit Gen Run Label  Failed", "Fail");
						PrepareReport.totalFail++;
					}
				} catch (Exception e) {
					e.printStackTrace();
					testCaseFlow = false;
					obj.repAddData("Error handler", "There should not be any error/exception in the test",
							"Exception found in current test", "Fail");
					PrepareReport.totalFail++;
					log.error("Audit Gen Run Label  Failed", e);
				} finally {

					obj.repGenerateResult(Test_Case_Name, header);
					obj.repGenerateIndexReport(indexHeader);
					obj.repGenerateIndexReportemail(indexHeader_email);
					header = null;
					log.info("Execution of Function Audit Gen Run Label  Completed");
				}
				return obj;
			}



}
