package com.mhplan.qms.reportmanager;




import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.mhplan.qms.DriverScript;
import com.mhplan.qms.ConfigManager.FileLoc;
import com.mhplan.qms.ConfigManager.SQLConfig;



public class PrepareReport extends DriverScript
{
	
	public static ArrayList<ReportEntity> reportList;
	public static ArrayList<ReportEntity> reportListdb;
	public static ArrayList<MasterEntity> masterList;
	
	public static final String strFinal=null;
	public static String chromeDriverPath ="";
	public static int slNo;
	static int totalCnt; // total step count
	static int passCnt; // step pass
	static int failCnt; // step fail
	static int incompleteCnt=0; // step incomplete
	private static final String buildNumber = "buildNumber";
	private static final String result = "/Results/";
	private static final String stylesheet = "<html><head><link rel = \"stylesheet\" href = \"";
	private static final String date = "MM-dd-yyyy";
	private static final String datetime = "MM/dd/yyyy hh:mm:ss a";
	private static final String ui = "uivalidation";
	private static final String incomplete = "Incomplete";
	private static final String dbvalidation = "dbvalidation";
	private static final String px75 = "<tr><td class = \"tsindlevel2\" width = 75px>";
	private static final String px155 = "</td><td class = \"tsgen\" width = 155px>";
	private static final String px285 = "</td><td class = \"tsgen\" width = 285px>";
	private static final String px285_1 = " </td><td class = \"tsgen\" width = 285px>";
	private static final String srreenSrc = "'\"><img class = \"screen\" src  =  \"";
	private static final String tableBr = "</table><BR><BR>";
	private static final String px40 = "</td>\n<td class = \"tsind\" width = 40px>";
	
	
	static int diff = 0;
	
	static int testCaseCnt = 0;
	
	public static int totalExecuted = 0;
	public static int totalPass = 0;
	public static int totalFail = 0;
	public static final int totalIncomplete = 0;
	public static final int totalPlanned = 0;
	
	static int testPassCnt= 0;
	static int testFailCnt = 0;
	static int testIncompleteCnt = 0;
	static int ttlPassCnt = 0;
	static int ttlFailCnt = 0;
	static int ttlIncompleteCnt = 0;
	static int testCnt = 0;
	
	
	@SuppressWarnings("rawtypes")
	static ArrayList tc;
	static String strDiff = "";
	static String startTime = "";
	static Date startDate;
	static Date endDate;
	static Date testStartDate;
	static Date testEndDate;
	public  int i;
	public String rowid;
	public static File file;
 
	
	static final String PATH = FileLoc.sReportsPath+"Results\\";
    static final String REFPATH = FileLoc.sReportsPath+"ReportInfo\\";	
	
	public static String filePath; // local report testcase folder
	public static String shareFolderPath; // track shared folder path
	
	SQLConfig objSQLConfig = new SQLConfig();
	/* @@@ Generate Header for the index HTML @@@ */
	

	
	public static String repGenerateIndexHeader(String testEnv, String appName, String productionType, String testPhase) throws Exception
	{
		String indexHeaderHtmlContent = "";
		String miniPathJenkins = null;
		String miniPathEclipse = null;
		String sSharedServerIP = null; //Commented by VL 
		ttlFailCnt = 0;
		testCnt = 0;
		testStartDate = null;
		File dir = null;
		testStartDate = new Date();
		
		sSharedServerIP =  DriverScript.prop.getProperty("sharedServerIP");
		
		//Commented by VL 
		
		
		miniPathEclipse = testEnv+"_"
				+ appName+"_"
				+ productionType+"_"
				+ testPhase+"_"
				+ new SimpleDateFormat("MM_dd_yyyy_hh_mm_ss_a")
						.format(new Date());
		
		
		miniPathJenkins = testPhase+"_"+System.getenv(buildNumber);
		
	
		String buildnumber = System.getenv(buildNumber);
		if (buildnumber == null)
		{
		filePath = FileLoc.sReportsPath+result+ miniPathEclipse;    //LVCOMMENTED-0826
		folderPath = filePath; // save path of local report folder
		}else {
			filePath = FileLoc.sReportsPath+result+ miniPathJenkins;    //LVCOMMENTED-0826
			folderPath = filePath; // save path of local report folder
		}
		
		
	
		
		
		shareFolderPath = "\\\\"+sSharedServerIP+"\\";
		if (buildnumber == null)
		{
		shareFolderPath = shareFolderPath + miniPathEclipse;
		}else {
			shareFolderPath = shareFolderPath + miniPathJenkins;
			
		}
			
		dir = new File(filePath);
		
		dir.mkdir();
	
		masterList = new ArrayList<MasterEntity>();
		indexHeaderHtmlContent = stylesheet
				+ "../ReportInfo/css/styles.css\" /></head><body><hr class = \"divline\"><table class = \"reportheader\" width = 80000px><tr><td height = 100px><img src  = '"
				+ "../ReportInfo/Images/logo_en.gif' style=\"margin: 15px;padding: 5px;float: left;text-align: center;position: absolute;top: 0.5px;left: 5px;width:290px;height:80px\"></td><BR><td height = 3px>"
				//+ appName
				+ mMasterSheetData.get(iMasterRowId).get("Suite_Name")
				+ "<BR><td height = 3px align = right></td></tr></table><hr class = \"divline\"><BR><table class = \"subheader\" width = 900px><tr><td width = 400px class = \"subheader\" align = left>Test Run</td><td width = 300px class = \"subheader\">Execution Date</td><td width = 350px class = \"subheader\" align = right>Test Environment</td></tr><tr><td width = 400px class = \"subcontents\" align = left>"
				+ testPhase
				+ "</td><td width = 300px class = \"subcontents\">"
				+ new SimpleDateFormat(date).format(testStartDate)
				+ "</td><td width = 400px class = \"subcontents\" align = right>"
				+ testEnv + "</td></tr></table><hr class = \"divline\"><BR>";
		
		
		return indexHeaderHtmlContent;
	}

	public static String repGenerateIndexHeaderemail(String testEnv, String appName, String productionType, String testPhase) throws Exception
	{
		String indexHeaderHtmlContent = "";
		String miniPathJenkins = null;
		String miniPathEclipse = null;
		String sSharedServerIP = null; //Commented by VL 
		ttlFailCnt = 0;
		testCnt = 0;
		testStartDate = null;
		File dir = null;
		testStartDate = new Date();
		
		sSharedServerIP =  DriverScript.prop.getProperty("sharedServerIP");
		
		//Commented by VL 
		
		
		miniPathEclipse = testEnv+"_"
				+ appName+"_"
				+ productionType+"_"
				+ testPhase+"_"
				+ new SimpleDateFormat("MM_dd_yyyy_hh_mm_ss_a")
						.format(new Date());
		
	
		miniPathJenkins = testPhase+"_"+System.getenv(buildNumber);
		
		String buildnumber = System.getenv(buildNumber);
		if (buildnumber == null)
		{
		filePath = FileLoc.sReportsPath+result+ miniPathEclipse;    //LVCOMMENTED-0826
		folderPath = filePath; // save path of local report folder
		}else {
			filePath = FileLoc.sReportsPath+result+ miniPathJenkins;    //LVCOMMENTED-0826
			folderPath = filePath; // save path of local report folder
		}
	
		

		shareFolderPath = "\\\\"+sSharedServerIP+"\\";
		if (buildnumber == null)
		{
		shareFolderPath = shareFolderPath + miniPathEclipse;
		}else {
			shareFolderPath = shareFolderPath + miniPathJenkins;
			
		}
		
		dir = new File(filePath);
		
		dir.mkdir();
		
		masterList = new ArrayList<MasterEntity>();
		indexHeaderHtmlContent = stylesheet
				+ "cid:styles_email.css\" /></head><body><table class = \"reportheader\" width = 8000px><tr><td height = 50px><img src  = '"
				+ "cid:logo_en_email.gif' style=\"margin: 15px;padding: 5px;float: center;text-align: center;position: absolute;top: 50.5px;left: 5px;width:290px;height:80px\"></td><BR><td height = 6px>"
				//+ appName
				+ mMasterSheetData.get(iMasterRowId).get("Suite_Name")
				+ "<BR><td height = 6px align = center></td></tr></table><BR><table class = \"subheader\" width = 900px><tr><td width = 400px class = \"subheader\" align = center>Test Run</td>&nbsp&nbsp&nbsp&nbsp<td width = 300px class = \"subheader\">Execution Date</td>&nbsp&nbsp&nbsp&nbsp<td width = 350px class = \"subheader\" align = right>Test Environment</td></tr><tr><td width = 400px class = \"subcontents\" align = left>"
				+ testPhase
				+ "&nbsp&nbsp&nbsp&nbsp</td><td width = 300px class = \"subcontents\">"
				+ new SimpleDateFormat(date).format(testStartDate)
				+ "&nbsp&nbsp&nbsp&nbsp</td><td width = 400px class = \"subcontents\" align = left>"
				+ testEnv + "</td></tr></table><BR>";
		
		
		return indexHeaderHtmlContent;
	}

	
	/* @@@ Generate Header for the HTML @@@ */

	public static String repGenerateHeader(String testCaseHeader,
			String testCase, String application, String testCaseDescription)
			throws IOException, ParseException {

		String headerHtmlContent = "";
		passCnt = 0;
		totalCnt = 0;
		failCnt = 0;
		incompleteCnt = 0;
		startTime = "";
		reportList = new ArrayList<ReportEntity>();

		startDate = null;
		endDate = null;
		
		startDate = new Date();

		headerHtmlContent = stylesheet
				+ "../ReportInfo/css/styles.css\" /></head><hr class = \"divline\"><table class = \"reportheader\" width = 80000px><tr><td height = 100px><img src = '" //LV Commented
				+ "../ReportInfo/Images/logo_en.gif'style=\"margin: 15px;padding: 5px;float: left;text-align: center;position: absolute;top: 0.5px;left: 5px;width:290px;height:80px\"></td><BR><td height = 3px>"   //LVCommented
				+ testCaseHeader
				+ "<BR><td height = 3px align = right></td></tr></table><hr class = \"divline\"><BR><table class = \"subheader\" width = 900px><tr><td width = 400px class = \"subheader\">Test Case</td><td width = 300px class = \"subheader\">Execution Date</td><td width = 200px align = right class = \"subheader\">Application</td></tr><tr><td width = 400px class = \"subcontents\">"
				+ testCase
				+ "</td><td width = 300px class = \"subcontents\">"
				+ new SimpleDateFormat(date).format(startDate)
				+ "</td><td width = 200px align = right class = \"subcontents\">"
				+ application
				+ "</td></tr></table><hr class = \"divline\"> <BR><table class = \"subheader\" width = 900px><tr><tr><td width = 900px class = \"subheader\">Test Case Description</td></tr><tr><td width = 900px class = \"subcontents\">"
				+ testCaseDescription
				+ "</td></tr></tr></table><hr class = \"divline\"><BR>";
		return headerHtmlContent;
	}

	/* @@@ Generate Footer for the HTML @@@ */

	public String repGenerateFooter() {
		String footer = "";
		endDate = new Date();
		
		diff = (int) ((endDate.getTime() / 1000) - (startDate.getTime() / 1000));
		if ((diff / 60) != 0) {
			strDiff = ((diff / 60) + "Min" + " " + (diff % 60) + "Secs");
		} else {
			strDiff = ((diff % 60) + " " + "Secs");
		}
		
		
	
		footer = "<table class = \"tblinks\" width = 250px align = left><tr><td class = \"tsheader\">Links</td></tr><tr><td class = \"pfind\"><a href = "+DriverScript.sIndexHTMLFileName+">Index Page</a></td></tr></table><table width = 250px class = \"tbtime\"><tr><td colspan = 2 class = \"tsheader\">Execution Time</td></tr><tr><td class = \"pfhead\" width = 120px>Start Time</td><td class = \"pfind\" width = 130px>"
				+ new SimpleDateFormat(datetime)
						.format(startDate)
				+ "</td></tr><tr><td class = \"pfhead\" width = 120px>End Time</td><td class = \"pfind\" width = 130px>"
				+ new SimpleDateFormat(datetime).format(endDate)
				+ "</td></tr><tr><td class = \"pfhead\" width = 600px>Duration</td><td class = \"pfind\" width = 600px>"
				+ strDiff
				+ "  </td></tr></table><!-- Pass Fail count--><table width = 250px class = \"pfsummary\"><tr><td colspan = 2 class = \"tsheader\">Test Case Summary</td></tr><tr><td class = \"pfhead\" width = 200px>Total Steps</td><td class = \"pfind\" width = 50px>"
				+ totalCnt
				+ "</td>	</tr><tr><td class = \"pfhead\" width = 200px>Steps Passed</td><td class = \"pfind\" width = 50px>"
				+ passCnt
				+ "</td></tr><tr><td class = \"pfhead\" width = 200px>Incomplete</td><td class = \"pfind\" width = 50px>"+incompleteCnt+"</td></tr><tr><td class = \"pfhead\" width = 200px>Steps Failed</td><td class = \"pfind\" width = 50px>"
				+ failCnt + "</td></tr></table><BR><BR>";
		return footer;
	}

	/* @@@ Generate Footer for the index HTML @@@ */

	public String repGenerateIndexFooter() 
	{
	
		String footer = "";
		endDate = new Date();
		diff = (int) ((endDate.getTime() / 1000) - (testStartDate.getTime() / 1000));
		if ((diff / 60) != 0) {
			strDiff = ((diff / 60) + "Min" + " " + (diff % 60) + " " + "Secs");
		} else {
			strDiff = ((diff % 60) + " Secs");
		}
		
		footer = "<table width = 250px class = \"tbtime\"><tr><td colspan = 2 class = \"tsheader\">Execution Time</td></tr><tr><td class = \"pfhead\" width = 120px>Start Time</td><td class = \"pfind\" width = 130px>"
				+ new SimpleDateFormat(datetime)
						.format(testStartDate)
				+ "</td></tr><tr><td class = \"pfhead\" width = 120px>End Time</td><td class = \"pfind\" width = 130px>"
				+ new SimpleDateFormat(datetime).format(endDate)
				+ "</td></tr><tr><td class = \"pfhead\" width = 120px>Duration</td><td class = \"pfind\" width = 130px>"
				+ strDiff
				+ " </td></tr></table><table width = 250 class = \"pfsummary\"><tr><td colspan = 2 class = \"tsheader\">Test Cases Summary</td></tr><tr><td class = \"pfhead\" width = 200px>Total Test Cases</td> <td class = \"pfind\" width = 50px>"
				+ totalExecuted
				+ "</td></tr><tr><td class = \"pfhead\" width = 200px>Test Cases Passed</td><td class = \"pfind\" width = 50px> "
				+ totalPass
				+ "</td></tr><tr><td class = \"pfhead\" width = 200px>Incomplete Test Cases</td><td class = \"pfind\" width = 50px>"+totalIncomplete+"</td></tr><tr><td class = \"pfhead\" width = 200px>Test Cases Failed</td><td class = \"pfind\" width = 50px>"
				+ totalFail + "</td></tr></table></body></html>";

		
		
		return footer;
		
	
	}

	/* @@@ Generate Body content for the HTML @@@ */

	//public void repAddData(String step, String stepDescription,String expectedResult, String actualResult, String status) throws Exception 
	public void repAddData(String stepDescription,String expectedResult, String actualResult, String status) throws Exception
	{
		try {
			String step = "";
			String stepType = ui;
		if(expectedResult.equalsIgnoreCase("") && actualResult.equalsIgnoreCase("") && status.equalsIgnoreCase(""))
			{
				mainStep++;
				step=String.valueOf(mainStep);
				subStep=0;  //If we start a new tc header like 2 and 3
			}
			else
			{
				subStep++;
				step=String.valueOf(mainStep)+"."+String.valueOf(subStep);
				
			}
			
	
			
			if(status.equalsIgnoreCase("Fail"))
			{
				String fileName = "";
				testCaseFlow = false;
				
				ReportEntity re = new ReportEntity();
				if (step.indexOf(".") != -1) {
					re.setStep(step);
					re.setStepDescription(stepDescription);
					re.setExpectedResult(expectedResult);
					re.setActualResult(actualResult);
					re.setStatus(status.toUpperCase());
					re.setStepType(stepType);
					fileName = ScreenCapture.screenShotCapture(filePath);
					re.setScreenShotFileName(fileName);
				
				re.setTimeStamp();
				} else 
				{
					re.setStep(step);
					re.setStepDescription(stepDescription);
					re.setStepType(stepType);
				}
				reportList.add(re);
			} 
			else if(status.equalsIgnoreCase(incomplete))
			{
				String fileName = "";
				testCaseFlow = false;
				
				ReportEntity re = new ReportEntity();
				if (step.indexOf('.') != -1) {
					re.setStep(step);
					re.setStepDescription(stepDescription);
					re.setExpectedResult(expectedResult);
					re.setActualResult(actualResult);
					re.setStatus(status.toUpperCase());
					fileName = ScreenCapture.screenShotCapture(filePath);
					re.setScreenShotFileName(fileName);
					re.setTimeStamp();
					re.setStepType(stepType);
				} else 
				{
					re.setStep(step);
					re.setStepDescription(stepDescription);
					re.setStepType(stepType);
				}
				reportList.add(re);
			}
			
			else 
			{
				String fileName = "";

				ReportEntity re = new ReportEntity();
				if (step.indexOf('.') != -1) {
					re.setStep(step);
					re.setStepDescription(stepDescription);
					re.setExpectedResult(expectedResult);
					re.setActualResult(actualResult);
					re.setStatus(status.toUpperCase());
					fileName = ScreenCapture.screenShotCapture(filePath);
					re.setScreenShotFileName(fileName);
					re.setTimeStamp();
					re.setStepType(stepType);
				} else 
				{
					re.setStep(step);
					re.setStepDescription(stepDescription);
					re.setStepType(stepType);
				}
				reportList.add(re);
			}
			
			System.out.println("["+step+"]"+"["+stepDescription+"]"+"["+expectedResult+"]"+"["+actualResult+"]"+"["+status+"]");

		} catch (Exception e) {
			System.out.println(e);
		}
		
	}	

		
	
	public void repAdddbData(String stepDescription,String expectedResult, String actualResult, String status) throws Exception
	{
		try {
			String step = "";
			String stepType = dbvalidation;
		if(expectedResult.equalsIgnoreCase("") && actualResult.equalsIgnoreCase("") && status.equalsIgnoreCase(""))
			{
				mainStep++;
				
				step=String.valueOf(mainStep);
				
				subStep=0;  //If we start a new tc header like 2 and 3
			}
			else
			{
				subStep++;
				
				step=String.valueOf(mainStep)+"."+String.valueOf(subStep);
				
				
				
			}
			
		
			
			if(status.equalsIgnoreCase("Fail"))
			{
				String fileName = "";
				testCaseFlow = false;
				
				ReportEntity re1 = new ReportEntity();
				if (step.indexOf('.') != -1) {
					re1.setStep(step);
					re1.setStepDescription(stepDescription);
					re1.setExpectedResult(expectedResult);
					re1.setActualResult(actualResult);
					re1.setStatus(status.toUpperCase());
					re1.setStepType(stepType);
					
				
				re1.setTimeStamp();
				} else 
				{
					re1.setStep(step);
					re1.setStepDescription(stepDescription);
					re1.setStepType(stepType);
				}
				reportList.add(re1);
			} 
			else if(status.equalsIgnoreCase(incomplete))
			{
				String fileName = "";
				testCaseFlow = false;
				
				ReportEntity re1 = new ReportEntity();
				if (step.indexOf('.') != -1) {
					re1.setStep(step);
					re1.setStepDescription(stepDescription);
					re1.setExpectedResult(expectedResult);
					re1.setActualResult(actualResult);
					re1.setStatus(status.toUpperCase());
					re1.setStepType(stepType);
					re1.setTimeStamp();
				} else 
				{
					re1.setStep(step);
					re1.setStepDescription(stepDescription);
					re1.setStepType(stepType);
				}
				reportList.add(re1);
			}
			
			else 
			{
				String fileName = "";

				ReportEntity re1 = new ReportEntity();
				if (step.indexOf('.') != -1) {
					re1.setStep(step);
					re1.setStepDescription(stepDescription);
					re1.setExpectedResult(expectedResult);
					re1.setActualResult(actualResult);
					re1.setStatus(status.toUpperCase());
					re1.setStepType(stepType);
				
					re1.setTimeStamp();
				} else 
				{
					re1.setStep(step);
					re1.setStepDescription(stepDescription);
					re1.setStepType(stepType);
				}
				reportList.add(re1);
			}
			
			
			System.out.println("["+step+"]"+"["+stepDescription+"]"+"["+expectedResult+"]"+"["+actualResult+"]"+"["+status+"]");

		} catch (Exception e) {
			System.err.println(e);
			
		}
		
	}	
	

	/* @@@ Generate the child test report HTML @@@ */

	public void repGenerateResult(String testName, String header)	throws Exception 
	{
		
		String str = "";
		String strdb = "";
		String footer = "";
		MasterEntity me = new MasterEntity();

		slNo++;
		for (int i = 0; i < reportList.size(); i++) 
		{
			if (reportList.get(i).getStep().indexOf('.') == -1) 
			{
				str = str
						+ "<tr><td class = \"tsindlevel1\" width = 75px>"
						+ reportList.get(i).getStep()
						+ "</td><td class = \"tsgenlevel1\" width = 155px>"
						+ reportList.get(i).getStepDescription()
						+ "</td><td class = \"tsgenlevel1\" width = 285px></td><td class = \"tsgenlevel1\" width = 285px></td><td class = \"tsindlevel1\" width = 50px>&nbsp</td></tr>";
			} else 
			{
				totalCnt++; //total test step count
				if ("Pass".equalsIgnoreCase(reportList.get(i).getStatus()) && ui.equalsIgnoreCase(reportList.get(i).getStepType())) 
				{
					passCnt++; //total testcase passed
					         str = str
							+ px75
							+ reportList.get(i).getStep()
							+ px155
							+ reportList.get(i).getStepDescription()
							+ px285_1
							+ reportList.get(i).getExpectedResult()
							+ px285
							+ reportList.get(i).getActualResult()
							+ "</td><td class = \"tsind\" width = 50px><font size  =  2 color  =  green><b>"
							+ reportList.get(i).getStatus()
							+ "</b></td><td class = \"tsind\" width = 50px><a target = \"_blank\" class = \"anibutton\" href =  '"
							+ reportList.get(i).getScreenShotFileName()
							+ srreenSrc
							+ "../ReportInfo/Images/screenshot.gif\"></a></td></tr>";
					
					
				} 
				
				else if ("Pass".equalsIgnoreCase(reportList.get(i).getStatus()) && dbvalidation.equalsIgnoreCase(reportList.get(i).getStepType()))
					
				{
					passCnt++; //total testcase passed
					 str = str
							+ px75
							+ reportList.get(i).getStep()
							+ px155
							+ reportList.get(i).getStepDescription()
							+ px285_1
							+ reportList.get(i).getExpectedResult()
							+ px285
							+ reportList.get(i).getActualResult()
							+ "</td><td class = \"tsind\" width = 50px><font size  =  2 color  =  green><b>"
							+ reportList.get(i).getStatus()
							+ "</b></td></tr>";
					
					
				} 
				else if (incomplete.equalsIgnoreCase(reportList.get(i).getStatus()) && ui.equalsIgnoreCase(reportList.get(i).getStepType())) 
				{
					incompleteCnt++; //total testcase incompleted
					str = str
							+ px75
							+ reportList.get(i).getStep()
							+ px155
							+ reportList.get(i).getStepDescription()
							+ px285_1
							+ reportList.get(i).getExpectedResult()
							+ px285
							+ reportList.get(i).getActualResult()
							+ "</td><td class = \"tsind\" width = 50px><font size  =  1 color  =  black><img src  =  '"
							+ "../ReportInfo/Images/Incomplete.gif'/>"
							+ reportList.get(i).getStatus()
							+ "</td><td class = \"tsind\" width = 50px><a target = \"_blank\" class = \"anibutton\" href =  '"
							+ reportList.get(i).getScreenShotFileName()
							+ srreenSrc
							+ "../ReportInfo/Images/screenshot.gif\"></a></td></tr>";
					
					
				}
				
				else if (incomplete.equalsIgnoreCase(reportList.get(i).getStatus()) && dbvalidation.equalsIgnoreCase(reportList.get(i).getStepType())) 
				{
					incompleteCnt++; //total testcase incompleted
					str = str
							+ px75
							+ reportList.get(i).getStep()
							+ px155
							+ reportList.get(i).getStepDescription()
							+ px285_1
							+ reportList.get(i).getExpectedResult()
							+ px285
							+ reportList.get(i).getActualResult()
							+ "</td><td class = \"tsind\" width = 50px><font size  =  1 color  =  black><img src  =  '"
							+ "../ReportInfo/Images/Incomplete.gif'/>"
							+ reportList.get(i).getStatus()
							//+ "</b></td><td class = \"tsind\" width = 50px>&nbsp</td></tr>";
							+ "</td></tr>";
					
					
				}
				
				else if ("Fail".equalsIgnoreCase(reportList.get(i).getStatus()) && ui.equalsIgnoreCase(reportList.get(i).getStepType())) 
					
				{
					failCnt++; //total testcase failed
					str = str
							+ px75
							+ reportList.get(i).getStep()
							+ px155
							+ reportList.get(i).getStepDescription()
							+ px285_1
							+ reportList.get(i).getExpectedResult()
							+ px285
							+ reportList.get(i).getActualResult()
							+ "</td><td class = \"tsind\" width = 50px><font size  =  2 color  =  red><b><img src  =  '"
							+ "../ReportInfo/Images/failed.gif'/>"
							+ reportList.get(i).getStatus()
							+ "</b></td><td class = \"tsind\" width = 50px><a target = \"_blank\" class = \"anibutton\" href =  '"
							+ reportList.get(i).getScreenShotFileName()
							+ srreenSrc
							+ "../ReportInfo/Images/screenshot.gif\"></a></td></tr>";
				}
				
				else if ("Fail".equalsIgnoreCase(reportList.get(i).getStatus()) && dbvalidation.equalsIgnoreCase(reportList.get(i).getStepType()))
				
				
				{
					failCnt++; //total testcase failed
					str = str
							+ px75
							+ reportList.get(i).getStep()
							+ px155
							+ reportList.get(i).getStepDescription()
							+ px285_1
							+ reportList.get(i).getExpectedResult()
							+ px285
							+ reportList.get(i).getActualResult()
							+ "</td><td class = \"tsind\" width = 50px><font size  =  2 color  =  red><b><img src  =  '"
							+ "../ReportInfo/Images/failed.gif'/>"
							+ reportList.get(i).getStatus()
							+ "</b></td></tr>";
				}
			}
		}
		
		
		
		

		String bTblHdr = "<BR><table width = 900px class = \"teststeps\"><tr><td class = \"tsheader\" width = 75px>Step #</td><td class = \"tsheader\" width = 155px>Step Description</td><td class = \"tsheader\" width = 285px>Expected Result</td><td class = \"tsheader\" width = 285px>Actual Result</td><td class = \"tsheader\" width = 50px>Status</td><td class = \"tsheader\" width = 50px>Screen Shot</td></tr>";
		footer = repGenerateFooter();
		file = new File(filePath + "/" + testName + ".html"); //LVCOMMENTED-0826
		
		System.out.println("HTML test case report: " + file);
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		String output = header
				+ "<body><table BORDER = 1 CELLPADDING = 3 CELLSPACING = 1 WIDTH = 100%>"
				+ bTblHdr + str + tableBr + footer
				+ "</body></html>";
		bw.write(output);
		bw.close();

		/* @@@ Prepare Data for index.html @@@ */

		me.setSlNo(slNo);
		me.setTestCase(Test_Case_Name);
		me.setTestDesc(Test_Case_Description);
		me.setSteps(totalCnt); // total count of steps in Index
		me.setPass(passCnt); // total count of pass steps in Index
		me.setIncomplete(incompleteCnt);
		me.setFail(failCnt); // total count of fail steps in Index
		
		if (incompleteCnt!=0) {
			me.setStatus(incomplete);
			System.out.println("Not Completed");

		}
		else if (failCnt == 0 && incompleteCnt==0) {
			me.setStatus("PASS");
			System.out.println("Passed");

		} 
		else {
			me.setStatus("FAIL");
			System.out.println("Failed");
		}
		
		
		
		me.setDuration(strDiff);
		me.setHistory(strFinal);
		masterList.add(me);
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
	

	}
	
	
	

	/* @@@ Generate the index report HTML @@@ */

	public void repGenerateIndexReport(String indexHeaderHtmlContent) throws Exception 
	{
		String tblHdr = "";
		String content = "";
		String footerCntnt = "";
		String imgSrc = "";
	System.out.println(" Inside generate index report");
	
	System.out.println("***************************" + filePath);

		
		tblHdr = "<BR><table width = 900 class = \"teststeps\"><tr><td class = \"tsheader\" width = 20px>SNo</td><td class = \"tsheader\" width = 185px>Test Case</td><td class = \"tsheader\" width = 185 px>Description</td><td class = \"tsheader\" width = 25px>Steps</td><td class = \"tsheader\" width = 40px>Passed</td><td class = \"tsheader\" width = 40px>Incomplete</td><td class = \"tsheader\" width = 40px>Failed</td><td class = \"tsheader\" width = 50px>Status</td><td class = \"tsheader\" width = 25px>Duration</td><td class = \"tsheader\" width = 60px>History</td></tr>";
				
		for (int i = 0; i < masterList.size(); i++) 
		{
			testCnt++;
			if (masterList.get(i).getStatus().trim()
					.equalsIgnoreCase("Pass")) {
				ttlPassCnt++;
				imgSrc = "../ReportInfo/Images/pass.gif";
			} 
			
			else if (masterList.get(i).getStatus().trim()
					.equalsIgnoreCase("Incomplete")) {
				ttlIncompleteCnt++;
				imgSrc = "../ReportInfo/Images/Incomplete.gif";
			} 
			
			else {
				ttlFailCnt++;
				imgSrc = "../ReportInfo/Images/failed.gif";
			}
			
			
			content = content
					+ "\n\n<tr>\n<td class = \"tsind\" width = 20px>"
					+ masterList.get(i).getSlNo()
					+ "</td>\n<td class = \"tsgen\" width = 200px><a class = \"tcindex\" href = \""
					+ masterList.get(i).getTestCase() + ".html\">"
					+ masterList.get(i).getTestCase()
					+ "</a></td>\n<td class = \"tsgen\" width = 200px>"
					+ masterList.get(i).getTestDesc()
					+ "</td>\n<td class = \"tsind\" width = 25px>"
					+ masterList.get(i).getSteps()
					+ px40
					+ masterList.get(i).getPass()
					+ px40
					+ masterList.get(i).getIncomplete()
					+ px40
					+ masterList.get(i).getFail()
					+ "</td>\n<td class = \"tsind\" width = 50px><img src  =  '"
					+ imgSrc + "' width = \"20\" height = \"20\">"
					+ masterList.get(i).getStatus()
					+ px40
					+ masterList.get(i).getDuration() + "</td>"
					+"\n<td  class=\"pfind\" width=40px>"+ masterList.get(i).getHistory() +"</td>\n</tr>\n\n";  
					
			
		}
		
		footerCntnt = repGenerateIndexFooter();
		
		
		
		
		file = new File(filePath + "/" + DriverScript.sIndexHTMLFileName); //LVCOMMENTED-0826
		
		System.out.println("file " + file);
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		String output = indexHeaderHtmlContent
				+ "<body><table BORDER = 1 CELLPADDING = 4 CELLSPACING = 1 WIDTH = 100%>"
				+ tblHdr + content + tableBr + footerCntnt
				+ "<BR><BR><BR><BR><BR><BR><BR><BR>"; // + resultCntnt;
		bw.write(output);
		bw.close();
		
	}
	
	public void repGenerateIndexReportemail(String indexHeaderHtmlContentemail) throws Exception 
	{
		String tblHdr = "";
		String content = "";
		String footerCntnt = "";
		String imgSrc = "";
	System.out.println(" Inside generate index report for email");
	
	System.out.println("***************************" + filePath);

		
		tblHdr = "<BR><table width = 600 class = \"teststeps\"><tr><td class = \"tsheader\" width = 20px>SNo</td><td class = \"tsheader\" width = 185px>Test Case</td><td class = \"tsheader\" width = 185 px>Description</td><td class = \"tsheader\" width = 25px>Steps</td><td class = \"tsheader\" width = 40px>Passed</td><td class = \"tsheader\" width = 40px>Incomplete</td><td class = \"tsheader\" width = 40px>Failed</td><td class = \"tsheader\" width = 50px>Status</td><td class = \"tsheader\" width = 25px>Duration</td><td class = \"tsheader\" width = 60px>History</td></tr>";
				
		for (int i = 0; i < masterList.size(); i++) 
		{
			testCnt++;
			if (masterList.get(i).getStatus().toString().trim()
					.equalsIgnoreCase("Pass")) {
				ttlPassCnt++;
				imgSrc = "cid:pass.GIF";
			} 
			
			else if (masterList.get(i).getStatus().trim()
					.equalsIgnoreCase("Incomplete")) {
				ttlIncompleteCnt++;
				imgSrc = "cid:Incomplete.gif";
			} 
			
			else {
				ttlFailCnt++;
				imgSrc = "cid:failed.gif";
			}
			
			
			content = content
					+ "\n\n<tr>\n<td class = \"tsind\" width = 20px>"
					+ masterList.get(i).getSlNo()
					+ "</td>\n<td class = \"tsgen\" width = 200px><a class = \"tcindex\" href = \""+ "file:///w:/MI/IT/Development/Team/QA/Selenium_Reports/QMS/QA/Regression_"+System.getenv("buildNumber")+"/"
					+ masterList.get(i).getTestCase() + ".html\">"
					+ masterList.get(i).getTestCase()
					+ "</a></td>\n<td class = \"tsgen\" width = 200px>"
					+ masterList.get(i).getTestDesc()
					+ "</td>\n<td class = \"tsind\" width = 25px>"
					+ masterList.get(i).getSteps()
					+ px40
					+ masterList.get(i).getPass()
					+ px40
					+ masterList.get(i).getIncomplete()
					+ px40
					+ masterList.get(i).getFail()
					+ "</td>\n<td class = \"tsind\" width = 50px><img src  =  '"
					+ imgSrc + "' width = \"20\" height = \"20\">"
					+ masterList.get(i).getStatus()
					+ px40
					+ masterList.get(i).getDuration() + "</td>"
					+"\n<td  class=\"pfind\" width=40px>"+ masterList.get(i).getHistory() +"</td>\n</tr>\n\n";  
				
			
		}
		
		footerCntnt = repGenerateIndexFooter();
		
		
		
		
		file = new File(filePath + "/" + DriverScript.sIndexHTMLFileNameemail); //LVCOMMENTED-0826
		
		System.out.println("file " + file);
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		String output = indexHeaderHtmlContentemail
				+ "<body><table BORDER = 1 CELLPADDING = 4 CELLSPACING = 1 WIDTH = 100%>"
				+ tblHdr + content + tableBr + footerCntnt
				+ "<BR><BR>"; // + resultCntnt;
		bw.write(output);
		bw.close();
		
	}
	
	public void repGenerateTextReport() 
	{
		try
		{
			
		    File logFile=new File(filePath + "\\" + Test_Case_Name +".txt");

		    String input="";
		    
		    // write it into file
		    BufferedWriter bw = new BufferedWriter(new FileWriter(logFile));
		    
		    for (int i = 0; i < reportList.size(); i++) 
			{
				if (reportList.get(i).getStep().indexOf(".") == -1) 
				{
					
				} else 
				{
					input = Test_Case_ID+"|";
					bw.write (input);
					
					input = Environment+"|"; 
					bw.write (input);
					
					input = Phase+"|";
					bw.write (input);
					
					input = Release+"|";
					bw.write (input);
					
					input = Application+"|";
					bw.write (input);
					
					
					input = Test_Case_Name+"|";
					bw.write (input);
					
					input = Test_Case_Description+"|";
					bw.write (input);
					
					input = reportList.get(i).getStep()+"|";
					bw.write (input);
					
					input = reportList.get(i).getStepDescription()+"|";
					bw.write (input);
					
					input = reportList.get(i).getExpectedResult()+"|";
					bw.write (input);
					
					input = reportList.get(i).getActualResult()+"|";
					bw.write (input);
					
					input = reportList.get(i).getStatus()+"|";
					bw.write (input);
					
					input = reportList.get(i).getTimeStamp()+"|";
					bw.write (input);

					
				

					input = shareFolderPath+"\\"+reportList.get(i).getScreenShotFileName();
					bw.write (input);
					
					bw.newLine(); // new line after each step
					
				}
			}
		    
		    bw.close(); //Close writer
		    
		} catch(Exception e)
		{
		    e.printStackTrace();
		}
		
	}
	
	//This function is currently no in use. Need to wipe out if we are not using in any ATM related activities
	
	
	
	//Abir added this to open the HTML report after execution is complete. NOvember 7, 14
	@SuppressWarnings("deprecation")
	public static void openHTMLreport() throws Exception
	{
		try {
			
			
			String url1 = "" + filePath + "/"+DriverScript.sIndexHTMLFileName;
			File htmlFile = new File(url1);
			
			DesiredCapabilities desiredcapabilities=DesiredCapabilities.chrome();
		    ChromeOptions option=new ChromeOptions();
		    option.addArguments("--start-maximized");
		    desiredcapabilities.setCapability(ChromeOptions.CAPABILITY,option );
		    chromeDriverPath= fnGetData("ChromePath");
		    System.setProperty("webdriver.chrome.driver", 
		    			    		chromeDriverPath); 
		    WebDriver driver=new ChromeDriver(desiredcapabilities);
		    driver.manage().window().maximize();
		    driver.get(url1);
		   // Desktop.getDesktop().browse(htmlFile.toURI());
		}

		catch (Exception e) {
			System.out.println(e.getMessage());
		} 
	}

	public static String getCurrentTimeStamp(String format) {
	    SimpleDateFormat sdfDate = new SimpleDateFormat(format);  // "MM/dd/yyyy"
	    Date now = new Date();
	    String strDate = sdfDate.format(now);
	    return strDate;
	}
	
	// copy report folder from Local to share machine
	
	public void createTestResultsWithTimestamp(String filePath) 
	{
		System.out.println("Creating another copy of test results with timestamp...");
		try {

			System.out.println("Local File Path" + filePath);
			
			System.out.println("Remote Machine File Path" + shareFolderPath);
			
			String xCopyCommand = "xcopy /i  \"" + filePath + "\"" + " " + "\""	+ shareFolderPath + "\"";
			System.out.println(xCopyCommand);
			@SuppressWarnings("unused")
			Process process = Runtime.getRuntime().exec(xCopyCommand); 
			
		} catch (IOException ioe) {
			System.out.println("Error occurred while making a copy of test results with timestamp::: "+ ioe.getMessage());
		} 
		System.out.println("END - Creating another copy of test results with timestamp...");
		
		htmlLink = shareFolderPath + "\\" + DriverScript.sIndexHTMLFileName + ";"; // link to index.html in share machine
	}


	
	
} // end of class

